import {createSelector} from 'reselect'

//return state, because using immutable
export const getData = state => state

//reselect function
export const getDataset = createSelector(getData, function(dataset) {
  return dataset;
})

export const getMetadata = createSelector(getData, function(metadata) {
  return metadata;
})

import * as fromDataset from './dataset'

export function getDataset(state) {
  var dataset = fromDataset.getDataset(state.get('dataset'))
  return dataset
}

export function getMetadata(state) {
  return fromDataset.getMetadata(state.get('dataset').get('metadata'))
}

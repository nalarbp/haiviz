export async function getIsolateData(
  fileURL,
  loadIsolateData,
  setColorScale,
  loadSimulatedMap,
  loadXML,
  loadTreeData,
  loadMovementData,
  loadTransgraphData
) {
  let data_promise_raw = await csv(fileURL.isolateData).then(function(result) {
    return result;
  });
  const validHeaders = [
    "isolate_name",
    "isolate_species",
    "isolate_colDate",
    "isolate_colLocation",
    "isolate_sourceType",
    "isolate_sourceName",
    "profile_1",
    "profile_2",
    "profile_3"
  ];
  const inputHeaders = Object.keys(data_promise_raw[0]);
  let header_is_valid = true;
  validHeaders.forEach((item, i) => {
    if (inputHeaders.indexOf(item) === -1) {
      header_is_valid = false;
    }
  });
  if (!header_is_valid) {
    alert("Invalid headers");
    setisLoading(false);
    return;
  }
  // no duplicate in isolate name
  const isolate_name = _.countBy(data_promise_raw, "isolate_name");
  const duplicatedRecords = Object.keys(isolate_name)
    .map(key => {
      return { name: key, count: isolate_name[key] };
    })
    .filter(d => d.count > 1);
  const isolate_name_count = Object.values(isolate_name).sort((a, b) => {
    return a < b;
  });
  if (duplicatedRecords.length > 0) {
    alert(
      "Invalid data: duplicate record in column isolate name:" +
        `${JSON.stringify(duplicatedRecords)}`
    );
    setisLoading(false);
    return;
  }
  // no empty record in isolate_name
  const isolate_name_empty = isolate_name[""] ? true : false;
  if (isolate_name_empty) {
    alert("Invalid data: column isolate_name contain empty record");
    setisLoading(false);
    return;
  }
  // no empty record or invalid format in collection date
  let isolate_date_invalid = false;
  data_promise_raw.forEach(function(d) {
    d.isolate_name = d.isolate_name.replace(/\s*$/, "");
    d.isolate_colDate = d.isolate_colDate.replace(/\s*$/, "");
    d.isolate_sourceType = d.isolate_sourceType.replace(/\s*$/, "");
    d.isolate_sourceName = d.isolate_sourceName.replace(/\s*$/, "");
    d.isolate_species = d.isolate_species.replace(/\s*$/, "");
    d.isolate_colLocation = d.isolate_colLocation.replace(/\s*$/, "");
    if (isoDateParser(d.isolate_colDate)) {
      d["uid"] = d.isolate_name;
      d.isolate_colDate = isoDateParser(d.isolate_colDate);
    } else {
      isolate_date_invalid = true;
    }
  });
  let data_promise = data_promise_raw.map(d => {
    return {
      uid: d.uid,
      isolate_name: d.isolate_name,
      isolate_colDate: d.isolate_colDate,
      isolate_sourceType: d.isolate_sourceType,
      isolate_sourceName: d.isolate_sourceName,
      isolate_species: d.isolate_species,
      isolate_colLocation: d.isolate_colLocation,
      profile_1: d.profile_1,
      profile_2: d.profile_2,
      profile_3: d.profile_3
    };
  });
  if (isolate_date_invalid) {
    alert("Invalid data: wrong date format in column collection date");
    setisLoading(false);
    return;
  }
  // Create initial color table =====================================
  let species_list = data_promise
    .map(d => d.isolate_species)
    .filter(filterUnique);
  let location_list = data_promise
    .map(d => d.isolate_colLocation)
    .filter(filterUnique);
  let sourceType_list = data_promise
    .map(d => d.isolate_sourceType)
    .filter(filterUnique);
  let profile1_list = data_promise.map(d => d.profile_1).filter(filterUnique);
  let profile2_list = data_promise.map(d => d.profile_2).filter(filterUnique);
  let profile3_list = data_promise.map(d => d.profile_3).filter(filterUnique);
  const colorScale_bySpecies = colorOrdinalInterpolator(
    species_list,
    d3Chroma.interpolateRdYlBu
  );
  const colorScale_byLocation = colorOrdinalInterpolator(
    location_list,
    d3Chroma.interpolateSpectral
  );
  const colorScale_bySourceType = colorOrdinalInterpolator(
    sourceType_list,
    d3Chroma.interpolateViridis
  );
  const colorScale_byProfile1 = colorOrdinalInterpolator(
    profile1_list,
    d3Chroma.interpolateViridis
  );
  const colorScale_byProfile2 = colorOrdinalInterpolator(
    profile2_list,
    d3Chroma.interpolateViridis
  );
  const colorScale_byProfile3 = colorOrdinalInterpolator(
    profile3_list,
    d3Chroma.interpolateViridis
  );

  let colorbySpecies_Map = new Map();
  species_list.map(d => {
    colorbySpecies_Map.set(d, colorScale_bySpecies(d));
  });
  let colorbyLocation_Map = new Map();
  location_list.map(d => {
    colorbyLocation_Map.set(d, colorScale_byLocation(d));
  });
  let colorbySourceType_Map = new Map();
  sourceType_list.map(d => {
    colorbySourceType_Map.set(d, colorScale_bySourceType(d));
  });
  let colorbyProfile1_Map = new Map();
  profile1_list.map(d => {
    colorbyProfile1_Map.set(d, colorScale_byProfile1(d));
  });
  let colorbyProfile2_Map = new Map();
  profile2_list.map(d => {
    colorbyProfile2_Map.set(d, colorScale_byProfile2(d));
  });
  let colorbyProfile3_Map = new Map();
  profile3_list.map(d => {
    colorbyProfile3_Map.set(d, colorScale_byProfile3(d));
  });
  const colorScale_init = {
    colorType: "location",
    byLocation: colorbyLocation_Map,
    bySpecies: colorbySpecies_Map,
    bySourceType: colorbySourceType_Map,
    byProfile1: colorbyProfile1_Map,
    byProfile2: colorbyProfile2_Map,
    byProfile3: colorbyProfile3_Map
  };
  // make simulated map ================================================########
  const locationRollup = rollup(
    data_promise,
    d => d.length,
    d => d.isolate_colLocation
  );
  const childrenAccessorFn = ([key, value]) => {
    return value.size && Array.from(value);
  };
  const hierarchyData = hierarchy([null, locationRollup], childrenAccessorFn)
    .sum(([key, value]) => value)
    .sort((a, b) => b.value - a.value);

  //=========================================================================
  let isolateData_Map = new Map();
  data_promise.map(d => {
    isolateData_Map.set(d.uid, d);
  });

  loadIsolateData(isolateData_Map);
  loadSimulatedMap(hierarchyData);
  setColorScale(colorScale_init);

  //xml
  parseXML(fileURL.xmlData, loadXML);
  //tree
  parseTree(fileURL.treeData, loadTreeData);
  //trans
  //parseGraph(fileURL.transData, loadTransgraphData)
  //movement
  parseMovemet(filteURL.movementData, loadMovementData);
}

import {connect} from 'react-redux';
import SelectShowcaseDataset from '../components/component/btn_selectShowcaseDataset';
import {bindActionCreators} from 'redux';
import {newDataset} from '../action/index';


function mapDispatchToProps(dispatch, ownProps) {
  //newDataset is an action to parse all showase dataset (in a bundle)
  return bindActionCreators({newDataset: newDataset}, dispatch)
}

export default connect(null, mapDispatchToProps)(SelectShowcaseDataset);


/*

*/

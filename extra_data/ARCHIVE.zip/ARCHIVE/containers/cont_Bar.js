import React, {Component} from 'react'
import {selectActiveData} from '../action/index';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import BarComponent from '../components/comp_BarComponent';
import withMeasure from '../hocs/withMeasure'


function mapStateToProps(state, ownProps) {
  return {metadata: state.metadata.metadata,
          dateRange: state.metadata.dateRange,
          colorIndex: state.colorIndex,
          selectedData: state.selectedData.selectedData}
}

const dimensions = ['width', 'height']
const MeasuredBar = withMeasure(['width', 'height'])(BarComponent)

class MeasuredBarComponent extends Component {
  render(){
    return (
      <div style={{width: '100%', height: '100%'}} >
        <MeasuredBar metadata={this.props.metadata}
                    colorIndex={this.props.colorIndex}
                    selectedData={this.props.selectedData}
                    ></MeasuredBar>
      </div>
    )
  }
}

export default connect(mapStateToProps)(MeasuredBarComponent);

import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import TreeComponent from '../components/comp_TreeComponent';
import {selectActiveData} from '../action/index';
import React, {Component} from 'react'
import withMeasure from '../hocs/withMeasure'

function mapStateToProps(state, ownProps) {
  return {tree: state.tree,
          metadata: state.metadata.metadata,
          selectedData: state.selectedData,
          colorIndex: state.colorIndex}
}
function mapDispatchToProps(dispatch, ownProps) {
  return bindActionCreators({selectActiveData: selectActiveData}, dispatch)
}
////
const dimensions = ['width', 'height']
const MeasuredTree = withMeasure(dimensions)(TreeComponent)

class MeasuredComponentTree extends Component {
  render(){
    return (
      <div style={{width: '100%', height: '100%'}} >
        <MeasuredTree metadata={this.props.metadata}
                      tree={this.props.tree}
                      colorIndex={this.props.colorIndex}
                      selectActiveData={this.props.selectActiveData}
                      selectedData={this.props.selectedData.selectedData}
                      selectedExtent={this.props.selectedData.selectedExtent}
                    />
      </div>
    )
  }
}
export default connect(mapStateToProps, mapDispatchToProps)(MeasuredComponentTree);

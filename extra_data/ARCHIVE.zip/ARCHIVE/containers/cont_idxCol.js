import React, {Component} from 'react'
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import {changeColorIndex} from '../action/index';
import ColorComponent from '../components/comp_ColorComponent';
import withMeasure from '../hocs/withMeasure';

function mapStateToProps(state, ownProps) {
  //console.log('??-MTP INFOBOX');
  return {metadata: state.metadata.metadata,
          userColor: state.metadata.userColor,
          patientColor: state.metadata.patientColor,
          siteColor: state.metadata.siteColor,
          colorIndex:state.colorIndex}
}
//change the state of colour
function mapDispatchToProps(dispatch, ownProps) {
  return bindActionCreators({changeColorIndex: changeColorIndex}, dispatch)
}

const dimensions = ['width', 'height']
const MeasuredColor = withMeasure(['width', 'height'])(ColorComponent)


//props from container: dataset: Map(metadata,etc)
class MeasuredComponentColorIndex extends Component {
  render(){
    return (
      <div style={{width: '100%', height: '100%'}} >
        <MeasuredColor metadata={this.props.metadata}
                        colorIndex={this.props.colorIndex}
                        userColor={this.props.userColor}
                        changeColorIndex={this.props.changeColorIndex}
                        patientColor={this.props.patientColor}
                        siteColor={this.props.siteColor}/>
      </div>
    )
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(MeasuredComponentColorIndex);

import React, {Component} from 'react'
import {selectActiveData} from '../action/index';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import OverlappingTableComponent from '../components/comp_OverlappingTableComponent';
import withMeasure from '../hocs/withMeasure'

function mapStateToProps(state, ownProps) {
  return {metadata: state.metadata.metadata}
}

function mapDispatchToProps(dispatch, ownProps) {
  return bindActionCreators({selectActiveData: selectActiveData}, dispatch)
}

const dimensions = ['width', 'height']
const MeasuredOverlappingTable = withMeasure(['width', 'height'])(OverlappingTableComponent)

class MeasuredComponentOverlappingTable extends Component {
  render(){
    return (
      <div style={{width: '100%', height: '100%'}} >
        <MeasuredOverlappingTable metadata={this.props.metadata}
                              selectActiveData={this.props.selectActiveData}
                              ></MeasuredOverlappingTable>
      </div>
    )
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(MeasuredComponentOverlappingTable);
//

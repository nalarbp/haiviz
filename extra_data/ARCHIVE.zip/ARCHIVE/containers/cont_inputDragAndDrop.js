import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import {blob, csv, json, text} from 'd3-fetch';
import React, {Component} from 'react';
import FileDrop from 'react-file-drop';
import {printIt} from '../utils/utils';
import {load_DF} from '../action/index';
const FS = require('fs')


const DF = {
  ...require('data-forge'),
  ...require('data-forge-fs')
}



// === CONTAINER ===
// connect to states in store: metadata, map, phylo, transmission
function mapStateToProps(state, ownProps) {
  return {metadata: state.metadata.metadata,
          dateRange_init: state.metadata.dateRange,
          patients_init: state.metadata.patients,
          colorIndex: state.colorIndex,
          selectedData: state.selectedData}
}

// connect to action index
function mapDispatchToProps(dispatch, ownProps) {
  return bindActionCreators({load_DF: load_DF}, dispatch)
}

// AUXILARRY FUNCTIONS
async function getDF(fileURL) {
  var res = await csv(fileURL)
  return res;
}
// === COMPONENT ===
class comp_InputDragAndDrop extends Component {

  constructor(props) {
    super(props)
    this.state= {input:null}
    //this.oye= this.oye.bind(this)
    this.handleDrop= this.handleDrop.bind(this)
  }



  handleDrop(files, event) {

    //this.setState({'input':true})
    console.log(files.length);

    for (var i = 0; i < files.length; i++) {
      var ext = files[i].name.split('.').pop()
      switch (ext) {
        case 'csv':
        let file = files[i]
        if (file) {
          var reader = new FileReader();
          reader.readAsText(file);

          reader.onloadend = function(e) {
            var text = reader.result;
            var meta_DF = DF.fromCSV(text)
                            .parseDates('samplingDate', '%Y-%m-%d')
            console.log(meta_DF.toArray())
          }
        }



          //console.log('its csv');
          // get the input files
          //var meta_DF = DF.fromCSV(files[i])
          //console.log(files[i]);
          //var tree = await text(fileURL)

          // send to store through action
          //this.props.load_DF('val')

          break;
        case 'nwk':
          console.log('its Newick');
          break;
        default:
          alert(files[i].name+' is unsupported by HAIviz')

      }
    }

    //console.log(files[0].name)


  }

  render(){
    console.log('render');
    //console.log(this.props.metadata)
    //if component state == loaded > change to ok, else > show drag & drop
    if (this.state.input) {
      return (
        <div>
          <p>All good!</p>
        </div>
      )
    }
    else {
      return (
        <div className ="w3-panel w3-round-large" style={{height:'250px'}}>
          <FileDrop onDrop={this.handleDrop}>
            <div className ="w3-panel w3-border w3-round-large" style={{height:'200px'}}>
              Drop some files here!
            </div>

          </FileDrop>
        </div>
      // jsx containing drag and drop placeholder
      )
    }
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(comp_InputDragAndDrop);

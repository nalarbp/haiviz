import {connect} from 'react-redux';
import LoadShowcaseDataset from '../components/component/btn_loadShowcaseDataset';
import {bindActionCreators} from 'redux';
import {newDataset} from '../action/index';


function mapDispatchToProps(dispatch, ownProps) {
  return bindActionCreators({newDataset: newDataset}, dispatch)
}

export default connect(null, mapDispatchToProps)(LoadShowcaseDataset);


/*

*/

import React, {Component} from 'react'
import {selectActiveData} from '../action/index';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import SimulatedMapComponent from '../components/comp_SimulatedMapComponent';
import withMeasure from '../hocs/withMeasure'

function mapStateToProps(state, ownProps) {
  return {metadata: state.metadata.metadata,
          transmission: state.transmission,
          colorIndex: state.colorIndex,
          selectedData: state.selectedData.selectedData}
}

function mapDispatchToProps(dispatch, ownProps) {
  return bindActionCreators({selectActiveData: selectActiveData}, dispatch)
}

const dimensions = ['width', 'height']
const MeasuredSimulatedMap = withMeasure(['width', 'height'])(SimulatedMapComponent)

class MeasuredComponentSimulatedMap extends Component {
  render(){
    return (
      <div style={{width: '100%', height: '100%'}} >
        <MeasuredSimulatedMap metadata={this.props.metadata}
                              colorIndex={this.props.colorIndex}
                              transmission={this.props.transmission}
                              selectActiveData={this.props.selectActiveData}
                              selectedData={this.props.selectedData}
                              ></MeasuredSimulatedMap>
      </div>
    )
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(MeasuredComponentSimulatedMap);
//

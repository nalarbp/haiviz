import {connect} from 'react-redux';
import AnimationController from '../components/comp_AnimationController';
import {bindActionCreators} from 'redux';
import {deactivateChart} from '../action/index';


function mapDispatchToProps(dispatch, ownProps) {
  return bindActionCreators({deactivateChart: deactivateChart}, dispatch)
}

export default connect(null, mapDispatchToProps)(AnimationController);


/*

*/

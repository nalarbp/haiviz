import {connect} from 'react-redux';
import Dashboard from '../components/comp_Dashboard';
import {bindActionCreators} from 'redux';
import {loadData, updateLoginState, setActiveChart, setLayout, changeColorIndex} from '../action/index';

function mapStateToProps(state, ownProps) {
  return {metadata: state.metadata,
          colorIndex: state.colorIndex,
          floorplan: state.floorplan,
          tree: state.tree,
          metaDB: state.metaDB,
          transmission: state.transmission,
          activeChart: state.activeChart,
          loginState: state.loginState,
          layout: state.layout}
}

function mapDispatchToProps(dispatch, ownProps) {
  return bindActionCreators({loadData: loadData,
                              setLayout: setLayout,
                              changeColorIndex: changeColorIndex,
                              updateLoginState: updateLoginState,
                              setActiveChart: setActiveChart}, dispatch)
}

export default connect(mapStateToProps, mapDispatchToProps)(Dashboard)

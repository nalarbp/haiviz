import {connect} from 'react-redux';
import IndividualTest from '../components/comp_IndividualTest';
import {bindActionCreators} from 'redux';
import {newDataset} from '../action/index';


function mapDispatchToProps(dispatch, ownProps) {
  //newDataset is an action to parse all showase dataset (in a bundle)
  return bindActionCreators({newDataset: newDataset}, dispatch)
}

export default connect(null, mapDispatchToProps)(IndividualTest);


/*
h
*/

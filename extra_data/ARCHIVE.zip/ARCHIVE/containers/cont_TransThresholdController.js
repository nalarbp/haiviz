import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import TransLinkThresholdInput from '../components/component/btn_transLinkThresholdInput';
import {setTransLinkThreshold} from '../action/index';


function mapDispatchToProps(dispatch, ownProps) {
  return bindActionCreators({setTransLinkThreshold: setTransLinkThreshold}, dispatch)
}

export default connect(null, mapDispatchToProps)(TransLinkThresholdInput);


/*

*/

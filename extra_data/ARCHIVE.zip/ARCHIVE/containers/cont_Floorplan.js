import React, {Component} from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import MapComponent from '../components/comp_MapComponent';
import withMeasure from '../hocs/withMeasure';
import {selectActiveData} from '../action/index';

// get floorplan,  passed as props/
function mapStateToProps(state, ownProps) {
  return {floorplan: state.floorplan,
          metadata: state.metadata.metadata,
          colorIndex: state.colorIndex,
          selectedData:state.selectedData,
          levelID: ownProps.levelID}
}

function mapDispatchToProps(dispatch, ownProps) {
  return bindActionCreators({selectActiveData: selectActiveData}, dispatch)
}
//
const dimensions = ['width', 'height']
const MeasuredMap = withMeasure(dimensions)(MapComponent)

class MeasuredComponentMap extends Component {
  render(){
    //console.log('@@', this.props.floorplanDragLocationX);
    return (
      <div style={{width: '100%', height: '100%'}} >
        <MeasuredMap metadata={this.props.metadata}
                           levelID={this.props.levelID}
                           floorplan={this.props.floorplan}
                           selectedData={this.props.selectedData.selectedData}
                           selectedExtent={this.props.selectedData.selectedExtent}
                           selectActiveData={this.props.selectActiveData}
                           colorIndex={this.props.colorIndex}/>
      </div>
    )
  }
}
export default connect(mapStateToProps, mapDispatchToProps)(MeasuredComponentMap);

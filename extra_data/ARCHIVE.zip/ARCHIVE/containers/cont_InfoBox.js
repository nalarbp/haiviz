import {connect} from 'react-redux';
import InfoBox from '../components/comp_InfoBox';

function mapStateToProps(state, ownProps) {
  //console.log('??-MTP INFOBOX');
  return {metadata: state.metadata.metadata,
          clickedElement: state.clickedElement}
}

export default connect(mapStateToProps)(InfoBox);

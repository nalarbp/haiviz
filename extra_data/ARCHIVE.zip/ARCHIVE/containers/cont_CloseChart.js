import {connect} from 'react-redux';
import CloseChart from '../components/component/btn_closeChart';
import {bindActionCreators} from 'redux';
import {deactivateChart} from '../action/index';


function mapDispatchToProps(dispatch, ownProps) {
  return bindActionCreators({deactivateChart: deactivateChart}, dispatch)
}

export default connect(null, mapDispatchToProps)(CloseChart);


/*

*/

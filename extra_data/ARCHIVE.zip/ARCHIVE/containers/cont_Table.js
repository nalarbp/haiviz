import {connect} from 'react-redux';
import ComponentTable from '../components/comp_Table';

function mapStateToProps(state, ownProps) {
  return {metadata: state.metadata.metadata,
          selectedData: state.selectedData.selectedData}
}

export default connect(mapStateToProps)(ComponentTable);
///

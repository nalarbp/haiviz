import {connect} from 'react-redux';
import React, {Component} from 'react';
import {bindActionCreators} from 'redux';
import UkuleleComponent from '../components/comp_UkuleleComponent';
import {selectActiveData} from '../action/index';
import withMeasure from '../hocs/withMeasure';

function mapStateToProps(state, ownProps) {
  return {metadata: state.metadata.metadata,
          patients:state.metadata.patients,
          dateRange: state.metadata.dateRange,
          colorIndex: state.colorIndex,
          patientColor: state.metadata.patientColor}
}

function mapDispatchToProps(dispatch, ownProps) {
  return bindActionCreators({selectActiveData: selectActiveData}, dispatch)
}

const dimensions = ['width', 'height'],
      MeasuredUkulele = withMeasure(dimensions)(UkuleleComponent)

class MeasuredComponentUkulele extends Component {
  render(){
    return (
      <div style={{width: '100%', height: '100%'}} >
        <MeasuredUkulele
           dateRange={this.props.dateRange}
           metadata={this.props.metadata}
           patients={this.props.patients}
           colorIndex={this.props.colorIndex}
           selectActiveData={this.props.selectActiveData}
        ></MeasuredUkulele>
      </div>
    )
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(MeasuredComponentUkulele);

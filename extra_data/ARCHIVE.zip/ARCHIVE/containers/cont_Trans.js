import React, {Component} from 'react'
import {connect} from 'react-redux'
import {bindActionCreators} from 'redux'
import {updateClickedElement, loadData, setTransLinkThreshold, updateTransmissionData, selectActiveData} from '../action/index'
import TransComponent from '../components/comp_TransComponent'
import withMeasure from '../hocs/withMeasure'


function mapStateToProps(state, ownProps) {
  return {transmission: state.transmission,
          metadata: state.metadata.metadata,
          colorIndex: state.colorIndex,
          selectedData:state.selectedData}
}
////
function mapDispatchToProps(dispatch, ownProps) {
  return bindActionCreators({ updateTransmissionData: updateTransmissionData,
                              selectActiveData: selectActiveData}, dispatch)
}

const dimensions = ['width', 'height']
const MeasuredTrans = withMeasure(dimensions)(TransComponent)

class MeasuredComponentTrans extends Component {
  render(){
    return (
      <div style={{width: '100%', height: '100%'}} >
        <MeasuredTrans transmission={this.props.transmission}
                       colorIndex={this.props.colorIndex}
                       metadata={this.props.metadata}
                       selectActiveData={this.props.selectActiveData}
                       selectedData={this.props.selectedData.selectedData}
                       selectedExtent={this.props.selectedData.selectedExtent}
                       updateTransmissionData={this.props.updateTransmissionData}
                      ></MeasuredTrans>
      </div>
    )
  }
}


export default connect(mapStateToProps, mapDispatchToProps)(MeasuredComponentTrans);

import {connect} from 'react-redux';
import SearchFormChart from '../components/component/btn_SearchFormChart';
import {bindActionCreators} from 'redux';
import {selectActiveData} from '../action/index';


function mapDispatchToProps(dispatch, ownProps) {
  return bindActionCreators({selectActiveData: selectActiveData}, dispatch)
}

export default connect(null, mapDispatchToProps)(SearchFormChart);

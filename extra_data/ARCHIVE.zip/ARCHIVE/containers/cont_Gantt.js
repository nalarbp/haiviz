import {connect} from 'react-redux';
import TimelineComponent from '../components/comp_TimelineComponent';
import {bindActionCreators} from 'redux';
import {selectActiveData} from '../action/index';
import React, {Component} from 'react';
import withMeasure from '../hocs/withMeasure';

// get metadata, extract date Range, create filterData return as props
function mapStateToProps(state, ownProps) {
  return {metadata: state.metadata.metadata,
          dateRange_init: state.metadata.dateRange,
          patients_init: state.metadata.patients,
          colorIndex: state.colorIndex,
          selectedData: state.selectedData}
}

function mapDispatchToProps(dispatch, ownProps) {
  return bindActionCreators({selectActiveData: selectActiveData}, dispatch)
}

const dimensions = ['width', 'height']
const MeasuredTimeline = withMeasure(dimensions)(TimelineComponent)


class MeasuredComponentTimeline extends Component {
  render(){
    //console.log(this.props.metadata)
    return (
      <MeasuredTimeline metadata={this.props.metadata}
                        dateRange_init={this.props.dateRange_init}
                        patients_init={this.props.patients_init}
                        colorIndex={this.props.colorIndex}
                        selectActiveData={this.props.selectActiveData}
                        selectedData={this.props.selectedData}>

                        </MeasuredTimeline>
    )
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(MeasuredComponentTimeline);

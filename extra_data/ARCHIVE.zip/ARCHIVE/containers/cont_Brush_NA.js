import {connect} from 'react-redux';
import React, {Component} from 'react';
import {bindActionCreators} from 'redux';
//import Brush from '../components/comp_Brush';
import BrushComponent from '../components/comp_BrushComponent';
import {selectActiveData} from '../action/index';
import withMeasure from '../hocs/withMeasure';

function mapStateToProps(state, ownProps) {
  return {metadata: state.metadata.metadata,
          patients: state.metadata.patients,
          dateRange: state.metadata.dateRange,
          siteColor: state.metadata.siteColor,
          patientColor: state.metadata.patientColor}
}

function mapDispatchToProps(dispatch, ownProps) {
  return bindActionCreators({selectActiveData: selectActiveData}, dispatch)
}

const dimensions = ['width', 'height'],
      MeasuredBrush = withMeasure(dimensions)(BrushComponent)

class MeasuredComponentBrush extends Component {
  render(){
    return (
      <div style={{width: '100%', height: '100%'}} >
        <MeasuredBrush
           dateRange={this.props.dateRange}
           patients={this.props.patients}
           metadata={this.props.metadata}
           siteColor={this.props.siteColor}
           selectActiveData={this.props.selectActiveData}
        ></MeasuredBrush>
      </div>
    )
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(MeasuredComponentBrush);

import {connect} from 'react-redux';
import DownloadUploadSession from '../components/comp_downloadUploadSession';
import {bindActionCreators} from 'redux';
import {loadSession} from '../action/index';

function mapStateToProps(state, ownProps) {
  return {activeChart: state.activeChart,
          metadata: state.metadata,
          floorplan: state.floorplan,
          transmission: state.transmission,
          layout: state.layout,
          selectedData: state.selectedData,
          colorIndex: state.colorIndex,
          tree: state.tree}
}

function mapDispatchToProps(dispatch, ownProps) {
  return bindActionCreators({loadSession: loadSession}, dispatch)
}

export default connect(mapStateToProps, mapDispatchToProps)(DownloadUploadSession);

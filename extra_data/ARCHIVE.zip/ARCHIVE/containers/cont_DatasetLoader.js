import React, {Component} from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import {loadDataset} from '../action/index';
import {csv, json, text} from 'd3-fetch';

const metadataURL = './data/metadata1.csv';
const transURL = './data/trans1.csv';
const floorplanURL = './data/map1.geojson';
const newickURL = './data/tree.txt';

async function getDataset(metadataURL, floorplanURL, newickURL, transURL ) {
  var rawDataset={}
  var treeFile = await text(newickURL)
  var jsonFile = await json(floorplanURL);
  var csvFile = await csv(metadataURL);
  csvFile.forEach((d) => {
    d.dateIn = new Date(d.dateIn)
    d.dateOut = new Date(d.dateOut)
    if (d.samplingDate !== 'N/A') {d.samplingDate = new Date(d.samplingDate)}
  })
  var transFile = await csv(transURL);
  transFile.forEach(function(d) {
    if (d.parent == 'null') d.parent = null;
  });
  rawDataset.metadata = csvFile;
  rawDataset.floorplan = jsonFile;
  rawDataset.tree = treeFile;
  rawDataset.transmission = transFile;
  return rawDataset;
}


class DatasetLoader extends Component {
  render(){
    let dataset = getDataset(metadataURL, floorplanURL, newickURL, transURL)
    this.props.loadDataset(dataset)
    return(
      <div></div>
    )
  }
}

function mapDispatchToProps(dispatch) {
  //console.log('??-MTP DATA');
  return bindActionCreators({loadDataset}, dispatch)
}

export default connect(null, mapDispatchToProps)(DatasetLoader)

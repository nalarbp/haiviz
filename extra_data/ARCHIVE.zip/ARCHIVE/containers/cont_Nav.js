import {connect} from 'react-redux';
import Nav from '../components/comp_Nav';
import {bindActionCreators} from 'redux';
import {setActiveChart, setLayout, addFloorplan} from '../action/index';

function mapStateToProps(state, ownProps) {
  return {activeChart: state.activeChart,
          metadata: state.metadata.metadata,
          floorplan: state.floorplan,
          transmission: state.transmission,
          layout: state.layout,
          tree: state.tree}
}

function mapDispatchToProps(dispatch, ownProps) {
  return bindActionCreators({setActiveChart: setActiveChart,
                              setLayout: setLayout,
                              addFloorplan: addFloorplan}, dispatch)
}

export default connect(mapStateToProps, mapDispatchToProps)(Nav);

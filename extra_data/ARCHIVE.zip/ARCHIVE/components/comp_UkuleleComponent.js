import React, {Component} from 'react'
import UkuleleViewer from './comp_UkuleleViewer'
import {withFauxDOM} from 'react-faux-dom'
import CloseChart from '../containers/cont_CloseChart'
const d3 = {
  ...require('d3-array'),
  ...require('d3-scale'),
  ...require('d3-axis'),
  ...require('d3-time'),
  ...require('d3-selection')
}

class UkuleleComponent extends Component {
  render() {
    if (this.props.height !== 0 && this.props.width !== 0 && this.props.metadata !== null) {
      return (
        <div style={{width: '100%', height: '100%'}}>
          <UkuleleViewer
            metadata={this.props.metadata}
            patients={this.props.patients}
            dateRange={this.props.dateRange}
            width={this.props.width}
            colorIndex={this.props.colorIndex}
            height={this.props.height}
            selectActiveData={this.props.selectActiveData}
          ></UkuleleViewer>
        </div>
      )
    }
    else {
      //console.log('#dimensions not ready', this.props.height, this.props.width)
      return (
        <div style={{width: '100%', height: '100%'}}>
          <h4>Processing..</h4>
        </div>
      )
    }
  }
}

export default UkuleleComponent

/*

*/

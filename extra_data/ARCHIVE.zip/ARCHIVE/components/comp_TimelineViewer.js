//Module timeline viewer
import React, {Component} from 'react'
import {withFauxDOM} from 'react-faux-dom'
import * as util from '../utils/utils'
import CloseChart from '../containers/cont_CloseChart'
import DownloadSVG from './component/btn_downloadSVG'
import {PanelTop, PanelTitle} from './component/btn_utils'
import {event as d3Event} from 'd3';
const d3 = {
  ...require('d3-array'),
  ...require('d3-scale'),
  ...require('d3-axis'),
  ...require('d3-time'),
  ...require('d3-selection'),
}

// //props from container: metadata
class TimelineViewer extends Component {
  constructor(props){
  super(props)
  this.state = {collectionTimeline:false,
                gridType:'daily',
                sidebarMenu: false}

  this.initiateTimeline= this.initiateTimeline.bind(this)
  this.updateTimelineBySelectedData=this.updateTimelineBySelectedData.bind(this)
  this.redrawTimeline=this.redrawTimeline.bind(this)

  this.toCollectionDateOnly= this.toCollectionDateOnly.bind(this)
  this.collectionDateTimelineOnly= this.collectionDateTimelineOnly.bind(this)

  this.changeGridType=this.changeGridType.bind(this)
  this.updateGridType=this.updateGridType.bind(this)

  this.openSetting=this.openSetting.bind(this)
  this.closeSetting=this.closeSetting.bind(this)
  }
//
  componentDidMount(){
      this.initiateTimeline()
  }

  shouldComponentUpdate(nextProps, nextStates){
    //console.log(nextStates.gridAtt, this.state.gridAtt, nextStates.gridAtt === this.state.gridAtt);
    if (nextStates.collectionTimeline !== this.state.collectionTimeline) {
      this.collectionDateTimelineOnly(nextStates.collectionTimeline)
      return false;
    }
    else if (nextStates.sidebarMenu !== this.state.sidebarMenu) {
      this.w3_open(nextStates.sidebarMenu)
      return false;
    }
    else {
      return true;
    }
  }

  componentDidUpdate(prevProps, prevState){
    //console.log('this==prev', this.props.dateRange_init === prevProps.dateRange_init );
    //when selected data is null and selectedExtent is undefined: intial render >>ok
    //selectedData is [], selectedExtent is undefined, no records found >> no render
    //selectedData is [1,2,3], selectedExtent is [1,2], multiple record found
    //selectedData is [1], selectedExtent is undefined, on click event
    if (this.props.selectedData && this.props.selectedData.length > 0 &&
        this.props.selectedData !== prevProps.selectedData){
      d3.select('svg#ganttSVG').remove()
      this.updateTimelineBySelectedData()
    }

    else if ( this.props.width !== prevProps.width &&
              this.props.height !== prevProps.height) {
            d3.select('svg#ganttSVG').remove()
            d3.select('#timeline_refreshDescriptor').classed('w3-show', true)
    }

    else if (this.props.colorIndex !== prevProps.colorIndex) {
      this.redrawTimeline()
    }
  }

  toCollectionDateOnly(e){
    if (this.state.collectionTimeline) {
      this.setState({collectionTimeline:false})
    } else {
      this.setState({collectionTimeline:true})
    }
  }

  collectionDateTimelineOnly(collectionTimeline){
    if (collectionTimeline) {
      d3.selectAll('.gantt_rect')
                      .style('visibility', 'hidden')
    } else {
      d3.selectAll('.gantt_rect')
                      .style('visibility', 'visible')
    }
  }

  changeGridType(e){
    if (e.target.value !== 'null') {
      var sel = e.target.value
      this.setState({gridType: sel})
    }
    else {
      this.setState({gridType: undefined})
    }
  }

  updateGridType(gridType){
    //what is the current state of gantt height, with and data range?
    d3.select('#gAxisGrid').remove()
    //grid
    var height, width, dateRange

    var gantt_x = d3.scaleTime()
                    .domain(dateRange)
                    .range([0, width])

    switch (gridType) {
      case 'daily':
        var gantt_grid_daily = d3.axisTop().scale(gantt_x)
                                 .ticks(d3.timeDay.every(1))
                                 .tickSize([height])

        d3.select("svg#ganttSVG").select("#gantt_svgGroupRoot").append('g').attr('id', 'gAxisGrid')
                    .attr("transform", "translate(0," + height  + ")")
                    .attr('class', 'w3-axis')
                    .call(gantt_grid_daily)
        break;
      case 'weekly':
        var gantt_grid_weekly = d3.axisTop().scale(gantt_x)
                                  .ticks(d3.timeWeek.every(1))
                                  .tickSize([height])
        d3.select("svg#ganttSVG").select("#gantt_svgGroupRoot").append('g').attr('id', 'gAxisGrid')
                    .attr("transform", "translate(0," + height  + ")")
                    .attr('class', 'w3-axis')
                    .call(gantt_grid_weekly)
        break;
      case 'monthly':
        var gantt_grid_monthly = d3.axisTop().scale(gantt_x)
                                   .ticks(d3.timeMonth.every(1))
                                   .tickSize([height])
        d3.select("svg#ganttSVG").select("#gantt_svgGroupRoot").append('g').attr('id', 'gAxisGrid')
                    .attr("transform", "translate(0," + height  + ")")
                    .attr('class', 'w3-axis')
                    .call(gantt_grid_monthly)
        break;
      default:
    }
  }

  openSetting() {
    var el = document.getElementById('timelineController')
    el.className = "w3-sidebar w3-border-bottom w3-show-block"
    el.style="height:auto;right:0"

  }
  closeSetting(){
    document.getElementById('timelineController').className = "w3-hide"
  }

  collectionDateTimelineOnly(collectionTimeline){
    if (collectionTimeline) {
      d3.selectAll('.gantt_rect')
                      .style('visibility', 'hidden')
    } else {
      d3.selectAll('.gantt_rect')
                      .style('visibility', 'visible')
    }
  }

  redrawTimeline(){
    d3.select('svg#ganttSVG').remove()
    d3.select('#timeline_refreshDescriptor').classed('w3-show', false)
    this.initiateTimeline()
  }

  render() {
    //console.log('+++render TimelineViewer+++');
    const {timeline:timeline, timelineViewer: timelineViewer} = this.props
    return (
      <div id="timeline" className= 'w3-row'>
        <div className= 'panelHeader w3-row w3-dark-grey'>
          <PanelTitle titleText={"Timeline Chart"}></PanelTitle>
          <div id="timeline_setting" className= 'w3-col m6 w3-right'>
            <CloseChart id='gantt'/>
            <DownloadSVG id='ganttSVG'/>
            <div className='w3-right'>
              <button onClick={this.openSetting}
                      className="w3-button w3-medium w3-hover-none">
                      <i className="fa fa-wrench fa-lg"></i>
              </button>
            </div>
            <div id='refreshButton' className='w3-right'>
              <button onClick={this.redrawTimeline}
                      className="w3-button w3-medium w3-hover-none">
                      <i className="fa fa-refresh fa-lg"></i>
              </button>
            </div>
          </div>
        </div>

        <div id="timelineController" className= " w3-sidebar w3-border-right w3-behind w3-hide" >
          <div className= "w3-right" >
            <button onClick={this.closeSetting}
                    className="w3-button w3-medium w3-hover-none">
                    <i className="fa fa-times-circle fa-lg"></i></button>
          </div>

          <div id='timelineType' className= "w3-container w3-row w3-margin-top w3-margin-bottom w3-behind" >
            <div className='w3-col s10'>
              <label>Collection date only &nbsp;&nbsp; </label>
              <label className="w3-switch">
                <input onChange={this.toCollectionDateOnly} type="checkbox"></input>
                  <span className="w3-slider round"></span>
                </label>

            </div>
            <div className='w3-col s2 w3-right'>
              <i onClick={this.closeSetting} className='w3-text-orange fa fa-question-circle fa-xs'></i>
            </div>
          </div>
        </div>

        <div id='timeline_tooltip' className='w3-container w3-small w3-white w3-row'>
          <div id='tooltip_info_icon' className='w3-text-white w3-col s1'>
            <p>.<i className="fa fa-info-circle fa-lg w3-text-black"></i></p>
          </div>
          <div id='timeline_tooltip_text' className='w3-col s11 w3-text-left'>
            <p></p>
          </div>
        </div>

        <div id= 'timelineViewer' className= 'w3-center'>
          <h6 id='timeline_refreshDescriptor' className='w3-hide'>
             Redraw chart using reload button on the top right corner of this window
           </h6>
          {timelineViewer}
        </div>
      </div>
    )
  }

  initiateTimeline(){
    //we need dynamic date scale, so we use data (meta/selected) as input
    var margin = {'top': 10, 'right': 40, 'bottom': 20, 'left': 70},
                  {dateRange_init, patients_init, metadata, colorIndex, selectActiveData, height, width, connectFauxDOM, drawFauxDOM} = this.props,
                  timeline_height = height - 90 - margin.top - margin.bottom,
                  tooltipID = "timeline_tooltip_text",
                  timeline_width = width - margin.left - margin.right,
                  faux = connectFauxDOM('div', 'timelineViewer'),
                  collectionTimeline = this.state.collectionTimeline

    //generate new scale from new data
    var patients = []
    patients_init.forEach(function(d) {patients.push(d)})
    patients.push('plusOne') //mybuggysign
    var rectHeight = timeline_height/patients.length

    var dateRange= dateRange_init

    //scale
    var gantt_x = d3.scaleTime().domain(dateRange).range([0, timeline_width]),
        gantt_y = d3.scalePoint().domain(patients).range([0, timeline_height])

    //axis-scale
    var gantt_xAxis = d3.axisBottom().scale(gantt_x),
        gantt_grid_daily = d3.axisTop().scale(gantt_x).ticks(d3.timeDay.every(1)).tickSize([10]),
        gantt_grid_weekly = d3.axisTop().scale(gantt_x).ticks(d3.timeWeek.every(1)).tickSize([timeline_height]),
        gantt_grid_monthly = d3.axisTop().scale(gantt_x).ticks(d3.timeMonth.every(1)).tickSize([timeline_height]),
        gantt_yAxis = d3.axisLeft(gantt_y).tickFormat("").tickSize(0)

    //SVG root
    var container = d3.select(faux)
    var svg = container.append('svg')
                       .attr('id', 'ganttSVG')
                       .attr('width', timeline_width + margin.left + margin.right)
                       .attr('height', timeline_height + margin.top + margin.bottom)
    //clipping mask
    var svgGroupRoot = svg.append('g').attr('id', 'gantt_svgGroupRoot')
                          .attr('transform', 'translate(' + margin.left + ',' + margin.top + ')')
        svgGroupRoot.append("defs")
                    .append("clipPath")
                    .attr("id", "gantt_clipPath")
                    .append("rect")
                    .attr("width", timeline_width)
                    .attr("height", timeline_height)

    //rectangles
    var rectGroup = svgGroupRoot.append("g")
                                .attr('class', 'rectGroup')
                                .attr("clip-path", "url(#gantt_clipPath)")
        rectGroup.selectAll(".gantt_rect")
               .data(metadata)
               .enter().append("rect")
               .attr('class', 'gantt_rect')
               .attr('id', (d) => {return 'gantt_rect'+d.entryID })
               .attr('x', (d) => {return gantt_x(d.dateIn)})
               .attr('y', (d) => {return gantt_y(d.patID)})
               .attr('width', (d) => {return gantt_x(d.dateOut) - gantt_x(d.dateIn)})
               .attr('height', rectHeight)
               .on('mouseover', (d) => {showTooltip('#'+tooltipID, d, 'admission')})
               .on('mouseout', (d) => {hideTooltip('#'+tooltipID)})
               .style("fill", function(d) {return util.fillWithColorIndex(d, colorIndex)})
               .style('visibility', () => {return !collectionTimeline ? 'visible' : 'hidden'})

    //axis (X)
    svgGroupRoot.append('g').attr('id', 'gAxisX')
                   .attr("transform", "translate(0," + timeline_height + ")")
                   .call(gantt_xAxis);
    //axis-lable (Y)
    svgGroupRoot.append("g").selectAll(".yAxis_label")
               .data(patients).enter().append('text')
               .attr('class', 'yAxis_label')
               .text((d) => {if (d !== undefined && d !== 'plusOne') {return d}})
               .attr('x', -3)
  ,           .attr('y', function(d) {if (d !== undefined) {return gantt_y(d)+(rectHeight/2)}})
               .attr('text-anchor', 'end')
               .attr('font-size', '0.7em')

    //sampling date: circles
    rectGroup.selectAll(".gantt_sampling_circle")
              .data(metadata)
              .enter().append("circle")
              .attr('class', 'gantt_sampling_circle')
              .attr('cx', (d) => {return d.samplingDate ? gantt_x(d.samplingDate) : 0 }) //put -10 to hide out
              .attr('cy', (d) => {return d.samplingDate ? gantt_y(d.patID) + rectHeight/2 : 0 }) //put -10 to hide out
              .attr('r', rectHeight/4)
              .style("fill", function(d) {return util.fillWithColorIndex(d, colorIndex)})
              .style("stroke", "black")
              .style("stroke-width", '2px')
              .style('visibility', (d) => { return !d.samplingDate ? 'hidden' : 'visible'})
              .style('cursor', 'move')
              .on('mouseover', (d) => {showTooltip('#'+tooltipID, d, 'admission')})
              .on('mouseout', (d) => {hideTooltip('#'+tooltipID)})
              .on('click', (d) => {selectActiveData({selectedData: [d], selectedExtent: undefined})})
    //sample id text
    rectGroup.selectAll(".gantt_sample_text")
              .data(metadata)
              .enter().append("text")
              .attr('class', 'gantt_sample_text')
              .attr('x', (d) => {return d.samplingDate ? gantt_x(d.samplingDate) + 10 : -10 }) //hide out
              .attr('y', (d) => {return d.samplingDate ? gantt_y(d.patID) + rectHeight/2 : -10 }) //hide out
              .text(function(d) { return String(d.sampleID) })
              .style("fill", 'black')

    //add left and bottom axis title
    svgGroupRoot.append("text")
                  .attr("transform", "rotate(-90)")
                  .attr("y", 0 - margin.left)
                  .attr("x",0 - (timeline_height / 2))
                  .attr("dy", "1em")
                  .style("text-anchor", "middle")
                  .text("Hosts");

    //grid
    switch (this.state.gridType) {
      case 'daily':
        svgGroupRoot.append('g').attr('id', 'gAxisGrid')
                  .attr("transform", "translate(0," + timeline_height + ")")
                  .attr('class', 'w3-axis')
                  .call(gantt_grid_daily)
        break;
      case 'weekly':
        svgGroupRoot.append('g').attr('id', 'gAxisGrid')
                  .attr("transform", "translate(0," + timeline_height + ")")
                  .attr('class', 'w3-axis')
                  .call(gantt_grid_weekly)
        break;
      case 'monthly':
        svgGroupRoot.append('g').attr('id', 'gAxisGrid')
                  .attr("transform", "translate(0," + timeline_height + ")")
                  .attr('class', 'w3-axis')
                  .call(gantt_grid_monthly)
        break;
      default:
      //draw nothing
    }

    //Local-tooltips function
    function showTooltip(tooltipID, data, option) {
      if (option === 'isolate') {
        var tooltip = d3.select(tooltipID)
                        .html('<p id="timeline_tooltip_content" >' +
                              'Sample: ' +data.sampleID +
                              '<span>&nbsp&nbsp&nbsp&nbsp</span>'+
                              'Collected on: ' +util.formatTime(data.samplingDate) +
                              '<span>&nbsp&nbsp&nbsp&nbsp</span>'+
                              'From: '+data.patID+
                              '</p>')
      } else {
        var tooltip = d3.select(tooltipID)
                        .html('<p id="timeline_tooltip_content" >' +
                              'Host: '+data.patID+
                              '<span>&nbsp&nbsp&nbsp&nbsp</span>'+
                              'Stay at: ' +data.siteID+
                              '<span>&nbsp&nbsp&nbsp&nbsp</span>'+
                              'from: ' +util.formatTime(data.dateIn) +
                              '<span>&nbsp&nbsp&nbsp&nbsp</span>'+
                              'to: ' +util.formatTime(data.dateOut) +
                              '</p>')
      }
    }

    function hideTooltip(tooltipID) {
      d3.select('#timeline_tooltip_content').remove()

    }


     //console.log('setState');
     //update grid attribute state
     //this.setState({gridAtt:{height: timeline_height}})
                             //
     //console.log('aftersetState, to drawFauxDOM');
    drawFauxDOM()
  }

  updateTimelineBySelectedData(){
    //we need dynamic date scale, so we use data (meta/selected) as input
    var margin = {'top': 10, 'right': 40, 'bottom': 20, 'left': 70},
                  {selectedData, selectedExtent, colorIndex, selectActiveData, height, width, connectFauxDOM, drawFauxDOM} = this.props,
                  timeline_height = height - 90 - margin.top - margin.bottom,
                  timeline_width = width - margin.left - margin.right,
                  tooltipID = "timeline_tooltip_text",
                  faux = connectFauxDOM('div', 'timelineViewer'),
                  collectionTimeline = this.state.collectionTimeline
    //console.log(selectedData, selectedExtent);
    //generate new scale from new data
    var newPatientList = [], newDateRange = []
        selectedData.forEach(function (d) {
          newPatientList.push(d.patID)
          newDateRange.push(d.dateIn, d.dateOut, d.samplingDate)
        })
    var patients = newPatientList.filter(util.filterUniqueNullUndefined)
        patients.push('plusOne') //mybuggysign
    var rectHeight = timeline_height/patients.length

    var arbtoday = new Date(), arbtomorrow = new Date()
        arbtomorrow.setDate(arbtoday.getDate()+1)
    var defaultRange = [arbtoday, arbtomorrow],
        dateRange = util.getDateRangeOnExtent(d3.extent(newDateRange), selectedExtent, defaultRange)


    //scale
    var gantt_x = d3.scaleTime().domain(dateRange).range([0, timeline_width]),
        gantt_y = d3.scalePoint().domain(patients).range([0, timeline_height])

    //axis-scale
    var gantt_xAxis = d3.axisBottom().scale(gantt_x),
        gantt_grid_daily = d3.axisTop().scale(gantt_x).ticks(d3.timeDay.every(1)).tickSize([10]),
        gantt_grid_weekly = d3.axisTop().scale(gantt_x).ticks(d3.timeWeek.every(1)).tickSize([timeline_height]),
        gantt_grid_monthly = d3.axisTop().scale(gantt_x).ticks(d3.timeMonth.every(1)).tickSize([timeline_height]),
        gantt_yAxis = d3.axisLeft(gantt_y).tickFormat("").tickSize(0)

    //SVG root
    var container = d3.select(faux)
    var svg = container.append('svg')
                       .attr('id', 'ganttSVG')
                       .attr('width', timeline_width + margin.left + margin.right)
                       .attr('height', timeline_height + margin.top + margin.bottom)
    //clipping mask
    var svgGroupRoot = svg.append('g').attr('id', 'gantt_svgGroupRoot')
                          .attr('transform', 'translate(' + margin.left + ',' + margin.top + ')')
        svgGroupRoot.append("defs")
                    .append("clipPath")
                    .attr("id", "gantt_clipPath")
                    .append("rect")
                    .attr("width", timeline_width)
                    .attr("height", timeline_height)

    //rectangles
    var rectGroup = svgGroupRoot.append("g")
                                .attr('class', 'rectGroup')
                                .attr("clip-path", "url(#gantt_clipPath)")
        rectGroup.selectAll(".gantt_rect")
               .data(selectedData)
               .enter().append("rect")
               .attr('class', 'gantt_rect')
               .attr('id', (d) => {return 'gantt_rect'+d.entryID })
               .attr('x', (d) => {return gantt_x(d.dateIn)})
               .attr('y', (d) => {return gantt_y(d.patID)})
               .attr('width', (d) => {return gantt_x(d.dateOut) - gantt_x(d.dateIn)})
               .attr('height', rectHeight)
               .on('mouseover', (d) => {showTooltip('#'+tooltipID, d, 'admission')})
               .on('mouseout', (d) => {hideTooltip('#'+tooltipID)})
               .style("fill", function(d) {return util.fillWithColorIndex(d, colorIndex)})
               .style('visibility', () => {return !collectionTimeline ? 'visible' : 'hidden'})

    //axis (X)
    svgGroupRoot.append('g').attr('id', 'gAxisX')
                   .attr("transform", "translate(0," + timeline_height + ")")
                   .call(gantt_xAxis);
    //axis-lable (Y)
    svgGroupRoot.append("g").selectAll(".yAxis_label")
               .data(patients).enter().append('text')
               .attr('class', 'yAxis_label')
               .text((d) => {if (d !== undefined && d !== 'plusOne') {return d}})
               .attr('x', -3)
               .attr('y', function(d) {if (d !== undefined) {return gantt_y(d)+(rectHeight/2)}})
               .attr('text-anchor', 'end')
               .attr('font-size', '0.7em')

    //sampling date: circles
    rectGroup.selectAll(".gantt_sampling_circle")
              .data(selectedData)
              .enter().append("circle")
              .attr('class', 'gantt_sampling_circle')
              .attr('cx', (d) => {return d.samplingDate ? gantt_x(d.samplingDate) : 0 }) //-10 to hide
              .attr('cy', (d) => {return d.samplingDate ? gantt_y(d.patID) + rectHeight/2 : 0 }) //-10 to hide
              .attr('r', rectHeight/4)
              .style("fill", function(d) {return util.fillWithColorIndex(d, colorIndex)})
              .style("stroke", "black")
              .style("stroke-width", '2px')
              .style('visibility', (d) => { return !d.samplingDate ? 'hidden' : 'visible'})
              .style('cursor', 'move')
              .on('mouseover', (d) => {showTooltip('#'+tooltipID, d, 'isolate')})
              .on('mouseout', (d) => {hideTooltip('#'+tooltipID)})
              .on('click', (d) => {selectActiveData({selectedData: [d], selectedExtent: undefined})})

    //add left and bottom axis title
    svgGroupRoot.append("text")
                  .attr("transform", "rotate(-90)")
                  .attr("y", 0 - margin.left)
                  .attr("x",0 - (timeline_height / 2))
                  .attr("dy", "1em")
                  .style("text-anchor", "middle")
                  .text("Hosts");
    //grid
    switch (this.state.gridType) {
      case 'daily':
        svgGroupRoot.append('g').attr('id', 'gAxisGrid')
                  .attr("transform", "translate(0," + timeline_height + ")")
                  .attr('class', 'w3-axis')
                  .call(gantt_grid_daily)
        break;
      case 'weekly':
        svgGroupRoot.append('g').attr('id', 'gAxisGrid')
                  .attr("transform", "translate(0," + timeline_height + ")")
                  .attr('class', 'w3-axis')
                  .call(gantt_grid_weekly)
        break;
      case 'monthly':
        svgGroupRoot.append('g').attr('id', 'gAxisGrid')
                  .attr("transform", "translate(0," + timeline_height + ")")
                  .attr('class', 'w3-axis')
                  .call(gantt_grid_monthly)
        break;
      default:
      //draw nothing
    }

     //Local-tooltips function
     function showTooltip(tooltipID, data, option) {
       if (option === 'isolate') {
         var tooltip = d3.select(tooltipID)
                         .html('<p id="timeline_tooltip_content" >' +
                               'Sample: ' +data.sampleID +
                               '<span>&nbsp&nbsp&nbsp&nbsp</span>'+
                               'Collected on: ' +util.formatTime(data.samplingDate) +
                               '<span>&nbsp&nbsp&nbsp&nbsp</span>'+
                               'From: '+data.patID+
                               '</p>')
       } else {
         var tooltip = d3.select(tooltipID)
                         .html('<p id="timeline_tooltip_content" >' +
                               'Host: '+data.patID+
                               '<span>&nbsp&nbsp&nbsp&nbsp</span>'+
                               'Stay at: '+data.siteID+
                               '<span>&nbsp&nbsp&nbsp&nbsp</span>'+
                               'from: ' +util.formatTime(data.dateIn) +
                               '<span>&nbsp&nbsp&nbsp&nbsp</span>'+
                               'to: ' +util.formatTime(data.dateOut) +
                               '</p>')
       }
     }

     function hideTooltip(tooltipID) {
       d3.select('#timeline_tooltip_content').remove()

     }

     /*update grid attribute state
     this.setState({gridAtt:{height: timeline_height,
                             width: timeline_width,
                             dateRange: dateRange}})
                             */
    drawFauxDOM()
  }

}

export default withFauxDOM(TimelineViewer)
/*
initiateTimeline(metadata){
  //we need dynamic date scale, so we use data (meta/selected) as input
  var margin = {'top': 10, 'right': 40, 'bottom': 20, 'left': 40},
                {color_user, selectActiveData, selectedExtent, height, width, connectFauxDOM, drawFauxDOM} = this.props,
                timeline_height = height - 90 - margin.top - margin.bottom,
                timeline_width = width - margin.left - margin.right,
                faux = connectFauxDOM('div', 'timelineViewer'),
                collectionTimeline = this.state.collectionTimeline

  //generate new scale from new data
  var newPatientList = [], newDateRange = []
      metadata.forEach(function (d) {
        newPatientList.push(d.patID)
        newDateRange.push(d.dateIn, d.dateOut, d.samplingDate)
      })
  var patients = newPatientList.filter(util.filterUnique)
      patients.push('plusOne') //mybuggysign
  var rectHeight = timeline_height/patients.length

  var arbtoday = new Date(), arbtomorrow = new Date()
      arbtomorrow.setDate(arbtoday.getDate()+1)
  var defaultRange = [arbtoday, arbtomorrow],
      dateRange = util.getDateRangeOnExtent(d3.extent(newDateRange), selectedExtent, defaultRange)

  //scale
  var gantt_x = d3.scaleTime().domain(dateRange).range([0, timeline_width]),
      gantt_y = d3.scalePoint().domain(patients).range([0, timeline_height])

  //axis-scale
  var gantt_xAxis = d3.axisBottom().scale(gantt_x),
      gantt_grid_daily = d3.axisTop().scale(gantt_x).ticks(d3.timeDay.every(1)).tickSize([timeline_height]),
      gantt_grid_weekly = d3.axisTop().scale(gantt_x).ticks(d3.timeWeek.every(1)).tickSize([timeline_height]),
      gantt_grid_monthly = d3.axisTop().scale(gantt_x).ticks(d3.timeMonth.every(1)).tickSize([timeline_height]),
      gantt_yAxis = d3.axisLeft(gantt_y).tickFormat("").tickSize(0)

  //SVG root
  var container = d3.select(faux),
      svg = container.append('svg')
                     .attr('id', 'ganttSVG')
                     .attr('width', timeline_width + margin.left + margin.right)
                     .attr('height', timeline_height + margin.top + margin.bottom)
  //clipping mask
  var svgGroupRoot = svg.append('g').attr('id', 'gantt_svgGroupRoot')
                        .attr('transform', 'translate(' + margin.left + ',' + margin.top + ')')
      svgGroupRoot.append("defs")
                  .append("clipPath")
                  .attr("id", "gantt_clipPath")
                  .append("rect")
                  .attr("width", timeline_width)
                  .attr("height", timeline_height)

  //tooltips
  var tooltipID = 'gantt',
      tooltip_container = container.append('div')
                                       .attr('id', tooltipID)
                                       .classed('tooltip', true)
  //rectangles
  var rectGroup = svgGroupRoot.append("g")
                              .attr('class', 'rectGroup')
                              .attr("clip-path", "url(#gantt_clipPath)")
      rectGroup.selectAll(".gantt_rect")
             .data(metadata)
             .enter().append("rect")
             .attr('class', 'gantt_rect')
             .attr('id', (d) => {return 'gantt_rect'+d.entryID })
             .attr('x', (d) => {return gantt_x(d.dateIn)})
             .attr('y', (d) => {return gantt_y(d.patID)})
             .attr('width', (d) => {return gantt_x(d.dateOut) - gantt_x(d.dateIn)})
             .attr('height', rectHeight)
             .attr('stroke-width', '2')
             .attr('stroke-dasharray', '5,3')
             .attr('stroke', 'none')
             .style("fill", (d) => {return color_user[d.entryID]})
             .style('visibility', () => {return !collectionTimeline ? 'visible' : 'hidden'})

  //axis (X)
  svgGroupRoot.append('g').attr('id', 'gAxisX')
                 .attr("transform", "translate(0," + timeline_height + ")")
                 .call(gantt_xAxis);
  //axis-lable (Y)
  svgGroupRoot.append("g").selectAll(".yAxis_label")
             .data(patients).enter().append('text')
             .attr('class', 'yAxis_label')
             .text((d) => {if (d !== undefined && d !== 'plusOne') {return d}})
             .attr('x', -3)
             .attr('y', function(d) {if (d !== undefined) {return gantt_y(d)+(rectHeight/2)}})
             .attr('text-anchor', 'end')
             .attr('font-size', '0.7em')

  //sampling date: circles
  rectGroup.selectAll(".gantt_sampling_circle")
            .data(metadata)
            .enter().append("circle")
            .attr('class', 'gantt_sampling_circle')
            .attr('cx', (d) => {return d.samplingDate ? gantt_x(d.samplingDate) : -10 })
            .attr('cy', (d) => {return d.samplingDate ? gantt_y(d.patID) + rectHeight/2 : -10 })
            .attr('r', rectHeight/4)
            .style("fill", (d) => {return color_user[d.entryID]})
            .style("stroke", "black")
            .style("stroke-width", '2px')
            .style('visibility', (d) => { return !d.samplingDate ? 'hidden' : 'visible'})
            .style('cursor', 'move')
            .on('mouseover', (d) => {showTooltip('#'+tooltipID, d)})
            .on('mouseout', (d) => {hideTooltip('#'+tooltipID)})
            .on('click', (d) => {selectActiveData({selectedData: [d], selectedExtent: undefined})})
  //grid
  switch (this.state.gridType) {
    case 'daily':
      svgGroupRoot.append('g').attr('id', 'gAxisGrid')
                .attr("transform", "translate(0," + timeline_height + ")")
                .attr('class', 'w3-axis')
                .call(gantt_grid_daily)
      break;
    case 'weekly':
      svgGroupRoot.append('g').attr('id', 'gAxisGrid')
                .attr("transform", "translate(0," + timeline_height + ")")
                .attr('class', 'w3-axis')
                .call(gantt_grid_weekly)
      break;
    case 'monthly':
      svgGroupRoot.append('g').attr('id', 'gAxisGrid')
                .attr("transform", "translate(0," + timeline_height + ")")
                .attr('class', 'w3-axis')
                .call(gantt_grid_monthly)
      break;
    default:
    //draw nothing
  }

   //Local-tooltips function
   function showTooltip(tooltipID, data) {

   }

   function hideTooltip(tooltipID) {

   }

   //update grid attribute state
   this.setState({gridAtt:{height: timeline_height,
                           width: timeline_width,
                           dateRange: dateRange}})

  drawFauxDOM()
}

<div id='gridType' className= "w3-container w3-row w3-margin-top w3-margin-bottom">
  <div className='w3-col s10'>
    <label>Timescale grid</label>
    <select value={this.state.gridType} onChange={this.changeGridType} className="w3-select" name="option">
      <option value="null">No Grid</option>
      <option value="daily">Daily</option>
      <option value="weekly">Weekly</option>
      <option value="monthly">Monthly</option>
    </select>
  </div>
</div>
*/

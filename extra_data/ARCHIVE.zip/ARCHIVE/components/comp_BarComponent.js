import React, {Component} from 'react'
import {PanelHeader} from '../utils/styled'
import CloseChart from '../containers/cont_CloseChart'
import BarViewer from './comp_BarViewer'

//props from container: dataset: Map(metadata,etc)
class BarComponent extends Component {
  render() {
    if (this.props.height !== 0 && this.props.width !== 0 && this.props.metadata !== null) {
      return (
        <div style={{width: '100%', height: '100%'}} >
          <BarViewer height={this.props.height}
                      width={this.props.width}
                      metadata={this.props.metadata}
                      colorIndex={this.props.colorIndex}
                      selectedData={this.props.selectedData}
            ></BarViewer>
        </div>
      )
    }
    else {
      return (
        <div style={{width: '100%', height: '100%'}}>
          <PanelHeader className='panelHeader'>
            <div className='panelTitle'>Epidemic Curve</div>
            <CloseChart id='bar'/>
          </PanelHeader>
        </div>
      )
    }
  }
}

export default BarComponent

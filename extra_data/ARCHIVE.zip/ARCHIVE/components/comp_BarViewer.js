//Module epidemic curve
import React, {Component} from 'react'
import {withFauxDOM} from 'react-faux-dom'
import {event as d3Event} from 'd3';
import DownloadSVG from './component/btn_downloadSVG'
import CloseChart from '../containers/cont_CloseChart'
import {PanelTitle} from './component/btn_utils'
const d3 = {
  ...require('d3-array'),
  ...require('d3-scale'),
  ...require('d3-axis'),
  ...require('d3-drag'),
  ...require('d3-selection'),
  ...require('d3-time-format'),
  ...require('d3-force')
}
//
class BarViewer extends Component {
  constructor(props){
    super(props)

  this.initiateBar = this.initiateBar.bind(this)
  this.reDraw = this.reDraw.bind(this)

  }

  componentDidMount(){
    this.initiateBar()
  }

  componentDidUpdate(prevProps, prevState){
    if ( this.props.width !== prevProps.width &&
          this.props.height !== prevProps.height) {
          // remove
          //d3.select('#simulatedMapSVG').remove()
          //d3.select('#simMap_refreshDescriptor').classed('w3-show', true)
    }
    else if (this.props.colorIndex !== prevProps.colorIndex) {
      this.reDraw()
    }
  }

  render() {
    //<DownloadSVG id='ganttSVG'/>
    const {barViewer: barViewer} = this.props
    return (
      <div id='barEpiCurve' className= 'w3-row'>

        <div id="barEpiCurveHandle" className= 'panelHeader w3-row w3-dark-grey'>
          <PanelTitle titleText={"Epidemic Curve"}></PanelTitle>
          <div id="barEpiCurve_setting" className= 'w3-col m6 w3-right'>
            <CloseChart id='bar'/>
              <div id='refreshButton' className='w3-right'>
              <button onClick={this.reDraw}
                      className="w3-button w3-medium w3-hover-none">
                      <i className="fa fa-refresh fa-lg"></i>
              </button>
            </div>
          </div>
        </div>

        <div className= 'w3-center' id= 'barViewer'>
          <h6 id='bar_refreshDescriptor'
             className='w3-hide'>
             Redraw chart using reload button on the top right corner of this window
           </h6>
            {barViewer}
        </div>
      </div>
    )
  }

  initiateBar(){
    const margin = {'top': 10, 'right': 20, 'bottom': 20, 'left': 10},
                  {metadata, height, width, connectFauxDOM, drawFauxDOM} = this.props,
                  bar_width = width - margin.left - margin.right,
                  bar_height = height - margin.top - margin.bottom - 80,
                  faux = connectFauxDOM('div', 'barViewer')

    var container = d3.select(faux),
        descriptor = container.append('div'),
        html =  "This module is under development"

    descriptor.html(html)
    .style("display", 'block')
    .style('position', 'absolute')
    .style('background-color', 'lightgreen')
    .style('padding', '5px 5px')
    .style('font-size', '12px')


    drawFauxDOM()
  }

  reDraw(){
    //d3.select('#simulatedMapSVG').remove()
    //d3.select('#simMap_refreshDescriptor').classed('w3-show', false)
    this.initiateBar()
  }
}


export default withFauxDOM(BarViewer)

import React, {Component} from 'react'
import ColorViewer from './comp_ColorViewer'

//props from container: dataset: Map(metadata,etc)
class ColorComponent extends Component {
  render() {
    if (this.props.height !== 0 && this.props.width !== 0 && this.props.metadata !== null) {
      return (
        <div style={{width: '100%', height: '100%'}} >
          <ColorViewer  height={this.props.height}
                        width={this.props.width}
                        metadata={this.props.metadata}
                        userColor={this.props.userColor}
                        colorIndex={this.props.colorIndex}
                        changeColorIndex={this.props.changeColorIndex}
                        patientColor={this.props.patientColor}
                        siteColor={this.props.siteColor}/>
        </div>
      )
    }
    else {
      return (
      <div style={{width: '100%', height: '100%'}}>
        <h4>Loading..</h4>
      </div>
      )
    }
  }
}
//
export default ColorComponent

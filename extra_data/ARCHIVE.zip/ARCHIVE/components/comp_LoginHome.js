import React, {Component} from 'react'
import SelectShowcaseDataset from '../containers/cont_SelectShowcaseDataset'
import InputFile from './comp_inputFiles'

class LoginHome extends Component {
  constructor(props){
    super(props)
    this.state = {uName: null,
                  pwd: null}

    this.changeUname = this.changeUname.bind(this)
    this.changePwd = this.changePwd.bind(this)
    this.getIn = this.getIn.bind(this)

  }

  shouldComponentUpdate(nextProps, nextStates){
    if (nextStates.uName !== this.state.uName ||
        nextStates.pwd !== this.state.pwd ) {
      return false;
    }
    else {
      return true;
    }
  }

  showDocumentation(){
    document.getElementById('documentation').style.display='block'
  }
  closeDocumentation(){
    document.getElementById('documentation').style.display='none'
  }
  changeUname(e){
    var value = e.target.value
    if (value) {
      this.setState({uName:value})
    }
  }
  changePwd(e){
    var value = e.target.value
    if (value) {
      this.setState({pwd:value})
    }
  }

  getIn(){
    if (this.state.uName === 'admin' && this.state.pwd === 'beatson143a') {
      var state = true
      this.props.updateLoginState(state)
    }
  }

  render() {
    return (
      <div id='loginHome' className="w3-content w3-center">
          <div className="w3-container w3-content w3-padding-32" style={{maxWidth:'700px'}} >
            <h1 className="w3-wide">HAIviz v.0.2</h1>
            <h4 className="w3-opacity"><i>Healthcare Associated Infections Visualization Tool</i></h4>
            <p className="w3-center">An easy to use and interactive single page application for visualizing and integrating information of genomic epidemiology of Healthcare Associated Infection (HAI).</p>
          </div>
          <hr></hr>
          <div className="w3-row w3-content w3-padding-bottom" style={{maxWidth:'600px'}}>
            <h4>Development Demo</h4>
            <div className="w3-col s12">
              <input onChange={this.changeUname} className="w3-input" type="text" placeholder="Enter Username" name="uname" required></input>
            </div>
            <div className="w3-col s12">
              <br></br>
              <input onChange={this.changePwd} className="w3-input" type="password" placeholder="Enter Password" name="psw" required></input>
            </div>
            <br></br>
            <div className="w3-col s12">
              <button onClick={this.getIn} className="w3-button w3-green" type="submit">Login</button>
            </div>
          </div>
          <hr></hr>
          <footer className="w3-center w3-small w3-white w3-padding-16 ">

            <p>HAIviz v.0.2 | {new Date().getFullYear()}
              <br/> Developed by Budi Permana at <a href="http://beatsonlab.com" target="_blank" className="w3-hover-text-green">Beatson Lab</a>
              <br/> The University of Queensland | Australia
            </p>
          </footer>
        </div>

    )
  }

}


export default LoginHome

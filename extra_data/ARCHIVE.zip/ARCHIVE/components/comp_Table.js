import React, {Component} from 'react'
import TableChart from './comp_TableViewer'
import withMeasure from '../hocs/withMeasure';

const dimensions = ['width', 'height'],
      MeasuredInfoBox = withMeasure(['width', 'height'])(TableChart)

class ComponentTable extends Component {
  render(){
    return (
      <div style={{width: '100%', height: '100%'}} >
        <MeasuredInfoBox metadata={this.props.metadata}
                        selectedData={this.props.selectedData}/>
      </div>
    )
  }
}

export default ComponentTable
//

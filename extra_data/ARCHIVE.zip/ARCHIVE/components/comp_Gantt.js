import React, {Component} from 'react'
import GanttChart from './comp_GanttChart'
import withMeasure from '../hocs/withMeasure';
import styled from 'styled-components'

const dimensions = ['width', 'height']
const MeasuredGantt = withMeasure(dimensions)(GanttChart)

class ComponentGantt extends Component {
  constructor(props){
    super(props)
  }
  render(){
    //console.log("comp GanttChart")
    return (
      <MeasuredGantt dateRange={this.props.dateRange}
                     metadata={this.props.metadata}
                     siteColor={this.props.siteColor}
                     clickedElement={this.props.clickedElement}
                     loadData={this.props.loadData}
                     updateClickedElement={this.props.updateClickedElement}/>
    )
  }
}

export default ComponentGantt

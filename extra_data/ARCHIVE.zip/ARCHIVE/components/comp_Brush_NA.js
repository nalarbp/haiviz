import React, {Component} from 'react'
import BrushChart from './comp_BrushChart'
import withMeasure from '../hocs/withMeasure';
const dimensions = ['width', 'height']
const MeasuredBrush = withMeasure(dimensions)(BrushChart)


class ComponentBrush extends Component {
  constructor(props){
    super(props)
  }
  render(){
    //console.log('xx-RDR BRUSH');
    return (
      <div style={{width: '100%', height: '100%'}} >
        <MeasuredBrush
           metadata={this.props.metadata}
           siteColor={this.props.siteColor}
           selectActiveData={this.props.selectActiveData}
        ></MeasuredBrush>
      </div>
    )
  }
}

export default ComponentBrush

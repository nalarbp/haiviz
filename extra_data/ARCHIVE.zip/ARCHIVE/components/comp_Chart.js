import React, { Component } from 'react';
import * as d3 from 'd3'
import {withFauxDOM} from 'react-faux-dom'

class Chart extends Component {
  //props: data, setHover
  constructor(props){
    super(props)

  }


  render() {
    return (
      <div style={{width: '100%', height: '100%'}}>
        {this.props.chart}
      </div>
    );
  }

}

Chart.defaultProps = {
  chart: ''
}

export default withFauxDOM(Chart)

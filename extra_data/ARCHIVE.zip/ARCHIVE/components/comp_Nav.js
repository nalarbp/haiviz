import React, {Component} from 'react';
import logo from '../img/logo.png';
import styled from 'styled-components';
import domToImage from 'dom-to-image';
import FileSaver from 'file-saver';
import * as util from '../utils/utils';
const d3 = {
  ...require('d3-selection')
}

const Menu = styled.div`
  width: 100%;

  .menu_footer {
    width: 80px;
    font-size: 9px;
    color: lightgray;
    text-align: center;
    position: fixed;
    bottom: 0;
    margin: auto 10px;
  }
  .menu_logo{
    width: 80px;;
    height: 80px;
    margin: 10px auto 20px auto;
  }

  .menu_items{
    width: 50px;
    margin: 5px auto 5px auto;

    ul li {
      list-style: none;
      margin-top: 1em;

    }
  }

  .menu_level{
    width: 30px;
    font-size: 9px;
    float: right;
    margin-bottom: 15px;
    border-style: none;

    ul li{
      list-style: none;


    }
  }

`;

class FloorplanLevelButton extends Component{
  // setActivePanel, levelID
  //
  constructor(props){
    super(props)
    this.setActiveFloorplan = this.setActiveFloorplan.bind(this)
  }

  setActiveFloorplan() {
    //console.log(this.props);
    let activeFloorplanLevel = this.props.levelID
    this.props.setActivePanel(activeFloorplanLevel)
  }

  render(){
    let level = this.props.levelID.split('_')
    return(
    <button className="w3-round" onClick={this.setActiveFloorplan}>
      {level[1]}
    </button>

    )

  }
}

class NavButton extends Component{
  constructor(props){
    super(props)
    //props: icon, buttonID, setActivePanel, all data input
    this.setActivePanel = this.setActivePanel.bind(this)
    this.buttonClicked = this.buttonClicked.bind(this)
    this.floorplanToogle = this.floorplanToogle.bind(this)
    this.renderFloorplanLevel = this.renderFloorplanLevel.bind(this)
  }


  setActivePanel() {
    let activeChart = this.props.buttonID
    this.props.setActivePanel(activeChart)
  }

  buttonClicked() {
    //buttonID : floorplan_1, 2 etc
    //if data loaded, setActivePanel
    //else alert to input data
    var buttonID = this.props.buttonID.split('_')
    switch (buttonID[0]) {
      case 'gantt':
        if (this.props.metadata) {
          this.setActivePanel()
        }
        else {
          alert('Please input metadata file')
        }
        break;
      case 'floorplan':
        if (this.props.floorplan) {

          //console.log(this.props.floorplan);
          this.setActivePanel()
        }
        else {
          alert('Please input floorplan file')
        }
        break;
      case 'tree':
        if (this.props.tree) {
          this.setActivePanel()
        }
        else {
          alert('Please input tree file')
        }
        break;
      case 'transmission':
        if (this.props.transmission) {
          this.setActivePanel()
        }
        else {
          alert('Please input transmission file')
        }
        break;
      case 'simulatedMap':
        if (this.props.metadata) {
          this.setActivePanel()
        }
        else {
          alert('Please input metadata file')
        }
        break;
      case 'overlappingTable':
        if (this.props.metadata) {
          this.setActivePanel()
        }
        else {
          alert('Please input metadata file')
        }
        break;
      case 'ukulele':
        if (this.props.metadata) {
          this.setActivePanel()
        }
        else {
          alert('Please input metadata file')
        }
        break;
      case 'table':
        if (this.props.metadata) {
          this.setActivePanel()
        }
        else {
          alert('Please input metadata file')
        }
        break;
      case 'bar':
        if (this.props.metadata) {
          this.setActivePanel()
        }
        else {
          alert('Please input metadata file')
        }
        break;
      case 'downloadVis':
        if (this.props.metadata || this.props.floorplan ||
            this.props.tree || this.props.transmission ) {
          //get DOM node, download it
          var node = document.getElementById('dashboard');
          domToImage.toBlob(document.getElementById('dashboard'))
                    .then(function(blob) {
                      //console.log(blob);
                      FileSaver.saveAs(blob, 'HAIviz_report.png')
                    });
        }
        else {
          alert('Please input a file')
        }
        break;
      default:
    }
  }

  floorplanToogle() {
    if (this.props.floorplan) {
      var x = document.getElementById('floorplanList');
      if (x.className.indexOf("w3-show") == -1) {
          x.className += " w3-show";
      } else {
          x.className = x.className.replace(" w3-show", "");
      }
    }
    else {
      alert('Please input floorplan file')
    }
  }

  renderFloorplanLevel() {
    var self = this
    var floorplanLevel = []
    for (var key in this.props.activeChart) {
      let buttonID = key.split('_')
      if (buttonID[1] && !this.props.activeChart[key].show) {
         floorplanLevel.push(key)
       }
    }


    return floorplanLevel.map(function(d) {
      return <li key={d}>
        <FloorplanLevelButton  setActivePanel={self.props.setActivePanel}
                              levelID={d}/>
      </li>
    })

  }

  getNavIcon(){

  }
  render(){
        let buttonID = this.props.buttonID.split('_')
        //console.log(this.props);
        if (buttonID.length === 1 && buttonID[0] === 'floorplan') {
          //FLOORPLAN LIST/TOGGLE
          return (
            <div>
              <button title={this.props.title}
                    onClick={this.floorplanToogle}
                    style={{border: 'none', backgroundColor: '#303030'}}>
                    <img src={this.props.icon}></img>
              </button>

              <div id="floorplanList" className="w3-hide menu_level">
                <ul>
                  {this.renderFloorplanLevel()}
                </ul>
              </div>
            </div>

          )
        }
        else if (buttonID[0] === 'floorplan' && buttonID.length >= 1) {
          //FLOORPLAN BUTTON TOP
          return (
            <div></div>
          )
        }
        else {
          //REGULAR BUTTON
          return(
            <button title={this.props.title} onClick={this.buttonClicked} style={{border: 'none', backgroundColor: '#303030'}}>
              <img src={this.props.icon}></img>
            </button>
          )

        }


  }
}


class Nav extends Component {
  constructor(props){
    super(props)
    this.renderNav = this.renderNav.bind(this)
  }

  componentDidUpdate(prevState){

    //process the floorplan
    if (this.props.floorplan !== prevState.floorplan) {
      //call action to add activeChart
      var newActiveChart = JSON.parse(JSON.stringify(this.props.activeChart))
      var levels = []
      // convert all feature.properties.level into a list []
      var features = this.props.floorplan.features
      features.forEach(function(d) {
        //Check if they have properties.level
        if (d.properties.hasOwnProperty('level')) {
          var level_str = String(d.properties.level)
          var level_list = level_str.split(',')
          //to the list
           //conver to integer
           for (var i = 0; i < level_list.length; i++) {
             if (level_list[i]) {
               level_list[i] = parseInt(level_list[i])
             } else {
               level_list[i] = undefined
             }
           }
         d.properties.level = level_list
         levels = levels.concat(d.properties.level)
        }
        else {
          d.properties['level'] = [1]
          levels = levels.concat(d.properties.level)
        }
      })
      levels = levels.filter(util.filterUnique)
      //console.log(levels);

      var additionalLayout = []
      levels.forEach(function(d) {
        let layoutKey = 'floorplan_'+d
        let layout = {i: layoutKey, x: 0, y: 0, w: 12, h: 20, minW:6, minH:10}
        additionalLayout.push(layout)
        //add active chart list
        newActiveChart[layoutKey] = {'show': false}
      })

      //call action to set layout
      var newLayout = []
      this.props.layout.forEach(function(d) {
        newLayout.push(d)
      })
      newLayout = newLayout.concat(additionalLayout)
      this.props.setLayout(newLayout)
      this.props.addFloorplan(newActiveChart)
      //console.log(newLayout, newActiveChart);

    }
    //======
  }

  renderNav(){
    var self = this
    var stateNav = this.props.activeChart
    var activeNav = []
    for (var key in stateNav) {
      if (key !== 'idxCol' && !stateNav[key].show) {activeNav.push(key)}
    }

    return activeNav.map(function(d) {
      return <li key={d}>
        <NavButton  setActivePanel={self.props.setActiveChart}
                    metadata={self.props.metadata}
                    activeChart={self.props.activeChart}
                    floorplan={self.props.floorplan}
                    transmission={self.props.transmission}
                    tree={self.props.tree}
                    buttonID={d}
                    title={util.getButtonTitle(d)}
                    icon={util.getIcon(d, self.props.metadata, self.props.floorplan, self.props.tree, self.props.transmission)}
                    floorplanLevel={self.props.floorplanLevel}/>
      </li>
    })
  }

  render(){
    //console.log('@@RENDER Comp_Nav');
    return (
      <Menu>
        <div className='menu_logo'>
          <img src={logo} width='100%' ></img>
        </div>
        <div className='menu_items'>
          <ul>
            {this.renderNav()}
          </ul>
        </div>
        <div className='menu_footer'>
        </div>

      </Menu>
    )
  }
}

export default Nav
//<img src={logo} alt='Logo'></img>

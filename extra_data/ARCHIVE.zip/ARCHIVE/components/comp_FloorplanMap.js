import React, {Component} from 'react'
import {withFauxDOM} from 'react-faux-dom'
import * as util from '../utils/utils'
import {PanelHeader} from '../utils/styled'
import DownloadSVG from './component/btn_downloadSVG'
import CloseChart from '../containers/cont_CloseChart'
import {event as currentEvent} from 'd3';
const d3 = {
  ...require('d3-geo'),
  ...require('d3-array'),
  ...require('d3-scale'),
  ...require('d3-axis'),
  ...require('d3-zoom'),
  ...require('d3-drag'),
  ...require('d3-selection'),
  ...require('d3-time-format'),
  ...require('d3-force')
}

// props from container: floorplan
class FloorplanMap extends Component {
  constructor(props){
    super(props)
  this.renderD3= this.renderD3.bind(this)
  this.renderMapOnly = this.renderMapOnly.bind(this)
  }

  componentDidUpdate(prevProps, prevState){
    //when user provide metadata
    if (this.props.metadata && this.props.floorplan) {
      if (this.props.floorplan && this.props.floorplan !== prevProps.floorplan) {

        this.updateD3()
      }
      //when window's dimensions changed
      else if (this.props.floorplan &&
              this.props.width !== prevProps.width &&
              this.props.height !== prevProps.height) {
        this.updateD3()
      }
      //when brushing
      else if (this.props.filteredEntryID !== null &&
        this.props.filteredEntryID !== prevProps.filteredEntryID) {
        this.updateNodes(this.props.filteredEntryID)
      }
      //when circle clicked
      else if (this.props.clickedElement !== null &&
        this.props.clickedElement !== prevProps.clickedElement ) {
        this.updateClickedNodes(this.props.clickedElement)
      }
    }

    //when user dont upload metadata
    else {
      if (this.props.floorplan && this.props.floorplan !== prevProps.floorplan) {
        this.updateMapOnly()
      }
      else if (this.props.floorplan && this.props.width !== prevProps.width &&
                this.props.height !== prevProps.height) {
        this.updateMapOnly()
      }
    }
  }

  render() {
    const {chart: chart} = this.props
    return (
      <div style={{width: '100%', height: '100%'}}>
        <PanelHeader className='panelHeader'>
          <div className='panelTitle'>{this.props.levelID}</div>
          <CloseChart id={this.props.levelID}/>
          <DownloadSVG svgID="floorplanSVG"/>
        </PanelHeader>
        {chart}
      </div>
    )
  }

  renderMapOnly(){

    const {width, height, connectFauxDOM, animateFauxDOM} = this.props
    const margin = {'top': 10, 'right': 10, 'bottom': 50, 'left': 10}
    const geojson = this.props.floorplan
    const map_width = width - margin.left - margin.right
    const map_height = height- margin.top - margin.bottom - 60

    var zoomLevel = 1
    var dragStartX, dragStartY, isMouseDown, dragTimeStamp
    var translateX = margin.left
    var translateY = margin.top

    const faux = connectFauxDOM('div', 'chart')
    const mapProjection = d3.geoMercator()
                      .fitExtent([[0, 0], [map_width, map_height]], geojson);

    const path = d3.geoPath().projection(mapProjection)


    // Filtering the level
    var floorplanLevel = +this.props.levelID.split('_')[1]
    function filterLevel(level) {
      return function(feature) {
        return feature.properties.level.indexOf(level) !== -1
      }
    }

    var level = JSON.parse(JSON.stringify(geojson))
    level.features = level.features.filter(filterLevel(floorplanLevel))

    var container = d3.select(faux)
    var transformFloorplanID = 'transform'+this.props.levelID

    //reset zoom and loation
    d3.select('#'+transformFloorplanID)
    .attr('transform', 'translate(' + margin.left + ',' + margin.top + ') scale(1)')

    //make svg root
    var svg = container.append('svg').attr('id', 'floorplanSVG')
                .attr('width', map_width + margin.left + margin.right)
                .attr('height', map_height + margin.top + margin.bottom)
    var g = svg.append('g')
                .attr('id', transformFloorplanID)
                .attr('transform', 'translate(' + margin.left + ',' + margin.top + ') scale(1)')

    //add site label
    g.append('g').selectAll('.map_siteLabel')
                    .data(level.features)
                    .enter()
                    .append('text')
                    .attr('class', 'map_siteLabel')
                    .text( d => d.properties.name)
                    .attr('x', function(d) {return path.centroid(d)[0]})
                    .attr('y', function(d) {return path.centroid(d)[1]})
                    .attr('fill', 'black')
                    .attr('text-anchor', 'middle')
                    .attr('font-size', '8pt')

    //create map from path
    //console.log(path(level))

    g.append('g').selectAll('.pathD')
                    .data([0])
                    .enter()
                    .append('path')
                    .attr('class', 'pathD')
                    .attr('d', path(level))
                    .attr('fill', 'transparent')
                    .attr('stroke-width', '1px')
                    .attr('stroke', 'black');

    // Event: zoom
    svg.on('wheel.zoom', function() {
      if (currentEvent.deltaY > 0 && zoomLevel < 4 ) {
        //var initial = floorplanZoomLevel + 0.2
        zoomLevel += 0.15
        //updateFloorplanZoomLevel(num)
        zoomed('#'+transformFloorplanID, zoomLevel)
      }
      else if (currentEvent.deltaY < 0 && zoomLevel > 0.2 ) {
        //var reducedLevel = floorplanZoomLevel - 0.2
        zoomLevel -= 0.15
        //updateFloorplanZoomLevel(num)
        zoomed('#'+transformFloorplanID, zoomLevel)
      }
    })

    // Event: drag
    svg.on('mousedown', function() {
      isMouseDown = true
      dragStartX = currentEvent.screenX
      dragStartY = currentEvent.screenY})
        .on('mousemove', function() {
          if (isMouseDown) {
            var deltaTimeStamp = currentEvent.timeStamp - dragTimeStamp
            if (dragTimeStamp && deltaTimeStamp > 10) {
              var deltaX = currentEvent.screenX - dragStartX
              var deltaY = currentEvent.screenY - dragStartY
              dragTimeStamp = currentEvent.timeStamp
              dragged('#'+transformFloorplanID, deltaX, deltaY, zoomLevel)
            }
            else {
              dragTimeStamp = currentEvent.timeStamp
            }
          }
        })
        .on('mouseup', function() {
          isMouseDown = false
        })

    //Litener: zoomed
    function zoomed(transformID, newLevel) {
        d3.select(transformID)
          .attr('transform', 'translate(' + translateX + ',' + translateY + ') scale(' + newLevel + ')')
      }
    //Listener: dragged
    function dragged(transformID, deltaX, deltaY, currentZoomLevel) {
      translateX += deltaX*0.1
      translateY += deltaY*0.1
      d3.select(transformID)
        .attr('transform', 'translate(' + translateX + ',' + translateY + ') scale(' + currentZoomLevel + ')')
      }

    //call the faux-dom but iterate the didupdate step
    animateFauxDOM(50)

  }
  renderD3(){
    const {updateClickedElement,
           siteColor, chart, width, height, connectFauxDOM,
           animateFauxDOM} = this.props
    const margin = {'top': 10, 'right': 10, 'bottom': 50, 'left': 10}
    const geojson = this.props.floorplan
    var metadata = this.props.metadata
    const map_width = width - margin.left - margin.right
    const map_height = height- margin.top - margin.bottom - 60


    var zoomLevel = 1
    var dragStartX, dragStartY, isMouseDown, dragTimeStamp
    var translateX = margin.left
    var translateY = margin.top

    const formatTime = d3.timeFormat("%d %B, %Y")
    const faux = connectFauxDOM('div', 'chart')
    const mapProjection = d3.geoMercator()
                      .fitExtent([[0, 0], [map_width, map_height]], geojson);

    const path = d3.geoPath().projection(mapProjection)

    // Filtering the level
    var floorplanLevel = +this.props.levelID.split('_')[1]
    function filterLevel(level) {
      return function(feature) {
        return feature.properties.level.indexOf(level) !== -1
      }
    }

    var level = JSON.parse(JSON.stringify(geojson))
    level.features = level.features.filter(filterLevel(floorplanLevel))

    var container = d3.select(faux)
    var tooltipID = 'tooltip'+this.props.levelID
    var transformFloorplanID = 'transform'+this.props.levelID

    //reset zoom and loation
    d3.select('#'+transformFloorplanID)
    .attr('transform', 'translate(' + margin.left + ',' + margin.top + ') scale(1)')


    //make tooltip
    var tooltip = container.append('div')
                            .attr('id', tooltipID)
                            .classed('tooltip', true)


    //make svg root
    var svg = container.append('svg').attr('id', 'floorplanSVG')
                .attr('width', map_width + margin.left + margin.right)
                .attr('height', map_height + margin.top + margin.bottom)
    var g = svg.append('g')
                .attr('id', transformFloorplanID)
                .attr('transform', 'translate(' + margin.left + ',' + margin.top + ') scale(1)')


    //add site label
    g.append('g').selectAll('.map_siteLabel')
                    .data(level.features)
                    .enter()
                    .append('text')
                    .attr('class', 'map_siteLabel')
                    .text( d => d.properties.name)
                    .attr('x', function(d) {return path.centroid(d)[0]})
                    .attr('y', function(d) {return path.centroid(d)[1]})
                    .attr('fill', 'black')
                    .attr('text-anchor', 'middle')
                    .attr('font-size', '8pt')

    //create map from path
    g.append('g').selectAll('.pathD')
                    .data([0])
                    .enter()
                    //.append('path').attr('class', 'pathD')
                    //.attr('d', path(level))
                    //.attr('fill', 'transparent')
                    //.attr('stroke-width', '1px')
                    //.attr('stroke', 'black');

    //spread out circle!
    d3.forceSimulation(metadata)
                .force('charge', d3.forceManyBody().strength(0.1))
                .force('collide', d3.forceCollide().radius(6).strength(0.5))
                .on('tick', ticked);

    metadata.forEach(function(d) {
        d.x = util.getXfromPath(d.siteID, geojson.features, path)
        d.y = util.getYfromPath(d.siteID, geojson.features, path)
      });

    //make circle nodes
    var nodeGroup = g.append('g').attr('class', 'nodeGroup')
    var circles = nodeGroup.selectAll('.map_nodes')
                    .data(metadata.filter(d => d.siteLevel === floorplanLevel))
                    .enter() //filter the metadata only at the floorplan
                    .append('circle')
                    .attr('class', 'map_nodes')
                    .attr('r', 5)
                    .attr('opacity', '0.8')
                    .style('fill', function(d) {return siteColor[d.siteID]})
                    .on('click', function(d) {updateClickedElement(d.entryID)})
                    .on('mouseover', function(d) {
                      //console.log(currentEvent);
                      util.showTooltip('#'+tooltipID, d,
                      currentEvent.offsetX, currentEvent.offsetY, 'floorplan')
                    })
                    .on('mouseout', function(d) {
                      util.hideTooltip('#'+tooltipID)
                    })

    function ticked() {
      //console.log('+++TICKED');
        circles.attr("cx", function(d){return d.x;})
            .attr("cy", function(d){ return d.y;})
        }

    // Event: zoom
    svg.on('wheel.zoom', function() {
      if (currentEvent.deltaY > 0 && zoomLevel < 4 ) {
        //var initial = floorplanZoomLevel + 0.2
        zoomLevel += 0.15
        //updateFloorplanZoomLevel(num)
        zoomed('#'+transformFloorplanID, zoomLevel)
      }
      else if (currentEvent.deltaY < 0 && zoomLevel > 0.2 ) {
        //var reducedLevel = floorplanZoomLevel - 0.2
        zoomLevel -= 0.15
        //updateFloorplanZoomLevel(num)
        zoomed('#'+transformFloorplanID, zoomLevel)
      }
    })

    // Event: drag
    svg.on('mousedown', function() {
      isMouseDown = true
      dragStartX = currentEvent.screenX
      dragStartY = currentEvent.screenY})
        .on('mousemove', function() {
          if (isMouseDown) {
            var deltaTimeStamp = currentEvent.timeStamp - dragTimeStamp
            if (dragTimeStamp && deltaTimeStamp > 10) {
              var deltaX = currentEvent.screenX - dragStartX
              var deltaY = currentEvent.screenY - dragStartY
              dragTimeStamp = currentEvent.timeStamp
              dragged('#'+transformFloorplanID, deltaX, deltaY, zoomLevel)
            }
            else {
              dragTimeStamp = currentEvent.timeStamp
            }
          }
        })
        .on('mouseup', function() {
          isMouseDown = false
        })

    //Litener: zoomed
    function zoomed(transformID, newLevel) {
        d3.select(transformID)
          .attr('transform', 'translate(' + translateX + ',' + translateY + ') scale(' + newLevel + ')')
      }
    //Listener: dragged
    function dragged(transformID, deltaX, deltaY, currentZoomLevel) {
      translateX += deltaX*0.1
      translateY += deltaY*0.1
      d3.select(transformID)
        .attr('transform', 'translate(' + translateX + ',' + translateY + ') scale(' + currentZoomLevel + ')')
      }
    //call animate withFauxDOM
    animateFauxDOM(100)

  }

  updateD3(){
    const faux = this.props.connectFauxDOM('div', 'chart')
    d3.select(faux).select('#floorplanSVG').remove()
    d3.select(faux).select('#floorplanTooltip').remove()
    this.renderD3()
  }

  updateMapOnly(){
    const faux = this.props.connectFauxDOM('div', 'chart')
    d3.select(faux).select('svg').remove()
    d3.select(faux).selectAll('#textSize_controller').remove()
    this.renderMapOnly()
  }

  updateNodes(filteredEntryID){
    var floorplanLevel = +this.props.levelID.split('_')[1]
    const faux = this.props.connectFauxDOM('div', 'chart')
    d3.select(faux)
      .selectAll('circle.map_nodes')
      .transition().duration(100)
      .attr('r', function (d) {
        if (filteredEntryID.indexOf(d.entryID) !== -1 && d.siteLevel === floorplanLevel) {return 5}
        else {return 0}
      })

      this.props.animateFauxDOM(100)
  }

  updateClickedNodes(entryID){
    var floorplanLevel = +this.props.levelID.split('_')[1]
    const faux = this.props.connectFauxDOM('div', 'chart')
    d3.select(faux)
      .selectAll('circle')
      .attr('r', function (d) {
        if (d.entryID === entryID && d.siteLevel === floorplanLevel) {return 10}
        else if (d.siteLevel === floorplanLevel) {return 5}
        else {return 0}
      })
      this.props.animateFauxDOM(50)
  }
}

export default withFauxDOM(FloorplanMap)

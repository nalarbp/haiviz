import React, {Component} from 'react';
//import {blob, csv, json, text} from 'd3-fetch';
//import * as util from '../utils/utils'
import DownloadSessionIcon from '../img/downloadSession.png';
import UploadSessionIcon from '../img/uploadSession.png';
//import TreeIcon_inactive from '../img/inactive_tree.png';
//import TransmissionIcon_inactive from '../img/inactive_transmission.png';
import FileSaver from 'file-saver';

const d3 = {
  ...require('d3-selection'),
  ...require('d3-scale'),
  ...require('d3-time-format')
}
//
class DownloadUploadSession extends Component{
  constructor(props){
    //props: metadata, floorplan, trans, tree, upload method
    super(props)
    this.onChange = this.onChange.bind(this)
    this.downloadSession = this.downloadSession.bind(this)
  }

  onChange(e){
    console.log('session change');
  }

  downloadSession(){
    //console.log(this.props);
    //var sessionFile = JSON.stringify(this.props)
    var sessionFile = JSON.stringify(this.props)
    //console.log(sessionFile);
  }


  render(){
    //console.log(this.props);
    return(
      <div className="w3-row w3-content w3-padding-bottom" style={{maxWidth:'600px'}}>
        <div className="w3-col m6 s12">
          <button id="downloadSession" onClick={this.downloadSession} style={{display: 'none'}} />
          <label
            className='w3-button w3-round w3-hover-lightgray'
            htmlFor={'downloadSession'} >
            <img
              src={DownloadSessionIcon}
              style={{width:"40%"}}
              className="w3-hover-opacity" />
            <br/>
            <p>Download</p>
          </label>

        </div>

        <div className="w3-col m6 s12">
          <input type="file"
                 accept={'.haiviz'}
                 id={'uploadSession'}
                 style={{display: 'none'}}
                 onChange={this.onChange}/>
          <label
            className='w3-button w3-round w3-hover-lightgray'
            htmlFor={'uploadSession'} >
            <img
              src={UploadSessionIcon}
              style={{width:"40%"}}
              className="w3-hover-opacity" />
            <br/>
            <p>Upload</p>
          </label>

        </div>

      </div>
    )
  }
}
export default DownloadUploadSession;

import React, {Component} from 'react'
import {withFauxDOM} from 'react-faux-dom'
import {PanelHeader} from '../utils/styled'
import DownloadSVG from './component/btn_downloadSVG'
import CloseChart from '../containers/cont_CloseChart'
import TimelineViewer from './comp_TimelineViewer'
const d3 = {
  ...require('d3-array'),
  ...require('d3-scale'),
  ...require('d3-axis'),
  ...require('d3-time'),
  ...require('d3-selection')
}
//
class TimelineComponent extends Component {
  render() {
    if (this.props.height !== 0 && this.props.width !== 0 && this.props.metadata !== null) {
        return (
          <div style={{width: '100%', height: '100%'}}>
            <TimelineViewer height={this.props.height}
                        width={this.props.width}
                        selectActiveData={this.props.selectActiveData}
                        metadata={this.props.metadata}
                        dateRange_init={this.props.dateRange_init}
                        patients_init={this.props.patients_init}
                        colorIndex={this.props.colorIndex}
                        selectedData={this.props.selectedData.selectedData}
                        selectedExtent={this.props.selectedData.selectedExtent}
              ></TimelineViewer>
          </div>
        )
      }
      else {
        // n-th render
        return (
          <div style={{width: '100%', height: '100%'}}>
            <PanelHeader className='panelHeader'>
              <div className='panelTitle'>Timeline</div>
              <CloseChart id='gantt'/>
            </PanelHeader>
          </div>
        )
      }
  }
}

export default TimelineComponent

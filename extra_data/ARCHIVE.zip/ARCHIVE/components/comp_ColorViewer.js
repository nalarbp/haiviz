import React, {Component} from 'react'
import {withFauxDOM} from 'react-faux-dom'
import * as util from '../utils/utils'
import DownloadSVG from './component/btn_downloadSVG'
import CloseChart from '../containers/cont_CloseChart'
import {PanelTitle} from './component/btn_utils'

const d3 = {
  ...require('d3-array'),
  ...require('d3-scale'),
  ...require('d3-axis'),
  ...require('d3-time-format'),
  ...require('d3-selection')
}

class ColourViewer extends Component {
  constructor(props){
    super(props)

    this.initiateColorIndex= this.initiateColorIndex.bind(this)
    this.reDrawColorIndex= this.reDrawColorIndex.bind(this)
    this.onSelected= this.onSelected.bind(this)
  }

  componentDidMount(){
    this.initiateColorIndex()
  }
//
  componentDidUpdate(prevProps, prevState){

    if (this.props.height !== prevProps.height &&
        this.props.width !== prevProps.width) {
        d3.select('#colourContainer').remove()
    }
    else if (this.props.colorIndex !== prevProps.colorIndex) {
      this.reDrawColorIndex()
    }

  }
  //when user select color index
  onSelected(e){
    if (e.target.value !== 'null') {
      var sel = e.target.value
      switch (sel) {
        case 'user':
          this.props.changeColorIndex({type: 'user', color: this.props.userColor})
          break;
        case 'patient':
          this.props.changeColorIndex({type: 'patient', color: this.props.patientColor})
          break;
        case 'location':
          this.props.changeColorIndex({type: 'location', color: this.props.siteColor})
          break;
        default:
          //do nothing
      }
    }
    else {
      // do nothing
    }
  }

  render() {
    const {colorIndexViewer: colorIndexViewer} = this.props
    return (
      <div id='colorIndex' className= 'w3-row'>
        <div id="colIdxHandle" className= 'panelHeader w3-row w3-dark-grey'>
          <PanelTitle titleText={"Colors"}></PanelTitle>
          <div className= 'w3-col m6 w3-right'>
            <DownloadSVG id='SVGColourChart'/>
            <div id='refreshButton' className='w3-col m4 w3-right'>
              <button onClick={this.reDrawColorIndex}
                      className="w3-button w3-medium w3-hover-none">
                      <i className="fa fa-refresh fa-lg"></i>
              </button>
            </div>
          </div>
        </div>

        <div id='colIdx_option' className='w3-container w3-margin'>
            <select className="w3-select" onChange={this.onSelected} name="option">
              <option value="null">Select Color</option>
              <option value="user">Based on color group</option>
              <option value="patient">Based on patients</option>
              <option value="location">Based on locations</option>
            </select>
        </div>

        <div id= 'timelineViewer' className= 'w3-light-gray w3-col m12'>
        {colorIndexViewer}
        </div>
      </div>
    )
  }

  initiateColorIndex(){

    const margin = {'top': 10, 'right': 5, 'bottom': 10, 'left': 10}
    const {siteColor, clickedElement, width, height, connectFauxDOM, drawFauxDOM, metadata} = this.props
    const faux = connectFauxDOM('div', 'colorIndexViewer')

    var colorIdx = this.props.colorIndex.color,
        colourList = Object.keys(colorIdx),
        chart_width = width - margin.left - margin.right,
        chart_height = height - margin.top - margin.bottom - 140

    //console.log(colorIdx, colourList);

    colourList.sort((a, b) => d3.ascending(a, b))

    var scale_y = d3.scaleBand()
                    .domain(colourList)
                    .range([0, chart_height])
                    .padding(0.01)

    var yAxis = d3.axisLeft(scale_y)
                  .tickSize(0)

    var colourContainer = d3.select(faux)
                          .append('div').attr('id', 'colourContainer')

    //svg: vis containter
    var svg = colourContainer.append('svg').attr('id', 'SVGColourChart')
                  .attr('width', chart_width + margin.left + margin.right)
                  .attr('height', chart_height + margin.top + margin.bottom + 40)

    var svgGroupRoot = svg.append('g')
                          .attr('transform', 'translate(' + margin.left + ',' + margin.top + ')')
    //color bar
    svgGroupRoot.selectAll(".colour_bar")
                .data(colourList).enter()
                .append('rect').attr('class', 'colour_bar')
                .attr('y', function(d) {return scale_y(d)})
                .attr('x', function(d) {return 2})
                .attr('height', scale_y.bandwidth)
                .attr('width', function(d) {return 10})
                .attr('fill', function(d) {
                  return colorIdx[d]
                })
    //color label text
    svgGroupRoot.append('g').attr('id', 'gAxisY')
                .attr("transform", "translate(0," + 0 + ")")
                .call(yAxis)
                .call(g => g.select(".domain").remove())
                .selectAll("text")
                .style("text-anchor", "start")
                .style("font-size", "10px")
                .attr("dx", "2em")
                .attr("dy", "0em")
                //.attr("transform", "rotate(315)");

    drawFauxDOM()
  }

  reDrawColorIndex(){
    d3.select('#colourContainer').remove()
    this.initiateColorIndex()
  }
}


export default withFauxDOM(ColourViewer)

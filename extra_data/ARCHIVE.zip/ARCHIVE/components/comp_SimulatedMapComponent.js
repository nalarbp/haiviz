import React, {Component} from 'react'
import {PanelHeader} from '../utils/styled'
//import DownloadSVG from './component/btn_downloadSVG'
import CloseChart from '../containers/cont_CloseChart'
import SimulatedMapViewer from './comp_SimulatedMapViewer'

class SimulatedMapComponent extends Component {
  render() {
    if (this.props.height !== 0 && this.props.width !== 0 && this.props.metadata !== null) {
      return (
        <div style={{width: '100%', height: '100%'}} >
          <SimulatedMapViewer height={this.props.height}
                      width={this.props.width}
                      metadata={this.props.metadata}
                      transmission={this.props.transmission}
                      colorIndex={this.props.colorIndex}
                      selectActiveData={this.props.selectActiveData}
                      selectedData={this.props.selectedData}
            ></SimulatedMapViewer>
        </div>
      )
    }
    else {
      return (
        <div style={{width: '100%', height: '100%'}}>
          <PanelHeader className='panelHeader'>
            <div className='panelTitle'>Simulated Map</div>
            <CloseChart id='simulatedMap'/>
          </PanelHeader>
        </div>
      )
    }
  }
}

export default SimulatedMapComponent

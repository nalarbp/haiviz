//Module tree viewer: tree only
import React, { Component } from "react";
import { withFauxDOM } from "react-faux-dom";
import newickParse from "../utils/newick";
import * as util from "../utils/utils";
import CloseChart from "../containers/cont_CloseChart";
import DownloadSVG from "./component/btn_downloadSVG";
import { PanelTitle } from "./component/btn_utils";
import { event as d3Event } from "d3";
const d3 = {
  ...require("d3-hierarchy"),
  ...require("d3-array"),
  ...require("d3-scale"),
  ...require("d3-axis"),
  ...require("d3-drag"),
  ...require("d3-shape"),
  ...require("d3-selection")
};
/////re-render when props changed. Props come from treeContainer's state
class TreeViewer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      nodeSize: 5,
      labelSize: 5,
      scaleFactor: 1,
      currentbranchLength: null,
      customScale: 1
    };

    this.initiateTree = this.initiateTree.bind(this);
    this.redrawTree = this.redrawTree.bind(this);

    this.changeNodeSize = this.changeNodeSize.bind(this);
    this.updateNodeSize = this.updateNodeSize.bind(this);

    this.changeLabelSize = this.changeLabelSize.bind(this);
    this.updateLabelSize = this.updateLabelSize.bind(this);

    this.changeScaleFactor = this.changeScaleFactor.bind(this);
    this.changeCustomScale = this.changeCustomScale.bind(this);

    this.updateScale = this.updateScale.bind(this);
    this.updateTreeBySelectedData = this.updateTreeBySelectedData.bind(this);

    this.openSetting = this.openSetting.bind(this);
    this.closeSetting = this.closeSetting.bind(this);
  }
  //
  componentDidMount() {
    this.initiateTree();
  }

  shouldComponentUpdate(nextProps, nextStates) {
    if (nextStates.nodeSize !== this.state.nodeSize) {
      this.updateNodeSize(nextStates.nodeSize);
      return false;
    } else if (nextStates.labelSize !== this.state.labelSize) {
      this.updateLabelSize(nextStates.labelSize);
      return false;
    } else if (
      nextStates.scaleFactor !== this.state.scaleFactor ||
      nextStates.customScale !== this.state.customScale ||
      nextStates.currentbranchLength !== this.state.currentbranchLength
    ) {
      return false;
    } else {
      return true;
    }
  }
  componentDidUpdate(prevProps, prevState) {
    if (
      this.props.selectedData !== prevProps.selectedData ||
      this.props.selectedExtent !== prevProps.selectedExtent
    ) {
      this.updateTreeBySelectedData();
    } else if (
      this.props.width !== prevProps.width &&
      this.props.height !== prevProps.height
    ) {
      d3.select("#treeSVG").remove();
      d3.select("#tree_refreshDescriptor").classed("w3-show", true);
    } else if (this.props.colorIndex !== prevProps.colorIndex) {
      this.redrawTree();
    }
  }
  //event listener node size
  changeNodeSize(e) {
    var value = e.target.value;
    if (value) {
      this.setState({ nodeSize: value });
    }
  }
  updateNodeSize(value) {
    d3.selectAll(".tree_nodeCircle").attr("r", function(d) {
      return value;
    });
  }

  //event listener node size
  changeLabelSize(e) {
    var value = e.target.value;
    if (value) {
      this.setState({ labelSize: value });
    }
  }
  updateLabelSize(value) {
    d3.selectAll(".tree_nodeLabel").attr("font-size", function(d) {
      return value + "px";
    });
  }
  //event listener for scale factor
  changeScaleFactor(e) {
    var value = e.target.value;
    if (value) {
      this.setState({ scaleFactor: value });
    }
  }

  changeCustomScale(e) {
    var value = e.target.value;
    if (value) {
      this.setState({ customScale: value });
    }
  }

  updateScale() {
    //
    var margin = { top: 10, right: 50, bottom: 20, left: 20 },
      { height, width } = this.props,
      tree_height = height - 40 - margin.top - margin.bottom,
      tree_width = width - margin.left - margin.right,
      branchLength = this.state.currentbranchLength,
      newBranchLength = branchLength * this.state.scaleFactor,
      newScale = parseInt(this.state.customScale, 10),
      y_scale = d3
        .scaleLinear()
        .domain([0, newBranchLength])
        .range([0, tree_width - 50]);

    d3.select("#tree_scale_line").attr("x2", function() {
      return y_scale(newScale);
    });
    d3.select("#tree_scale_text").text(function() {
      return newScale;
    });
  }

  updateTreeBySelectedData() {
    var { connectFauxDOM, drawFauxDOM, colorIndex } = this.props,
      nodeSizeState = this.state.nodeSize,
      faux = connectFauxDOM("div", "treeViewer"),
      container = d3.select(faux);

    if (
      this.props.selectedData &&
      this.props.selectedExtent &&
      this.props.selectedExtent.length !== 0
    ) {
      var dateExtent = this.props.selectedExtent,
        selectedEntryIDs = this.props.selectedData.map(function(d) {
          return d.entryID;
        });

      container
        .selectAll(".tree_nodeCircle")
        .attr("r", function(d) {
          if (
            selectedEntryIDs.indexOf(d.meta.entryID) !== -1 &&
            d.meta.samplingDate < dateExtent[1] &&
            d.meta.samplingDate > dateExtent[0]
          ) {
            return 2 * nodeSizeState;
          } else {
            return nodeSizeState;
          }
        })
        .attr("fill", function(d) {
          if (
            selectedEntryIDs.indexOf(d.meta.entryID) !== -1 &&
            d.meta.samplingDate < dateExtent[1] &&
            d.meta.samplingDate > dateExtent[0]
          ) {
            return util.fillWithColorIndex(d.meta, colorIndex);
          } else {
            return "lightgray";
          }
        });
    } else if (this.props.selectedData) {
      var selectedEntryIDs = this.props.selectedData.map(function(d) {
        return d.entryID;
      });
      container
        .selectAll(".tree_nodeCircle")
        .attr("r", function(d) {
          if (selectedEntryIDs.indexOf(d.meta.entryID) !== -1) {
            return 2 * nodeSizeState;
          } else {
            return nodeSizeState;
          }
        })
        .attr("fill", function(d) {
          return util.fillWithColorIndex(d.meta, colorIndex);

          //if (selectedEntryIDs.indexOf(d.meta.entryID) !== -1) {
          // return util.fillWithColorIndex(d.meta, colorIndex)
          // } else {
          //   return 'lightgray'
          //}
        });
    } else {
      //do nothing
    }
    drawFauxDOM();
  }

  openSetting() {
    var el = document.getElementById("TreeController");
    el.className = "w3-sidebar w3-border-bottom w3-show-block";
    el.style = "height:auto;right:0";
  }

  closeSetting() {
    document.getElementById("TreeController").className = "w3-hide";
  }

  redrawTree() {
    d3.select("#treeSVG").remove();
    d3.select("#tree_refreshDescriptor").classed("w3-show", false);
    this.initiateTree();
  }

  render() {
    const { treeViewer: treeViewer } = this.props;
    return (
      //produce only tree viewer PanelTitle is 6 column
      <div id="tree" className="w3-row">
        <div className="panelHeader w3-row w3-dark-grey">
          <PanelTitle titleText={"Phylogenetic Tree"}></PanelTitle>
          <div
            id="tree_setting"
            className="w3-col m6 w3-padding-small  w3-right"
          >
            <CloseChart id="tree" />
            <DownloadSVG id="treeSVG" />
            <div id="settingButton" className="w3-right">
              <button
                onClick={this.openSetting}
                className="w3-button w3-medium w3-hover-none"
              >
                <i className="fa fa-wrench fa-lg"></i>
              </button>
            </div>
            <div id="refreshButton" className="w3-right">
              <button
                onClick={this.redrawTree}
                className="w3-button w3-medium w3-hover-none"
              >
                <i className="fa fa-refresh fa-lg"></i>
              </button>
            </div>
          </div>
        </div>

        <div
          id="TreeController"
          className="w3-sidebar w3-border-right w3-behind w3-hide"
        >
          <div className="w3-right">
            <button
              onClick={this.closeSetting}
              className="w3-button w3-medium w3-hover-none"
            >
              <i className="fa fa-times-circle fa-lg"></i>
            </button>
          </div>
          <div
            id="nodeSize"
            className="w3-container w3-margin-top w3-margin-bottom"
          >
            <label>Node size</label>
            <input
              onChange={this.changeNodeSize}
              type="range"
              min="0"
              max="10"
              className="w3-input w3-border"
            ></input>
          </div>
          <div id="labelSize" className="w3-container w3-margin-bottom">
            <label>Label size</label>
            <input
              onChange={this.changeLabelSize}
              type="range"
              min="5"
              max="20"
              className="w3-input w3-border"
            ></input>
          </div>
          <div id="scaleFactor" className="w3-container">
            <label>Scale factor</label>
            <input
              onChange={this.changeScaleFactor}
              type="number"
              min="1"
              className="w3-input w3-border"
            ></input>
          </div>
          <div id="customScale" className="w3-container">
            <label>Custom scale</label>
            <input
              onChange={this.changeCustomScale}
              type="number"
              min="1"
              className="w3-input w3-border"
            ></input>
          </div>
          <div
            id="submitScale"
            className="w3-container w3-margin-top w3-margin-bottom"
          >
            <button
              onClick={this.updateScale}
              className="w3-button w3-round w3-green"
            >
              Change scale
            </button>
          </div>
        </div>

        <div
          id="tree_tooltip"
          className="w3-container w3-small w3-white w3-row"
        >
          <div id="tooltip_info_icon" className="w3-text-white w3-col s1">
            <p>
              .<i className="fa fa-info-circle fa-lg w3-text-black"></i>
            </p>
          </div>
          <div id="tree_tooltip_text" className="w3-col s11 w3-text-left">
            <p></p>
          </div>
        </div>

        <div id="treeSVGviewer" className="w3-center">
          <h6 id="tree_refreshDescriptor" className="w3-hide">
            Redraw chart using reload button on the top right corner of this
            window
          </h6>
          {treeViewer}
        </div>
      </div>
    );
  }

  initiateTree() {
    //var dummyNewickData = '(Bovine:0.69395,(Hylobates:0.36079,(Pongo:0.33636,(G._Gorilla:0.17147, (P._paniscus:0.19268,H._sapiens:0.11927):0.08386):0.06124):0.15057):0.54939, Rodent:1.21460);'
    var margin = { top: 10, right: 50, bottom: 20, left: 20 },
      {
        metadata,
        colorIndex,
        selectActiveData,
        selectedData,
        tree,
        height,
        width,
        connectFauxDOM,
        drawFauxDOM
      } = this.props,
      tree_height = height - 80 - margin.top - margin.bottom,
      tree_width = width - margin.left - margin.right,
      treeJSON = newickParse(tree),
      faux = connectFauxDOM("div", "treeViewer"),
      tooltipID = "tree_tooltip_text",
      root = d3.hierarchy(treeJSON, d => d.branchset),
      clusterLayout = d3.cluster().size([tree_height - 50, tree_width]);
    clusterLayout(root);

    var nodes = root.descendants(),
      links = root.links(),
      treeHasLength = util.isTreeHasLength(nodes);

    //reposition the leaf nodes
    var branchLengthRange = nodes.map(function(d) {
        if (treeHasLength) {
          return util.hasParrent(d);
        }
      }),
      treeBranchLenExtent = d3.extent(branchLengthRange),
      treeBranchDepthExtent = d3.extent(
        nodes.map(function(d) {
          return d.depth;
        })
      ),
      branchLength = treeHasLength
        ? treeBranchLenExtent
        : treeBranchDepthExtent,
      y_scale = d3
        .scaleLinear()
        .domain([0, branchLength[1]])
        .range([0, tree_width - 50]);

    this.setState({ currentbranchLength: branchLength[1] });

    //console.log(treeBranchLenExtent);
    //console.log(nodes);
    nodes.forEach(function(d) {
      let name = d.data.name;
      d["meta"] = util.getMetadataFromNodeName(name, metadata);
      //console.log(d.meta);

      if (treeHasLength) {
        d.y = y_scale(util.hasParrent(d));
      } else {
        d.y = y_scale(d.depth);
      }
    });

    var y_axis = d3
      .axisBottom()
      .scale(y_scale)
      .ticks();

    var tree_container = d3.select(faux);

    d3.select("#svgGroup_tree").attr(
      "transform",
      "translate(" + margin.left + "," + margin.top + ") scale(1)"
    );

    var svg = tree_container
      .append("svg")
      .attr("id", "treeSVG")
      .attr("width", tree_width + margin.right)
      .attr("height", tree_height + margin.bottom);

    var svgGroup = svg
      .append("g")
      .attr("id", "svgGroup_tree")
      .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

    //draw links
    svgGroup
      .append("g")
      .selectAll(".tree_link")
      .data(links)
      .enter()
      .append("path")
      .attr("class", "tree_link")
      .attr("d", d => util.tree_pathGenerator(d))
      .attr("stroke", "black")
      .attr("fill", "none");

    //draw nodes
    svgGroup
      .append("g")
      .attr("id", "nodeGroup")
      .selectAll("g.node")
      .data(nodes)
      .enter()
      .append("g")
      .attr("class", function(n) {
        if (n.children) {
          if (n.depth === 0) {
            return "tree_root node";
          } else {
            return "tree_inner node";
          }
        } else {
          return "tree_leaf node";
        }
      })
      .attr("transform", function(d) {
        return "translate(" + d.y + "," + d.x + ")";
      });

    //draw leaf node (black circle)
    svgGroup
      .selectAll("g.tree_leaf.node")
      .append("circle")
      .attr("class", "tree_nodeCircle")
      .attr("r", this.state.nodeSize)
      .attr("fill", function(d) {
        if (d.meta) {
          return util.fillWithColorIndex(d.meta, colorIndex);
        } else {
          return "black";
        }
      })
      .attr("stroke", "black")
      .attr("stroke-width", "2px")
      .style("cursor", "move")
      .on("mouseover", function(d) {
        if (d.meta) {
          showTooltip("#" + tooltipID, d);
        }
      })
      .on("mouseout", function(d) {
        hideTooltip("#" + tooltipID);
      })
      .on("click", function(d) {
        if (d.meta) {
          var activeData = [d.meta];
          selectActiveData({
            selectedData: activeData,
            selectedExtent: undefined
          });
        }
      });

    //draw internal node (black circle)
    svgGroup
      .selectAll("g.tree_inner.node")
      .append("circle")
      .attr("class", "tree_innerNodeCircle")
      .attr("r", 3)
      .attr("fill", "black")
      .style("cursor", "move")
      .on("click", function(d) {
        var activeData = util.getDatafromChildren(d.leaves());
        selectActiveData({
          selectedData: activeData,
          selectedExtent: undefined
        });
      });

    //draw label
    svgGroup
      .selectAll("g.tree_leaf.node")
      .append("text")
      .attr("class", "tree_nodeLabel")
      .attr("dx", 12)
      .attr("dy", 3)
      .attr("text-anchor", "start")
      .attr("font-size", "10px")
      .attr("fill", "black")
      .text(d => d.data.name);

    //draw scale line
    var scaleGroup = svgGroup.append("g").attr("id", "treeScaleGroup");
    //scale line
    scaleGroup
      .append("g")
      .attr("transform", "translate(0," + (tree_height - 30) + ")")
      .append("line")
      .attr("id", "tree_scale_line")
      .attr("x1", 0)
      .attr("y1", 0)
      .attr("x2", function() {
        return y_scale(Math.ceil(0.25 * branchLength[1]));
      })
      .attr("y2", 0)
      .attr("stroke", "black");
    //scale text
    scaleGroup
      .append("g")
      .attr("transform", "translate(0," + (tree_height - 10) + ")")
      .append("text")
      .attr("id", "tree_scale_text")
      .attr("x", 0)
      .attr("y", 0)
      .attr("font-size", "12px")
      .text(function() {
        return Math.ceil(0.25 * branchLength[1]);
      });

    //tooltip_local
    function showTooltip(tooltipID, data) {
      if (data.meta) {
        var tooltip = d3
          .select(tooltipID)
          .html(
            '<p id="tree_tooltip_content" >' +
              "Host: " +
              data.meta.patID +
              "<span>&nbsp&nbsp&nbsp&nbsp</span>" +
              "Location: " +
              data.meta.siteID +
              "</p>"
          );
      } else {
        var tooltip = d3
          .select(tooltipID)
          .html(
            '<p id="tree_tooltip_content" >' +
              "Host: " +
              "<span>&nbsp&nbsp&nbsp&nbsp</span>" +
              "Location: " +
              "</p>"
          );
      }
    }

    function hideTooltip(tooltipID) {
      d3.select("#tree_tooltip_content").remove();
    }
    drawFauxDOM();
  }
}

export default withFauxDOM(TreeViewer);

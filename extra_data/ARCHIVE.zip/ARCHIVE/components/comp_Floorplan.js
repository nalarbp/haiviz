import React, {Component} from 'react'
import FloorplanMap from './comp_FloorplanMap'
import withMeasure from '../hocs/withMeasure';

const dimensions = ['width', 'height']
const MeasuredFloorplan = withMeasure(dimensions)(FloorplanMap)



//props from container: dataset: Map(metadata,etc)
class FloorplanComponent extends Component {
  render(){
    //console.log('@@', this.props.floorplanDragLocationX);
    return (
      <div style={{width: '100%', height: '100%'}} >
        <MeasuredFloorplan metadata={this.props.metadata}
                           levelID={this.props.levelID}
                           floorplan={this.props.floorplan}
                           filteredEntryID={this.props.filteredEntryID}
                           siteColor={this.props.siteColor}
                           clickedElement={this.props.clickedElement}
                           updateClickedElement={this.props.updateClickedElement}
                           loadData={this.props.loadData}/>
      </div>
    )
  }
}

export default FloorplanComponent
//

import React, {Component} from 'react'
import {withFauxDOM} from 'react-faux-dom'
import * as util from '../utils/utils'
import newickParse from '../utils/newick';
import {PanelHeader} from '../utils/styled'
import ZoomController from './component/btn_zoomController'
import DownloadSVG from './component/btn_downloadSVG'
import UploadFile from './component/btn_uploadFile'
import CloseChart from '../containers/cont_CloseChart'
import {event as d3Event} from 'd3'
const d3 = {
  ...require('d3-hierarchy'),
  ...require('d3-array'),
  ...require('d3-axis'),
  ...require('d3-drag'),
  ...require('d3-shape'),
  ...require('d3-selection')
}

class TreeComponent extends Component {
  constructor(props) {
    super(props)
    this.state = {treeType:'null',
                  nodeLabel: true,
                  nodeLableSize: 10,
                  nodeSize: 1}
  }
}


//as container
class TreeComponentContainer extends Component {
  constructor(props) {
    super(props)

  }

  render(){
    return (
      <div className="w3-gray" style={{width: '100%', height: '100%'}}>
        <PanelHeader className='panelHeader'>
          <div className='panelTitle'>Phylogenetic tree</div>
          <CloseChart id='tree'/>
          <DownloadSVG svgID="treeSVG"/>
        </PanelHeader>
        <TreeComponent>

        </TreeComponent>
      </div>
    )
  }
}

export default TreeComponentContainer

/* OLD version
import React, {Component} from 'react'
import TreeChart from './comp_TreeChart'
import withMeasure from '../hocs/withMeasure';

const dimensions = ['width', 'height']
const MeasuredTree = withMeasure(dimensions)(TreeChart)



//props from container: dataset: Map(metadata,etc)
class ComponentTree extends Component {
  render(){
    return (
      <div style={{width: '100%', height: '100%'}} >
        <MeasuredTree metadata={this.props.metadata}
                      tree={this.props.tree}
                      filteredEntryID={this.props.filteredEntryID}
                      siteColor={this.props.siteColor}
                      updateClickedElement={this.props.updateClickedElement}
                      clickedElement={this.props.clickedElement}
                      updateZoomLevel={this.props.updateTreeZoomLevel}
                      zoomLevel={this.props.zoomLevel}
                      loadData={this.props.loadData}/>
      </div>
    )
  }
}

export default ComponentTree
*/

import React, {Component} from 'react'
import {withFauxDOM} from 'react-faux-dom'
import {PanelHeader} from '../utils/styled'
import CloseChart from '../containers/cont_CloseChart'
import * as util from '../utils/utils'

const d3 = {
  ...require('d3-array'),
  ...require('d3-scale'),
  ...require('d3-axis'),
  ...require('d3-time-format'),
  ...require('d3-time'),
  ...require('d3-selection')
}
// props from container: metadata
class BarChart extends Component {
  constructor(props){
    super(props)
    this.renderD3= this.renderD3.bind(this)
    this.updateD3= this.updateD3.bind(this)
  }

  componentDidUpdate(prevProps, prevState){
    if (this.props.height !== prevProps.height) {
        this.updateD3()
    }
  }

  render() {
    const {chart: chart} = this.props
    return (
      <div style={{width: '100%', height: '100%'}}>
        <PanelHeader className='panelHeader'>
          <div className='panelTitle'>Sample Bar Chart</div>
          <CloseChart id='bar'/>
        </PanelHeader>
        {chart}
      </div>
    )
  }

  renderD3(){
    const {siteColor, updateClickedElement, width, height, connectFauxDOM, animateFauxDOM, metadata} = this.props
      ,faux = connectFauxDOM('div', 'chart')
      ,panelHeaderHeight = 40
      ,isPerWeek = true
      ,chartContainer_height = (height - panelHeaderHeight)*0.85
      ,controllerContainer_height = (height - panelHeaderHeight) - chartContainer_height
      ,chart_margin = {'top': 10, 'right': 20, 'bottom': 50, 'left': 50}
      ,chart_width = width - chart_margin.left - chart_margin.right - 20
      ,chart_height = chartContainer_height - chart_margin.top - chart_margin.bottom

    // get the samplingDates
    var samplingDates = metadata.map(function(d) {if (d.samplingDate !== 'N/A') {return new Date(d.samplingDate)}})
    //root container
    var wrapper = d3.select(faux)
                  .append('div').attr('id', 'chartWrapper')
                  .style('height', height-40 +'px')
                  .style('width', width+'px')
                  //.style('background-color', 'lightgray')
                  //bar container
    var chartContainer = wrapper.append('div').attr('id', 'chartContainer')
                          .style('height', chartContainer_height+'px')
                          .style('width', width+'px')
                          //.style('background-color', 'gray')
                          //controller container
    var chartController = wrapper.append('div').attr('id', 'chartController')
                          .style('height', controllerContainer_height+'px')
                          .style('padding-left', '50px')

    var activeChart = 'week'
    if (activeChart === 'week') {
      renderWeek(samplingDates, chart_width, chart_height, chart_margin, chartContainer)
    }



    function renderWeek(samplingDates, chart_width, chart_height, chart_margin, chartContainer) {
      var samplingDateRange = d3.extent(samplingDates)

      var firstWeek = d3.timeMonday(samplingDateRange[0])
      var weekRange = samplingDateRange.map(function(d) {return d3.timeMonday.count(firstWeek, d) + 1})
      var weekCases = samplingDates.map(function(d) {
        //console.log(firstWeek, d)
        //console.log(d3.timeMonday.count(firstWeek, d))
        //console.log('====');
        if (d3.timeMonday.count(firstWeek, d) === undefined) {
          return undefined
          }
        else {
          return d3.timeMonday.count(firstWeek, d) + 1
          }
        }
      )
      //given a date and the first week, output which week are the date?
      // weekcase: in week 1
      var maxWeekCase = util.maxElFromArray(weekCases).maxCount
      var week_barW = chart_width / weekRange[1] - 5
      var weekDataset = util.weekRangeObj(weekCases)
      //console.log(weekDataset);
      var weekList = util.generateArrayFromRange(weekRange[0], weekRange[1])

      //logging
      //console.log(weekCases);
      //WEEK scaling
      var week_x = d3.scaleBand()
                      .domain(weekList)
                      .range([0, chart_width])
                      .padding(0.1)
      var week_y = d3.scaleLinear()
                      .domain([0, maxWeekCase])
                      .range([chart_height, 0])
      //WEEK Axis
      var week_xAxis = d3.axisBottom(week_x)
                          //.tickFormat(function(d) {return "Week "+d})
      var week_yAxis = d3.axisLeft(week_y)
      //DELETE Container
      //d3.select('#chartContainer').remove()
      //add svg
      var svg = chartContainer.append('svg').attr('id', 'SVGBarChart')
                    .attr('width', chart_width + chart_margin.left + chart_margin.right)
                    .attr('height', chart_height + chart_margin.top + chart_margin.bottom)

      //grouping
      var svgGroupRoot = svg.append('g')
                            .attr('transform', 'translate(' + chart_margin.left + ',' + chart_margin.top + ')')

      //add axis
      svgGroupRoot.append('g').attr('id', 'gAxisX')
                  .attr("transform", "translate(0," + chart_height + ")")
                  .call(week_xAxis)
                  .selectAll("text")
                  .style("text-anchor", "end")
                  .style("font-size", "10px")
                  .attr("dx", "-0.7em")
                  .attr("dy", "0em")
                  .attr("transform", "rotate(-65)");

      svgGroupRoot.append('g').attr('id', 'gAxisY')
                  .call(week_yAxis)
                  .selectAll("text")
                  .style("text-anchor", "end")
                  .style("font-size", "10px")
                  //.attr("transform", "translate(0," + chart_height + ")")

      //add bar each week
      svgGroupRoot.selectAll(".bar_rect_week")
                  .data(weekDataset).enter()
                  .append('rect').attr('class', 'bar_rect_week')
                  .attr('x', function(d) {return week_x(d.el)})
                  .attr('y', function(d) {return week_y(d.count)})
                  .attr('width', week_x.bandwidth)
                  .attr('height', function(d) {return chart_height - week_y(d.count)})
                  .attr('fill', '#1eb776')

      //add legend
      svgGroupRoot.append("text")
                    .attr("transform", "translate(" + ((chart_width + chart_margin.right +
                      chart_margin.left)/2) + " ," + (chart_height + (chart_margin.bottom/1.25)) + ")")
                    .style("text-anchor", "middle")
                    .style("font-size", "14px")
                    .text("Week "+"(1st week start from "+util.formatTime(firstWeek)+")")

      svgGroupRoot.append("text")
                    .attr("transform", "rotate(-90)")
                    .attr("y", 0 - chart_margin.left)
                    .attr("x",0 - (chart_height / 2))
                    .attr("dy", "1em")
                    .style("font-size", "12px")
                    .style("text-anchor", "end")
                    .text("Total isolate");

      animateFauxDOM(100)
    }
    function renderMonth(samplingDates, chart_width, chart_height, chart_margin, chartContainer) {
      var samplingDateRange = d3.extent(samplingDates)
      //================MONTH==========
      var firstDayOfMonth = d3.timeMonth(samplingDateRange[0])
      var monthRange = samplingDateRange.map(function(d) {
        return d3.timeMonth.count(firstDayOfMonth, d) + 1})
      var monthCases = samplingDates.map(function(d) {
        return d3.timeMonth.count(firstDayOfMonth, d) + 1
      })
      var maxMonthCase = util.maxElFromArray(monthCases).maxCount
      var monthDataset = util.weekRangeObj(monthCases)
      var monthList = util.generateArrayFromRange(monthRange[0], monthRange[1])

      //MONTH scaling
      var month_x = d3.scaleBand()
                      .domain(monthList)
                      .range([0, chart_width])
                      .padding(0.1)

      //console.log(maxMonthCase)

      var month_y = d3.scaleLinear()
                      .domain([0, maxMonthCase])
                      .range([chart_height, 0])

      //MONTH Axis
      var month_xAxis = d3.axisBottom(month_x)
                          //.tickFormat(function(d) {return "Week "+d})
      var month_yAxis = d3.axisLeft(month_y)

      //add svg
      var svg = chartContainer.append('svg').attr('id', 'SVGBarChart')
                    .attr('width', chart_width + chart_margin.left + chart_margin.right)
                    .attr('height', chart_height + chart_margin.top + chart_margin.bottom)

      //grouping
      var svgGroupRoot = svg.append('g')
                            .attr('transform', 'translate(' + chart_margin.left + ',' + chart_margin.top + ')')

      //add axis
      svgGroupRoot.append('g').attr('id', 'gAxisX')
                  .attr("transform", "translate(0," + chart_height + ")")
                  .call(month_xAxis)
                  .selectAll("text")
                  .style("text-anchor", "end")
                  .style("font-size", "10px")
                  .attr("dx", "-0.7em")
                  .attr("dy", "0em")
                  .attr("transform", "rotate(-65)");

      svgGroupRoot.append('g').attr('id', 'gAxisY')
                  .call(month_yAxis)
                  .selectAll("text")
                  .style("text-anchor", "end")
                  .style("font-size", "10px")
                  //.attr("transform", "translate(0," + chart_height + ")")

      //add bar each week
      svgGroupRoot.selectAll(".bar_rect_week")
                  .data(monthDataset).enter()
                  .append('rect').attr('class', 'bar_rect_week')
                  .attr('x', function(d) {return month_x(d.el)})
                  .attr('y', function(d) {return month_y(d.count)})
                  .attr('width', month_x.bandwidth)
                  .attr('height', function(d) {return chart_height - month_y(d.count)})
                  .attr('fill', '#1eb776')

      //add legend
      svgGroupRoot.append("text")
                    .attr("transform", "translate(" + ((chart_width + chart_margin.right +
                      chart_margin.left)/2) + " ," + (chart_height + (chart_margin.bottom/1.25)) + ")")
                    .style("text-anchor", "middle")
                    .style("font-size", "14px")
                    .text("Month "+"(1st month start from "+util.formatTime(firstDayOfMonth)+")")

      svgGroupRoot.append("text")
                    .attr("transform", "rotate(-90)")
                    .attr("y", 0 - chart_margin.left)
                    .attr("x",0 - (chart_height / 2))
                    .attr("dy", "1em")
                    .style("font-size", "12px")
                    .style("text-anchor", "end")
                    .text("Total isolate");

      animateFauxDOM(100)
    }

    //button by week
    chartController.append('button')
                    .classed('w3-button w3-green w3-round w3-hover-gray', true)
                    .text('Isolates by week').style('font-size', '10px')
                    .style('margin-right', '5px')
                    .on('click', function() {
                      if (activeChart === 'month') {
                        d3.select('svg#SVGBarChart').remove()
                        renderWeek(samplingDates, chart_width, chart_height, chart_margin, chartContainer)
                        activeChart = 'week'}
                    })
    //button by month
    chartController.append('button')
                    .classed('w3-button w3-green2 w3-round w3-hover-gray', true)
                    .text('Isolates by month').style('font-size', '10px')
                    .style('margin-right', '5px')
                    .on('click', function() {
                      if (activeChart === 'week') {
                        d3.select('svg#SVGBarChart').remove()
                        renderMonth(samplingDates, chart_width, chart_height, chart_margin, chartContainer)
                        activeChart = 'month'}
                    })


    //call animate withFauxDOM
    animateFauxDOM(100)
  }

  updateD3(){
    const faux = this.props.connectFauxDOM('div', 'chart')
    d3.select(faux).select('#chartWrapper').remove()
    this.renderD3()
  }

}


export default withFauxDOM(BarChart)

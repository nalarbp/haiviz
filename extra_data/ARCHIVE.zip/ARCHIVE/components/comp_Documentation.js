import React, {Component} from 'react'
import geojsonFormatImage from '../img/geojsonFormat.jpg';
//import tutorialVideo01 from '../files/tutorial_makeGeoJSON.mp4';

class Documentation extends Component {
  render() {
    return (
      <div style={{textAlign:'left'}}>
        <h3 style={{textAlign:'center'}}>Documentation</h3>
        <div>
          <h4>About</h4>
          <p>HAIviz is a single page application for visualizing epidemiological timeline, location, sample’s phylogenetic tree, and transmissions event.
            Users can use HAIviz to integrate and display these data interactively in a single dashboard visualization.
             <br/><br/>
             At the core of its technologies, HAIviz heavily utilizes Data Driven Document (D3.js)
             visualization library created by <a href="https://d3js.org/">Mike Bostock</a>.  It also uses several
             libraries such as <a href="https://github.com/jasondavies/newick.js/">Newick.js, </a>
             <a href="https://gist.github.com/kueda/1036776">d3.phylogram.js</a>, and
             <a href="https://www.w3schools.com/w3css/"> w3.css</a> before
             finally wrapped using <a href="https://reactjs.org/">React.js</a>.
           </p>
        </div>
        <hr></hr>

        <div>
          <h4>Input Files</h4>
          <p>
            HAIviz visualizes up to four input files: timeline metadata, map, phylogenetic tree, and transmission graph.
            Each file has their specification and format requirement (see Table below).
            Users can choose to load a single input to create an independent visualization window, or load the integrated one to generate multiple windows.
            The integrated inputs must be linked with a matched record within the files, such as when timeline and phylogenetic tree is linked by identical isolates IDs.
          </p>
          <p>Table 1. Specification for metadata input</p>
            <div style={{width:'80%', margin:'auto'}}>
              <table className="w3-table-all">
                <tbody>
                  <tr>
                    <th>Header</th>
                    <th>Description</th>
                  </tr>
                  <tr>
                    <td>entryID</td>
                    <td>The unique identifier (number) for each column. A duplicated id will produce an error. </td>
                  </tr>
                  <tr>
                    <td>siteID</td>
                    <td>The identifier/name/label for a site or location (i.e ICU_1)</td>
                  </tr>
                  <tr>
                    <td>siteLevel</td>
                    <td>Level of the room or location (number)</td>
                  </tr>
                  <tr>
                    <td>patID</td>
                    <td>Patient's identifier (i.e Patient_1)</td>
                  </tr>
                  <tr>
                    <td>dateIn</td>
                    <td>The date when the patient starts to stay in the site/room (date format mm/dd/yy) </td>
                  </tr>
                  <tr>
                    <td>dateOut</td>
                    <td>The date when the patient leave the site/room (date format mm/dd/yy)</td>
                  </tr>
                  <tr>
                    <td>samplingDate</td>
                    <td>The date when the isolate were taken from the patient/site (date format mm/dd/yy)</td>
                  </tr>
                  <tr>
                    <td>sampleID</td>
                    <td>Isolate's identifier </td>
                  </tr>
                </tbody>

              </table>
            </div>
            <br/><br/>
            The <span className='w3-tag'>floorplan panel</span> requires a building map encoded in a geographic
            data structures called geoJSON. Figure 1.1 shows how geoJSON stores
            the coordinates of Room_1 located at level 1. The feature object represents
            one coordinate (point location) or a collection of coordinates
            (polygonal location) with their attribute information stored in the
            properties object.
            <br/><br/>
            <div style={{width:'80%', margin:'auto'}}>
              <img src={geojsonFormatImage} className="w3-image" alt="geoJSON Format"></img>
            </div>
            The <span className='w3-tag'>tree panel</span> requires a phylogenetic tree represented in the Newick
            format (figure 1.2). And the <span className='w3-tag'>transmission panel</span> expects a parent-child
            relationship data structure written in CSV format.
            The pairwise relation between isolate (node) distinguished by a
            distance that in this case represented by numbers of Single Nucleotide Polymorphism (SNPs).
            An isolate which assumed the first case must be labeled as Index, and the parent of it is represented by null.
            The table below illustrates the pairwise relationship between the nodes.

            <br/><br/>
            <div style={{width:'50%', margin:'auto'}}>
              <table className="w3-table-all">
                <tbody>
                  <tr>
                    <th>isolateID</th>
                    <th>parent</th>
                    <th>snps</th>
                  </tr>
                  <tr>
                    <td>Index</td>
                    <td>null</td>
                    <td>null</td>
                  </tr>
                  <tr>
                    <td>Isolate_1</td>
                    <td>Index</td>
                    <td>1</td>
                  </tr>
                  <tr>
                    <td>Isolate_2</td>
                    <td>Index</td>
                    <td>2</td>
                  </tr>
                  <tr>
                    <td>Isolate_2</td>
                    <td>Isolate_1</td>
                    <td>1</td>
                  </tr>
                  <tr>
                    <td>Isolate_3</td>
                    <td>Isolate_2</td>
                    <td>3</td>
                  </tr>
                </tbody>
              </table>
              <br/><br/>

            </div>

        </div>

        <hr></hr>
        <div>
          <h4>Software Availability</h4>
          <p>HAIviz can be accessed directly from <a href="https://haiviz.beatsonlab.com">haiviz.beatsonlab.com</a> using
            any modern browser.
          </p>

        </div>

        <hr></hr>
        <div>
          <h4>Tutorial videos</h4>
          <p>
            [under development]
          </p>
          <div style={{width:'80%', margin:'auto'}}>

          </div>
        </div>

        <hr></hr>
        <div>
          <h4>Comments and feedbacks</h4>
          <p>
            HAIviz is under development. If you have any constructive feedback, comments, or suggestions, please
            feel free to send it to b.permana@uq.edu.au. Thank you.
          </p>
        </div>

      </div>
    )
  }
}
export default Documentation
/*
<video width='100%' controls>
  <source src={tutorialVideo01} type="video/mp4"/>
</video>
*/

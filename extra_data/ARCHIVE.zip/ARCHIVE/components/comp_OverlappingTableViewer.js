//Module overlapping table viewer
import React, {Component} from 'react'
import {withFauxDOM} from 'react-faux-dom'
import {formatTime, filterUnique, filterUndefinedNull, fillWithColorIndex,
        getOptimumDimensionFactors,categorizeThem} from '../utils/utils'
import {event as d3Event} from 'd3';
import DownloadSVG from './component/btn_downloadSVG'
import OverlappingSearchForm from '../containers/cont_OverlappingSearchForm'
import CloseChart from '../containers/cont_CloseChart'
import {PanelTitle} from './component/btn_utils'
const d3 = {
  ...require('d3-array'),
  ...require('d3-scale'),
  ...require('d3-axis'),
  ...require('d3-drag'),
  ...require('d3-selection'),
  ...require('d3-time-format'),
  ...require('d3-force')
}
//
class OverlappingTableViewer extends Component {
  constructor(props){
    super(props)

  this.initiateOverlappingTable = this.initiateOverlappingTable.bind(this)
  this.reDraw = this.reDraw.bind(this)

  }

  componentDidMount(){
    this.initiateOverlappingTable()
  }

  componentDidUpdate(prevProps, prevState){
    if ( this.props.width !== prevProps.width &&
          this.props.height !== prevProps.height) {
          // remove
          //d3.select('#simulatedMapSVG').remove()
          //d3.select('#simMap_refreshDescriptor').classed('w3-show', true)
    }
    else if (this.props.colorIndex !== prevProps.colorIndex) {
      this.reDraw()
    }
  }

  render() {
    //<DownloadSVG id='ganttSVG'/>
    const {overlappingTableViewer: overlappingTableViewer} = this.props
    return (
      <div id='overlappingTable' className= 'w3-row'>

        <div id="overlappingTableHandle" className= 'panelHeader w3-row w3-dark-grey'>
          <PanelTitle titleText={"Find Overlapping"}></PanelTitle>
          <div id="overlappingTable_setting" className= 'w3-col m6 w3-right'>
            <CloseChart id='overlappingTable'/>
              <div id='refreshButton' className='w3-right'>
              <button onClick={this.reDraw}
                      className="w3-button w3-medium w3-hover-none">
                      <i className="fa fa-refresh fa-lg"></i>
              </button>
            </div>
          </div>
        </div>

        <div className='w3-row w3-white'>
          <div className='w3-container w3-col m12'>
            <OverlappingSearchForm metadata={this.props.metadata}>
            </OverlappingSearchForm>
          </div>
        </div>


        <div className= 'w3-center' id= 'simulatedMapSVGviewer'>
          <h6 id='overlappingTable_refreshDescriptor'
             className='w3-hide'>
             Redraw chart using reload button on the top right corner of this window
           </h6>
            {overlappingTableViewer}
        </div>
      </div>
    )
  }

  initiateOverlappingTable(){
    const margin = {'top': 10, 'right': 20, 'bottom': 20, 'left': 10},
                  {metadata, selectActiveData, height, width, connectFauxDOM, drawFauxDOM} = this.props,
                  simMap_width = width - margin.left - margin.right,
                  simMap_height = height - margin.top - margin.bottom - 80,
                  faux = connectFauxDOM('div', 'overlappingTableViewer')

    var container = d3.select(faux),
        descriptor = container.append('div'),
        html =  "This module is under development"

    descriptor.html(html)
    .style("display", 'block')
    .style('position', 'absolute')
    .style('background-color', 'lightgreen')
    .style('padding', '5px 5px')
    .style('font-size', '12px')


    drawFauxDOM()
  }

  reDraw(){
    //d3.select('#simulatedMapSVG').remove()
    //d3.select('#simMap_refreshDescriptor').classed('w3-show', false)
    this.initiateOverlappingTable()
  }
}


export default withFauxDOM(OverlappingTableViewer)

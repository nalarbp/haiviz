import React, {Component} from 'react'
import LoadingTransImg from '../img/loadingTransmission.png';
//import UploadFile from './component/btn_uploadFile'
//import UploadFileDropbox from './component/btn_uploadFileDropbox'
import * as fa from 'react-icons/lib/fa'

class LoadingTrans extends Component {

  render() {
    return (
        <div className="w3-content w3-container">
          <div style={{border:'1px dashed black'}} className=' w3-container w3-margin w3-padding-32'>
            <div style={{maxWidth:'300px'}} className='w3-content w3-center'>
              <div>
                <img src={LoadingTransImg} alt='Waiting transmission'></img>
              </div>
            </div>
          </div>

        </div>

    )
  }

}

export default LoadingTrans
/*
<UploadFileDropbox loadData={this.props.loadData} fileID='metadata'/>

*/

//Module simulated map viewer
import React, {Component} from 'react'
import {withFauxDOM} from 'react-faux-dom'
import {formatTime, filterUnique, filterUndefinedNull, fillWithColorIndex,
        getOptimumDimensionFactors,categorizeThem, getXYfromMetadata} from '../utils/utils'
import {event as d3Event} from 'd3';
import DownloadSVG from './component/btn_downloadSVG'
import CloseChart from '../containers/cont_CloseChart'
import {PanelTitle} from './component/btn_utils'
const d3 = {
  ...require('d3-array'),
  ...require('d3-scale'),
  ...require('d3-axis'),
  ...require('d3-drag'),
  ...require('d3-selection'),
  ...require('d3-time-format'),
  ...require('d3-force')
}
//
class SimulatedMapViewer extends Component {
  constructor(props){
    super(props)
    this.state = {nodeSize:5,
                  overlayTransmissions: true}
  this.initiateSimulatedMap= this.initiateSimulatedMap.bind(this)
  this.updatePatientLocation = this.updatePatientLocation.bind(this)
  this.changeState_overlayTransmissions = this.changeState_overlayTransmissions.bind(this)
  this.overlayTransmissions = this.overlayTransmissions.bind(this)
  this.show_OverlayTransmissions = this.show_OverlayTransmissions.bind(this)
  this.hide_OverlayTransmissions = this.hide_OverlayTransmissions.bind(this)
  this.reDraw = this.reDraw.bind(this)

  }

  //open-close setting icon
  openSetting() {
    var el = document.getElementById('SimMapController')
    el.className = "w3-sidebar w3-border-bottom w3-show-block"
    el.style="height:auto;right:0"
  }
  closeSetting(){
    document.getElementById('SimMapController').className = "w3-hide"
  }

  changeState_overlayTransmissions(){
    if (this.state.overlayTransmissions) {
      this.setState({overlayTransmissions: false})
    }
    else {
      this.setState({overlayTransmissions: true})
    }
  }

  overlayTransmissions(){
    //if transmission available, show/hide, else alert user
    if (this.props.transmission && !this.state.overlayTransmissions) {
      //show overlay
      this.show_OverlayTransmissions()
    }
    else if (this.props.transmission && this.state.overlayTransmissions) {
      //hide overlay
      this.hide_OverlayTransmissions()
    }
    else {
      alert("Please input transmission graph")
    }
  }

  show_OverlayTransmissions() {
    var {connectFauxDOM, drawFauxDOM} = this.props,
        faux = connectFauxDOM('div', 'simulatedMapViewer')
    d3.select(faux).selectAll('.simMap_link')
                    .style('visibility', 'visible')
    drawFauxDOM()
  }

  hide_OverlayTransmissions() {
    var {connectFauxDOM, drawFauxDOM} = this.props,
        faux = connectFauxDOM('div', 'simulatedMapViewer')
    d3.select(faux).selectAll('.simMap_link')
                    .style('visibility', 'hidden')
    drawFauxDOM()
  }


  shouldComponentUpdate(nextProps, nextStates){
    if (nextStates.overlayTransmissions !== this.state.overlayTransmissions) {
      this.overlayTransmissions()
      return false;
    }
    else {
      return true;
    }
  }

  componentDidMount(){
    this.initiateSimulatedMap()
  }

  componentDidUpdate(prevProps, prevState){
    if (this.props.selectedData && this.props.selectedData !== prevProps.selectedData ||
    this.props.selectedExtent !== prevProps.selectedExtent){
      this.updatePatientLocation(this.props.selectedData)
    }
    else if ( this.props.width !== prevProps.width &&
              this.props.height !== prevProps.height) {
              // remove
              d3.select('#simulatedMapSVG').remove()
              d3.select('#simMap_refreshDescriptor').classed('w3-show', true)
    }
    else if (this.props.colorIndex !== prevProps.colorIndex) {
      this.reDraw()
    }
  }

  render() {
    const {simulatedMapViewer: simulatedMapViewer} = this.props
    return (
      <div id='simulatedMap' className= 'w3-row'>

        <div id="simMapHandle" className= 'panelHeader w3-row w3-dark-grey'>
          <PanelTitle titleText={"Simulated Map"}></PanelTitle>
          <div id="simMap_setting" className= 'w3-col m6 w3-right'>
            <CloseChart id='simulatedMap'/>
            <DownloadSVG id='simulatedMapSVG'/>
            <div id='settingButton' className='w3-right'>
              <button onClick={this.openSetting}
                      className="w3-button w3-medium w3-hover-none">
                      <i className="fa fa-wrench fa-lg"></i>
              </button>
            </div>
            <div id='refreshButton' className='w3-right'>
              <button onClick={this.reDraw}
                      className="w3-button w3-medium w3-hover-none">
                      <i className="fa fa-refresh fa-lg"></i>
              </button>
            </div>
          </div>
        </div>

        <div id="SimMapController" className= "w3-sidebar w3-tiny w3-border-right w3-behind w3-hide">
          <div className= "w3-right" >
            <button onClick={this.closeSetting}
                    className="w3-button w3-medium w3-hover-none">
                    <i className="fa fa-times-circle fa-lg"></i></button>
          </div>
          <div id='timelineType' className= "w3-container w3-row w3-margin-top w3-margin-bottom w3-behind" >
          <div className='w3-col s10'>
            <label>Overlay transmissions &nbsp;&nbsp; </label>
            <label className="w3-switch">
              <input onChange={this.changeState_overlayTransmissions} type="checkbox" ></input>
                <span className="w3-slider round"></span>
              </label>
          </div>
        </div>

        </div>

        <div id='simMap_tooltip' className='w3-container w3-small w3-white w3-row'>
          <div id='tooltip_info_icon' className='w3-text-white w3-col s1'>
            <p>.<i className="fa fa-info-circle fa-lg w3-text-black"></i></p>
          </div>
          <div id='simMap_tooltip_text' className='w3-col s11 w3-text-left'>
            <p></p>
          </div>
        </div>

        <div className= 'w3-center' id= 'simulatedMapSVGviewer'>
          <h6 id='simMap_refreshDescriptor'
             className='w3-hide'>
             Redraw chart using reload button on the top right corner of this window
           </h6>
            {simulatedMapViewer}
        </div>
      </div>
    )
  }

  initiateSimulatedMap(){
    const margin = {'top': 10, 'right': 20, 'bottom': 20, 'left': 10},
                  {transmission, metadata, selectActiveData, colorIndex, height, width, connectFauxDOM, drawFauxDOM} = this.props,
                  simMap_width = width - margin.left - margin.right,
                  tooltipID = 'simMap_tooltip_text',
                  simMap_height = height - margin.top - margin.bottom - 80,
                  faux = connectFauxDOM('div', 'simulatedMapViewer'),
                  circleRadius = this.state.nodeSize,
                  defaultTickNumber = 50

    //prepare simulated map
    //create new dataset for simulatedMap
    // newdata = [{patID: patID, isMulti: true, data:[{}, {}]}]
    var res_obj = {}, indicator = {}, locations = []
    metadata.forEach(function (d) {
      if (indicator[d.patID] >= 1) {
        indicator[d.patID]++
        res_obj[d.patID].num = indicator[d.patID]
        res_obj[d.patID].isMulti = true
        res_obj[d.patID].data.push(d)
      } else {
        indicator[d.patID] = 1
        res_obj[d.patID] = {num: 1, isMulti: false, data:[d]}
      }
      if (d.siteID !== 'N/A') {locations.push(d.siteID)}
    })

    locations = locations.filter(filterUnique).filter(filterUndefinedNull).sort()

    var map_dimension = getOptimumDimensionFactors(locations.length),
        tickValue_x = d3.range(map_dimension[0]),
        tickValue_y = d3.range(map_dimension[1]),
        locGrid = categorizeThem(locations, map_dimension)

    var scale_x = d3.scaleLinear().domain([0, map_dimension[0]]).range([0, simMap_width]),
        scale_y = d3.scaleLinear().domain([0, map_dimension[1]]).range([0, simMap_height]),
        container = d3.select(faux)


    //svg group
    var svgGroup = container.append('svg').attr('id', 'simulatedMapSVG')
                .attr('width', simMap_width + margin.left + margin.right)
                .attr('height', simMap_height + margin.top + margin.bottom)

    var g = svgGroup.append('g')
                .attr('transform', 'translate(' + margin.left + ',' + margin.top + ') scale(1)')

    //add circle's initial position
    metadata.forEach(function(d) {
        d.x = scale_x(locGrid[d.siteID].x + 0.5)
        d.y = scale_y(locGrid[d.siteID].y + 0.5)
      });

    //run simulation and spread circle's position
    var sim = d3.forceSimulation(metadata)
                .force('charge', d3.forceManyBody().strength(-1).distanceMax(50).distanceMin(10))
                .stop()
    for (var i = 0; i < defaultTickNumber; i++) {sim.tick()}

    //circles
    var circles = g.selectAll('.simMapCircle')
                    .data(metadata)
                    .enter()
                    .append('circle').attr('class', 'simMapCircle')
                    .attr('r', circleRadius)
                    .attr("cx", (d) => {return d.x})
                    .attr("cy", (d) => {return d.y})
                    .attr('fill', function(d) {return fillWithColorIndex(d, colorIndex)})
                    .attr('stroke',  'black')
                    .attr('stroke-width', '2px')
                    .style('visibility', (d) => { return !d.samplingDate ? 'hidden' : 'visible'})
                    .style('cursor', 'move')
                    .on('mouseover', (d) => {showTooltip('#'+tooltipID, d, d3Event.offsetX, d3Event.offsetY)})
                    .on('mouseout', (d) => {hideTooltip('#'+tooltipID)})
                    .on('click', (d) => {selectActiveData({selectedData: [d], selectedExtent: undefined})})

    //transmission links
    if (transmission && this.state.overlayTransmissions) {
      var transmissionData = JSON.parse(JSON.stringify(this.props.transmission))
      //make dictionary
      var nameIdDictionary = {}
      transmissionData.nodes.forEach(function(d) {
        nameIdDictionary[d.id] = {name: d.name,
                                  xy: getXYfromMetadata(d.name, metadata)}
      })
      //console.log(nameIdDictionary);
      //make arrow Group
      var arrowGroupBlack = g.append('g').attr('id', 'simMapArrowGroup')
                          .append("defs").append("marker")
                          .attr("id", 'simMapArrow')
                          .attr("refX", 15)
                          .attr("refY", 2)
                          .attr("markerWidth", 12)
                          .attr("markerHeight", 12)
                          .attr("orient", "auto")
                          .append("path")
                          .attr("d", "M0,0 L0,4 L4,2 Z")
                          .attr('fill', 'black')

      //make link group
      var linksGroup = g.append('g').attr('id', 'simMapLinksGroup')
      var linkLine = linksGroup.selectAll('.simMap_link')
                              .data(transmissionData.links)
                              .enter()
                              .append('line').attr('class', 'simMap_link')
                              .attr("x1", function(d) {
                                //console.log(nameIdDictionary[d.source].xy[0])
                                return nameIdDictionary[d.source].xy[0]})
                              .attr("y1", function(d) {return nameIdDictionary[d.source].xy[1]})
                              .attr("x2", function(d) {return nameIdDictionary[d.target].xy[0]})
                              .attr("y2", function(d) {return nameIdDictionary[d.target].xy[1]})
                              .attr('stroke',  'black')
                              .attr('stroke-width', '1px')
                              .style('fill', 'none')
                              .attr('marker-end', function(d) {
                                //console.log(d);
                                return 'url(#simMapArrow)'
                              })
                              .style('visibility', 'hidden')

                              //get dx of the nodes metadata using
      this.setState({overlayTransmissions: false})


    }





    //axis X + vertical grid
    /*
    var simMap_axisX = d3.axisBottom().scale(scale_x)
                          .tickValues(tickValue_x)
                          .tickFormat("")
                          .tickSize(simMap_height)

    svgGroup.append('g').attr('id', 'gAxisX')
                   .attr("transform", "translate(" + margin.left + "," + margin.top + ")")
                   .call(simMap_axisX);

    //axis Y + horizontal grid
    var simMap_axisY = d3.axisRight().scale(scale_y)
                          //.tickValues(tickValue_y)
                          //.tickFormat("")
                          //.tickSize(simMap_width)

    svgGroup.append('g').attr('id', 'gAxisY')
                   .attr("transform", "translate(" + margin.left + "," + margin.top + ")")
                   .call(simMap_axisY);

    //grid label (location text)
    var gridLabels = g.selectAll('.simMapGridLabel')
                    .data(locations)
                    .enter()
                    .append('text').attr('class', 'simMapGridLabel')
                    .text( d => d)
                    .attr('x', (d) => {return scale_x(locGrid[d].x + 0.5)}) //middle
                    .attr('y', (d) => {return scale_y(locGrid[d].y) + 10}) //offset 10px as margin
                    .attr('text-anchor', 'middle')
                    .attr('font-size', '8pt')
    */
    //for every location, draw box, patients, label and remap the position

    var locationBoxes = g.selectAll('.locationBoxGroup')
                          .data(locations).enter()
                          .append('g').attr('class', 'locationBoxGroup')
                          .attr('transform', function (d) {
                            return 'translate(' + scale_x(locGrid[d].x) + ',' + scale_y(locGrid[d].y) + ')'})
                          .append('rect')
                          .attr('x', 0)
                          .attr('y', 0)
                          .attr('width', simMap_width/map_dimension[0] - 10)
                          .attr('height', simMap_height/map_dimension[1] - 10)
                          .attr('fill', 'none')
                          .attr('stroke', 'black')

          g.selectAll('.locationBoxGroup')
                          .append('text').attr('class', 'locationBoxLabel')
                          .text( d => d)
                          .attr('x', simMap_width/map_dimension[0]/2 - 5)
                          .attr('y', 10)
                          .attr('text-anchor', 'middle')
                          .attr('font-size', '7pt')

    //tooltip_local
    function showTooltip(tooltipID, data) {
      var tooltip = d3.select(tooltipID)
                      .html('<p id="simMap_tooltip_content" >' +
                            'Host: '+data.patID+
                            '<span>&nbsp&nbsp&nbsp&nbsp</span>'+
                            'Sample: ' +data.sampleID +
                            '</p>')
    }

    function hideTooltip(tooltipID) {
      d3.select('#simMap_tooltip_content').remove()
    }

    drawFauxDOM()
  }

  reDraw(){
    d3.select('#simulatedMapSVG').remove()
    d3.select('#simMap_refreshDescriptor').classed('w3-show', false)
    this.initiateSimulatedMap()
  }

  updatePatientLocation(selectedData){
    //console.log('up simmap by selectedData');
    //select all circle, if entryID not in selectedData, hide it!
    var {color_user, colorIndex, connectFauxDOM, drawFauxDOM} = this.props,
        entryIDs = selectedData.map(function(d) {return d.entryID})
    var faux = connectFauxDOM('div', 'simulatedMapViewer'),
        nodeSize = this.state.nodeSize
    d3.select(faux)
      .selectAll('circle.simMapCircle')
      .attr('r', function (d) {
        if (entryIDs.indexOf(d.entryID) === -1) {
          return nodeSize;
        } else {
          return 2*nodeSize;
        }
      })
      .attr('fill', function (d) {
        if (entryIDs.indexOf(d.entryID) === -1) {
          return 'lightgray'
        } else {
          return fillWithColorIndex(d, colorIndex)
        }
      })
    drawFauxDOM()
  }

}


export default withFauxDOM(SimulatedMapViewer)

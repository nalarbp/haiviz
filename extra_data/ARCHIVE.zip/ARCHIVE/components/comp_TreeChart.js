import React, {Component} from 'react'
import {withFauxDOM} from 'react-faux-dom'
import * as util from '../utils/utils'
import newickParse from '../utils/newick';
import {PanelHeader} from '../utils/styled'
import ZoomController from './component/btn_zoomController'
import DownloadSVG from './component/btn_downloadSVG'
import UploadFile from './component/btn_uploadFile'
import CloseChart from '../containers/cont_CloseChart'
import {event as d3Event} from 'd3'
const d3 = {
  ...require('d3-hierarchy'),
  ...require('d3-array'),
  ...require('d3-axis'),
  ...require('d3-drag'),
  ...require('d3-shape'),
  ...require('d3-selection')
}

/*
// props from container: metadata
class TreeComp extends Component {
  constructor(props) {
    super(props)
    this.state = {treeType:'null',
                  nodeLabel: true,
                  nodeLableSize: 10,
                  nodeSize: 1}
  }

  render(){
    return (
      <div className="w3-gray" style={{width: '100%', height: '100%'}}>
        <PanelHeader className='panelHeader'>
          <div className='panelTitle'>Phylogenetic tree</div>
          <CloseChart id='tree'/>
          <DownloadSVG svgID="treeSVG"/>
        </PanelHeader>
        <
      </div>
    )
  }
}
*/
class TreeChart extends Component {
  constructor(props){
    super(props)

    this.state = {treeJSON: newickParse(this.props.tree)}
    this.renderD3= this.renderD3.bind(this)
    this.renderTreeOnly= this.renderTreeOnly.bind(this)
  }

  componentDidUpdate(prevProps, prevState){
    //when user provide metadata
    if (this.props.metadata && this.props.tree) {
      //if (this.props.tree && this.props.tree !== prevProps.tree) {
      //  this.updateD3()
      //}
      if (this.props.tree &&
              this.props.width !== prevProps.width &&
              this.props.height !== prevProps.height) {
        this.updateD3()
        //this.updateTreeAll()
      }
      else if (this.props.filteredEntryID !== null &&
               this.props.filteredEntryID !== prevProps.filteredEntryID) {
        this.updateNodes(this.props.filteredEntryID, this.props.metadata)
      }
      else if (this.props.clickedElement !== null &&
               this.props.clickedElement !== prevProps.clickedElement ) {
        this.updateClickedNodes(this.props.clickedElement)
      }
    }
    //when user has no metadata
    else {
      if (this.props.tree && this.props.tree !== prevProps.tree) {
        this.updateTreeOnly()
      }
      else if (this.props.tree && this.props.width !== prevProps.width &&
                this.props.height !== prevProps.height) {
        this.updateTreeOnly()
      }
    }
  }
  render() {
    const {chart: chart} = this.props
    return (
      <div style={{width: '100%', height: '100%'}}>
        <PanelHeader className='panelHeader'>
          <div className='panelTitle'>Tree</div>
          <CloseChart id='tree'/>
          <DownloadSVG svgID="treeSVG"/>
        </PanelHeader>
        {chart}
      </div>
    )
  }

  renderTreeOnly(){
    const treeData = this.props.tree,
          treeJSON = newickParse(treeData),
          {width, height, connectFauxDOM, animateFauxDOM} = this.props,
          faux = connectFauxDOM('div', 'chart'),
          margin = {'top': 10, 'right': 50, 'bottom': 20, 'left': 20}

    var tree_width = (0.8 * width) - margin.left - margin.right,
        tree_height = height - 80 - margin.top - margin.bottom,
        controller_width = (0.2 * width),
        zoomLevel = 1,
        translateX = margin.left,
        translateY = margin.top,
        dragStartX, dragStartY, isMouseDown, dragTimeStamp

    //prepare the tree data for d3 layout, convert json to hierarchical dataset
    var root = d3.hierarchy(treeJSON, d => d.branchset)
                 .sum(d => d.branchset ? 0 : 1)
                 //.sort((a, b) => d3.descending(a.data.length, b.data.length))

    var clusterLayout = d3.cluster().size([tree_height, tree_width]) // projection the default position x and y
    clusterLayout(root)
    var nodes = root.descendants()

    //var xscale = util.tree_scaleBranchLengths(nodes, tree_width - margin.right) // scale the branch for link projection
    //var tree_scaledWidth = xscale(tree_width)

    var links = root.links()
    var lengthOfNodes = nodes.map(function(d) {return d.data.length})

    var minimumLinks = links.filter(function(d) {
      if (d.target.data.length === d3.extent(lengthOfNodes)[0]) {
        return d.target.y - d.source.y}
    })

    var container = d3.select(faux)
                      .attr('class', 'w3-row')
    //reset zoom and loation
    d3.select('#svgGroup')
    .attr('transform', 'translate(' + margin.left + ',' + margin.top + ') scale(1)')

    //make controller div
    var tree_controller = container.append('div')
                              .attr('id', 'tree_controller')
                              .attr('width', controller_width)
                              .attr('height', tree_height + margin.bottom)
                              .attr("class", 'w3-blue w3-col m2')
    //scale bar controller =========
    var scaleBar = tree_controller.append('div')
                                  .attr('id', 'tree_scaleBar')
                                  .attr('class', 'w3-pink')
    var scaleBar_form = scaleBar.append('form').attr('class', 'w3-container')
    var eleco = scaleBar_form.append('select').attr('name', 'option')
                      .attr('class', 'w3-select')
        eleco.append('option').attr('value', '1').text('Satuy')
        eleco.append('option').attr('value', '2').text('dua')

        scaleBar_form.selectAll("input")
                      .data([0])
                      .enter()
                      .append('select')



        //scaleBar_form.insert('p').text('yoo')
        //scaleBar_form.append('input').attr('class', 'w3-input').attr('type', 'text')



        //scaleBar.append('label').attr('text', 'Scale Bar')



    //make tree div
    var tree_svg = container.append('div')
                              .attr('id', 'tree_svg')
                              .attr('width', tree_width)
                              .attr('height', tree_height + margin.bottom)
                              .attr("class", 'w3-green w3-col m10')

      tree_svg.append('button')
                .attr('class', 'w3-button w3-gray')
                .attr('text', 'button')


    //make svg root
    var svg = tree_svg.append('svg').attr('id', 'treeSVG')
                .attr('width', tree_width + margin.right)
                .attr('height', tree_height + margin.bottom)


    var svgGroup = svg.append('g').attr('id', 'svgGroup')
                .attr('transform', 'translate(' + margin.left + ',' + margin.top + ')')

    //border-rectangle
    //var rectangleBorder = svgGroup.append('rect')
    //                              .attr("x", 0)
    //                              .attr("y", 0)
    //                              .attr("width", tree_width + margin.left + margin.right)
    //                              .attr("height", tree_height + margin.top + margin.bottom)
    //                              .attr('stroke', 'black')
    //                              .attr('fill', 'none')

    //svg is ready
    //link group
    svgGroup.append('g')
            .selectAll('.tree_link')
            .data(links)
            .enter().append('path')
            .attr('class', 'tree_link')
            .attr('d', d => util.tree_pathGenerator(d))
            .attr('stroke', 'black')
            .attr('fill', 'none')
    //node group
    svgGroup.append('g')
            .selectAll('g.node')
            .data(nodes).enter()
            .append('g')
            .attr("class", function(n) {
              if (n.children) {
                if (n.depth === 0) {
                return "tree_root node"
                } else {
                return "tree_inner node"
                }
              } else {
              return "tree_leaf node"
              }
            })
            .attr("transform", function(d) {
            return "translate(" + d.y + "," + d.x + ")"; })
    //add label
    svgGroup.selectAll('g.tree_leaf.node')
          .append("text")
          .attr('class', 'tree_nodeLabel')
          .attr("dx", 9)
          .attr("dy", 3)
          .attr("text-anchor", "start")
          .attr('font-size', '10px')
          .attr('fill', 'black')
          .text(d =>  d.data.name)
    //add node (circle)
    svgGroup.selectAll('g.tree_leaf.node')
          .append("circle")
          .attr('class', 'tree_nodeCircle')
          .attr('r', 5)
          .attr('fill', 'black')

    //add scale
    var scaleGroup = svgGroup.append('g').attr('class', 'scaleGroup')
    //scaleGroup.append('text')
    //          .attr('x', 0)
    ///          .attr('y', tree_height - margin.bottom-10)
    ///          .attr('font-size', '12px')
    //          .text(Math.round(minimumLinks[0].target.data.length * 1000)/1000)

    //scaleGroup.selectAll('line')
    //    .data(yscale.ticks(10))
    //    .enter().append('svg:line')
    ///    .attr('y1', 0)
    //    .attr('y2', tree_height)
    //    .attr('x1', yscale)
    //    .attr('x2', yscale)
    //    .attr("stroke", "black");


    // Event: zoom
    svg.on('wheel.zoom', function() {
      if (d3Event.deltaY > 0 && zoomLevel < 4 ) {
        //var initial = floorplanZoomLevel + 0.2
        zoomLevel += 0.15
        //updateFloorplanZoomLevel(num)
        zoomed('#svgGroup', zoomLevel)
      }
      else if (d3Event.deltaY < 0 && zoomLevel > 0.2 ) {
        //var reducedLevel = floorplanZoomLevel - 0.2
        zoomLevel -= 0.15
        //updateFloorplanZoomLevel(num)
        zoomed('#svgGroup', zoomLevel)
      }
    })

    // Event: drag
    svg.on('mousedown', function() {
      isMouseDown = true
      dragStartX = d3Event.screenX
      dragStartY = d3Event.screenY})
        .on('mousemove', function() {
          if (isMouseDown) {
            var deltaTimeStamp = d3Event.timeStamp - dragTimeStamp
            if (dragTimeStamp && deltaTimeStamp > 10) {
              var deltaX = d3Event.screenX - dragStartX
              var deltaY = d3Event.screenY - dragStartY
              dragTimeStamp = d3Event.timeStamp
              dragged('#svgGroup', deltaX, deltaY, zoomLevel)
            }
            else {
              dragTimeStamp = d3Event.timeStamp
            }
          }
        })
        .on('mouseup', function() {
          isMouseDown = false
        })

    //Litener: zoomed
    function zoomed(transformID, newLevel) {
        d3.select(transformID)
          .attr('transform', 'translate(' + translateX + ',' + translateY + ') scale(' + newLevel + ')')
      }
    //Listener: dragged
    function dragged(transformID, deltaX, deltaY, currentZoomLevel) {
      translateX += deltaX*0.1
      translateY += deltaY*0.1
      d3.select(transformID)
        .attr('transform', 'translate(' + translateX + ',' + translateY + ') scale(' + currentZoomLevel + ')')
      }

    //call animate withFauxDOM
    animateFauxDOM(800)
  }

  generateStandardTree(){
    //input: TreeJSON, dimension,
  }

  renderD3(){
    const metadata = this.props.metadata
    const treeJSON = newickParse(this.props.tree);
    const {updateClickedElement,  siteColor,
          width, height, connectFauxDOM, animateFauxDOM} = this.props
    const faux = connectFauxDOM('div', 'chart')
    const margin = {'top': 10, 'right': 50, 'bottom': 20, 'left': 20}
    var tree_width = width - margin.left - margin.right
    var tree_height = height - 80 - margin.top - margin.bottom
    var zoomLevel = 1
    var dragStartX, dragStartY, isMouseDown, dragTimeStamp
    var translateX = margin.left
    var translateY = margin.top

    //Parsing dataset
    var root = d3.hierarchy(treeJSON, d => d.branchset)
          .sum(d => d.branchset ? 0 : 1)
          .sort((a, b) => d3.descending(a.data.length, b.data.length))

    var clusterLayout = d3.cluster().size([tree_height, tree_width]) // projection the default position x and y
    root = clusterLayout(root)
    root.leaves()
        .forEach(function(d) {d.data.entryID = util.getEntryIDfromSampleID(d.data.name, metadata)})
    var nodes = root.descendants()
    var links = root.links()

    var yscale = util.tree_scaleBranchLengths(nodes, tree_width - margin.right) // scale the branch for link projection
    var tree_scaledWidth = yscale(tree_width)

    //axis
    //var tree_xAxis = d3.axisBottom(tree_scaledWidth).tickFormat("").tickSize(1)


    //scalling
    var lengthOfNodes = nodes.map(function(d) {return d.data.length})
    var minimumLinks = links.filter(function(d) {
      if (d.target.data.length === d3.extent(lengthOfNodes)[0]) {
        return d.target.y - d.source.y}
    })

    //make tooltips container
    var container = d3.select(faux)
    var tooltipID = 'treeTooltip'
    var tooltip = container.append('div').attr('id', tooltipID).classed('tooltip', true)
    //var transformFloorplanID = 'transform'+this.props.levelID

    //reset zoom and loation
    d3.select('#svgGroup')
    .attr('transform', 'translate(' + margin.left + ',' + margin.top + ') scale(1)')

    //make svg root
    var svg = container.append('svg').attr('id', 'treeSVG')
                .attr('width', tree_width + margin.left + margin.right)
                .attr('height', tree_height + margin.top + margin.bottom)


    var svgGroup = svg.append('g').attr('id', 'svgGroup')
                      .attr('transform', 'translate(' + margin.left + ',' + margin.top + ')')

    //link group
    svgGroup.append('g')
            .selectAll('.tree_link')
            .data(links)
            .enter().append('path')
            .attr('class', 'tree_link')
            .attr('d', d => util.tree_pathGenerator(d))
            .attr('stroke', 'black')
            .attr('fill', 'none')
    //node group
    svgGroup.append('g')
            .selectAll('g.node')
            .data(nodes).enter()
            .append('g')
            .attr("class", function(n) {
              if (n.children) {
                if (n.depth === 0) {
                return "tree_root node"
                } else {
                return "tree_inner node"
                }
              } else {
              return "tree_leaf node"
              }
            })
            .attr('r', 10)
            .attr("transform", function(d) {
            return "translate(" + d.y + "," + d.x + ")"; })
    //add label
    svgGroup.selectAll('g.tree_leaf.node')
          .append("text")
          .attr('class', 'tree_nodeLabel')
          .attr("dx", 9)
          .attr("dy", 3)
          .attr("text-anchor", "start")
          .attr('font-size', '10px')
          .attr('fill', 'black')
          .text(d =>  d.data.name)
    //add node (circle)
    svgGroup.selectAll('g.tree_leaf.node')
          .append("circle")
          .attr('class', 'tree_nodeCircle')
          .attr('r', 5)
          .attr('fill', function(d) {
            //console.log('TREE-NODE:', d);

            var siteID =  util.getSiteIDfromEntryID(d.data.entryID, metadata)
            //console.log(d);

            //return siteColor(siteID)
            //let colourIdx = util.getColurFromEntryID(d.data.entryID, metadata)
            return siteColor[siteID]

          })
          .style("fill", function(d) {
            let siteID =  util.getSiteIDfromEntryID(d.data.entryID, metadata)
            return siteColor[d.siteID]
          })
          .on('click', function(d) {
            updateClickedElement(d.data.entryID)
          })
          //.on('mouseover', function(d) {
            //var entryID =  d.data.entryID
          //  var datum = util.getDetailsfromEntryID(d.data.entryID, metadata)
            //console.log(d3Event);
          //  util.showTooltip('#'+tooltipID, datum,
          //  d3Event.offsetX, d3Event.offsetY, 'tree')
          //})
          //.on('mouseout', function(d) {
          //  util.hideTooltip('#'+tooltipID)
          //})

    //add axis
    //svgGroup.append("g").attr('id', 'gAxisX').call(tree_xAxis)
    //              .attr("transform", "translate(0," + tree_height + ")")


    //add scale
    var scaleGroup = svgGroup.append('g').attr('class', 'scaleGroup')
    //scaleGroup.append('text')
    //          .attr('x', 0)
    //          .attr('y', tree_height - margin.bottom-10)
    //          .attr('font-size', '12px')
    //          .text(Math.round(minimumLinks[0].target.data.length * 1000)/1000)

    //scaleGroup.append('line')
    //                  .attr('x1', 0)
    //                  .attr('x2', minimumLinks[0].target.y - minimumLinks[0].source.y )
    //                  .attr('y1', tree_height - margin.bottom)
    //                  .attr('y2', tree_height- margin.bottom)
    //                .attr('stroke', 'black')

    // Event: zoom
    svg.on('wheel.zoom', function() {
      if (d3Event.deltaY > 0 && zoomLevel < 4 ) {
        //var initial = floorplanZoomLevel + 0.2
        zoomLevel += 0.15
        //updateFloorplanZoomLevel(num)
        zoomed('#svgGroup', zoomLevel)
      }
      else if (d3Event.deltaY < 0 && zoomLevel > 0.2 ) {
        //var reducedLevel = floorplanZoomLevel - 0.2
        zoomLevel -= 0.15
        //updateFloorplanZoomLevel(num)
        zoomed('#svgGroup', zoomLevel)
      }
    })

    // Event: drag
    svg.on('mousedown', function() {
      isMouseDown = true
      dragStartX = d3Event.screenX
      dragStartY = d3Event.screenY})
        .on('mousemove', function() {
          if (isMouseDown) {
            var deltaTimeStamp = d3Event.timeStamp - dragTimeStamp
            if (dragTimeStamp && deltaTimeStamp > 10) {
              var deltaX = d3Event.screenX - dragStartX
              var deltaY = d3Event.screenY - dragStartY
              dragTimeStamp = d3Event.timeStamp
              dragged('#svgGroup', deltaX, deltaY, zoomLevel)
            }
            else {
              dragTimeStamp = d3Event.timeStamp
            }
          }
        })
        .on('mouseup', function() {
          isMouseDown = false
        })

    //Litener: zoomed
    function zoomed(transformID, newLevel) {
        d3.select(transformID)
          .attr('transform', 'translate(' + translateX + ',' + translateY + ') scale(' + newLevel + ')')
      }
    //Listener: dragged
    function dragged(transformID, deltaX, deltaY, currentZoomLevel) {
      translateX += deltaX*0.1
      translateY += deltaY*0.1
      d3.select(transformID)
        .attr('transform', 'translate(' + translateX + ',' + translateY + ') scale(' + currentZoomLevel + ')')
      }

    //call animate withFauxDOM
    animateFauxDOM(800)

  }

  updateD3(){
    const faux = this.props.connectFauxDOM('div', 'chart')
    d3.select(faux).select('svg').remove()
    this.renderD3()
  }
  updateTreeOnly(){
    const faux = this.props.connectFauxDOM('div', 'chart')
    d3.select(faux).select('svg').remove()
    this.renderTreeOnly()
  }
  updateNodes(filteredEntryID, metadata){
    const faux = this.props.connectFauxDOM('div', 'chart')
    //console.log(filteredSampleID);
    var newFilteredEntryID = util.filterOutNonSampleID(filteredEntryID, metadata)
    console.log(newFilteredEntryID);
    d3.select(faux)
      .selectAll('circle')
      .transition().duration(200)
      .attr('r', function (d) {
        if (newFilteredEntryID.indexOf(d.data.entryID) !== -1) {return 10}
        else {return 5}
      })
      //call animate withFauxDOM
      this.props.animateFauxDOM(1800)
  }
  updateClickedNodes(entryID){
    const faux = this.props.connectFauxDOM('div', 'chart')
    d3.select(faux)
      .selectAll('circle')
      .attr('r', function (d) {
        if (d.data.entryID === entryID) {return 10}
        else {return 5}
      })
      this.props.animateFauxDOM(1800)
  }
  renderD3_ori(){
    const metadata = this.props.metadata
    const treeJSON = newickParse(this.props.tree);
    const {updateClickedElement,  siteColor,
          width, height, connectFauxDOM, animateFauxDOM} = this.props
    const faux = connectFauxDOM('div', 'chart')
    const margin = {'top': 10, 'right': 50, 'bottom': 20, 'left': 20}
    var tree_width = width - margin.left - margin.right
    var tree_height = height - 80 - margin.top - margin.bottom
    var zoomLevel = 1
    var dragStartX, dragStartY, isMouseDown, dragTimeStamp
    var translateX = margin.left
    var translateY = margin.top

    var root = d3.hierarchy(treeJSON, d => d.branchset)
          .sum(d => d.branchset ? 0 : 1)
          .sort((a, b) => d3.descending(a.data.length, b.data.length))

    var clusterLayout = d3.cluster().size([tree_height, tree_width]) // projection the default position x and y
    root = clusterLayout(root)
    var nodes = root.descendants()

    var yscale = util.tree_scaleBranchLengths(nodes, tree_width - margin.right) // scale the branch for link projection
    var tree_scaledWidth = yscale(tree_width)

    var links = root.links()
    var lengthOfNodes = nodes.map(function(d) {return d.data.length})

    var minimumLinks = links.filter(function(d) {
      if (d.target.data.length === d3.extent(lengthOfNodes)[0]) {
        return d.target.y - d.source.y}
    })

    //make tooltips container
    var container = d3.select(faux)
    var tooltipID = 'treeTooltip'
    var tooltip = container.append('div').attr('id', tooltipID).classed('tooltip', true)
    //var transformFloorplanID = 'transform'+this.props.levelID

    //reset zoom and loation
    d3.select('#svgGroup')
    .attr('transform', 'translate(' + margin.left + ',' + margin.top + ') scale(1)')

    //make svg root
    var svg = container.append('svg').attr('id', 'treeSVG')
                .attr('width', tree_width + margin.left + margin.right)
                .attr('height', tree_height + margin.top + margin.bottom)


    var svgGroup = svg.append('g').attr('id', 'svgGroup')
                      .attr('transform', 'translate(' + margin.left + ',' + margin.top + ')')

    //link group
    //link group
    svgGroup.append('g')
            .selectAll('.tree_link')
            .data(links)
            .enter().append('path')
            .attr('class', 'tree_link')
            .attr('d', d => util.tree_pathGenerator(d))
            .attr('stroke', 'black')
            .attr('fill', 'none')

    //node group
    svgGroup.append('g')
            .selectAll('g.node')
            .data(nodes).enter()
            .append('g')
            .attr("class", function(n) {
              if (n.children) {
                if (n.depth === 0) {
                return "tree_root node"
                } else {
                return "tree_inner node"
                }
              } else {
              return "tree_leaf node"
              }
            })
            .attr("transform", function(d) {
            return "translate(" + d.y + "," + d.x + ")"; })
    //add label
    svgGroup.selectAll('g.tree_leaf.node')
          .append("text")
          .attr('class', 'tree_nodeLabel')
          .attr("dx", 9)
          .attr("dy", 3)
          .attr("text-anchor", "start")
          .attr('font-size', '10px')
          .attr('fill', 'black')
          .text(d =>  d.data.name)
    //add node (circle)
    svgGroup.selectAll('g.tree_leaf.node')
          .append("circle")
          .attr('class', 'tree_nodeCircle')
          .attr('r', 5)
          .attr('fill', function(d) {
            //console.log('TREE-NODE:', d);
            //let siteID =  util.getSiteIDfromEntryID(d.data.entryID, metadata)
            //return siteColor(siteID)
            let colourIdx = util.getColurFromEntryID(d.data.entryID, metadata)
            return colourIdx
          })
          .on('click', function(d) {
            updateClickedElement(d.data.entryID)
          })
          //.on('mouseover', function(d) {
            //var entryID =  d.data.entryID
          //  var datum = util.getDetailsfromEntryID(d.data.entryID, metadata)
            //console.log(d3Event);
          //  util.showTooltip('#'+tooltipID, datum,
          //  d3Event.offsetX, d3Event.offsetY, 'tree')
          //})
          //.on('mouseout', function(d) {
          //  util.hideTooltip('#'+tooltipID)
          //})

    //add axis
    //svgGroup.append("g").attr('id', 'gAxisX').call(tree_xAxis)
    //              .attr("transform", "translate(0," + tree_height + ")")


    //add scale
    var scaleGroup = svgGroup.append('g').attr('class', 'scaleGroup')
    scaleGroup.append('text')
              .attr('x', 0)
              .attr('y', tree_height - margin.bottom-10)
              .attr('font-size', '12px')
              .text(Math.round(minimumLinks[0].target.data.length * 1000)/1000)

    scaleGroup.append('line')
                      .attr('x1', 0)
                      .attr('x2', minimumLinks[0].target.y - minimumLinks[0].source.y )
                      .attr('y1', tree_height - margin.bottom)
                      .attr('y2', tree_height- margin.bottom)
                      .attr('stroke', 'black')

    // Event: zoom
    svg.on('wheel.zoom', function() {
      if (d3Event.deltaY > 0 && zoomLevel < 4 ) {
        //var initial = floorplanZoomLevel + 0.2
        zoomLevel += 0.15
        //updateFloorplanZoomLevel(num)
        zoomed('#svgGroup', zoomLevel)
      }
      else if (d3Event.deltaY < 0 && zoomLevel > 0.2 ) {
        //var reducedLevel = floorplanZoomLevel - 0.2
        zoomLevel -= 0.15
        //updateFloorplanZoomLevel(num)
        zoomed('#svgGroup', zoomLevel)
      }
    })

    // Event: drag
    svg.on('mousedown', function() {
      isMouseDown = true
      dragStartX = d3Event.screenX
      dragStartY = d3Event.screenY})
        .on('mousemove', function() {
          if (isMouseDown) {
            var deltaTimeStamp = d3Event.timeStamp - dragTimeStamp
            if (dragTimeStamp && deltaTimeStamp > 10) {
              var deltaX = d3Event.screenX - dragStartX
              var deltaY = d3Event.screenY - dragStartY
              dragTimeStamp = d3Event.timeStamp
              dragged('#svgGroup', deltaX, deltaY, zoomLevel)
            }
            else {
              dragTimeStamp = d3Event.timeStamp
            }
          }
        })
        .on('mouseup', function() {
          isMouseDown = false
        })

    //Litener: zoomed
    function zoomed(transformID, newLevel) {
        d3.select(transformID)
          .attr('transform', 'translate(' + translateX + ',' + translateY + ') scale(' + newLevel + ')')
      }
    //Listener: dragged
    function dragged(transformID, deltaX, deltaY, currentZoomLevel) {
      translateX += deltaX*0.1
      translateY += deltaY*0.1
      d3.select(transformID)
        .attr('transform', 'translate(' + translateX + ',' + translateY + ') scale(' + currentZoomLevel + ')')
      }

    //call animate withFauxDOM
    animateFauxDOM(800)

  }

}
//*/
export default withFauxDOM(TreeChart)

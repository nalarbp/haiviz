import React, {Component} from 'react';
import * as md from 'react-icons/lib/md'

class AnimationController extends Component{
  constructor(props){
    //props: svgID
    super(props)
    this.playAnimation = this.playAnimation.bind(this);
    this.stopAnimation = this.stopAnimation.bind(this);
  }
  playAnimation(e){
    //console.log('Anim Play!');
  }

  stopAnimation(e){
    //console.log('Anim Stop!');

  }



  render(){
    return(
      <div style={{float: 'left', margin:'10px 0 0 20px'}} >
        <button style={{border: '1px solid teal', borderRadius: '3px', backgroundColor:'teal'}}
                onClick={this.playAnimation}>
                <md.MdPlayArrow  size={23} color='white'/>
        </button>
        <button style={{marginLeft:'10px', border: '1px solid teal', borderRadius: '3px', backgroundColor:'teal'}}
                onClick={this.stopAnimation}>
                <md.MdStop  size={23} color='white'/>
        </button>
      </div>
    )
  }
}
export default AnimationController;

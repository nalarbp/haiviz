import React, {Component} from 'react'
import {PanelHeader} from '../utils/styled'
import CloseChart from '../containers/cont_CloseChart'
import * as util from '../utils/utils'

// props from container: metadata
class InfoBoxHTML extends Component {

  componentDidUpdate(prevProps, prevState){
    if (this.props.width !== prevProps.width && this.props.height !== prevProps.height) {

    }

  }

  render() {
    //console.log('info render');
    let details = {patID: '...', sampleID: '...', dateIn: '...', dateOut: '...', siteID: '...'}
    if (this.props.clickedElement) {
       details = util.getDetailsfromEntryID(this.props.clickedElement, this.props.metadata)
    }
    return (
      <div style={{width: '100%', height: '100%'}}>
        <PanelHeader className='panelHeader'>
          <div className='panelTitle'>Information</div>
          <CloseChart id='info'/>
        </PanelHeader>
        <div className="w3-container">
          <table className="w3-table w3-bordered w3-small">
            <thead>
              <tr>
                <th>Patient</th>
                <th>{details.patID}</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Location</td>
                <td>{details.siteID}</td>
              </tr>
              <tr>
                <td>Sample</td>
                <td>{details.sampleID}</td>
              </tr>
              <tr>
                <td>Date In</td>
                <td>{details.dateIn}</td>
              </tr>
              <tr>
                <td>Date Out</td>
                <td>{details.dateOut}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    )
  }

}


export default InfoBoxHTML

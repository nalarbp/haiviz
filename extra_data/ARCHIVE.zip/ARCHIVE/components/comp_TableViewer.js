import React, {Component} from 'react'
import {withFauxDOM} from 'react-faux-dom'
import {PanelHeader} from '../utils/styled'
import CloseChart from '../containers/cont_CloseChart'
import SearchForm from '../containers/cont_SearchForm'
import {PanelTitle} from './component/btn_utils'
import * as util from '../utils/utils'

const d3 = {
  ...require('d3-array'),
  ...require('d3-scale'),
  ...require('d3-axis'),
  ...require('d3-time-format'),
  ...require('d3-selection')
}

// props from container: metadata
class TableViewer extends Component {
  constructor(props){
    super(props)
    this.renderD3= this.renderD3.bind(this)
    this.updateD3= this.updateD3.bind(this)
    this.updateTextDescriptor= this.updateTextDescriptor.bind(this)
  }

  componentDidUpdate(prevProps, prevState){

    if (this.props.height !== prevProps.height) {
        this.updateD3()
    }
    else if (this.props.selectedData !== null && this.props.selectedData !== prevProps.selectedData ) {
      //console.log(this.props.selectedData);
      this.updateD3()
      this.updateTextDescriptor(this.props.selectedData)
      //this.updateClickedNodes(prevProps.clickedElement, this.props.clickedElement)
    }
  }
  updateTextDescriptor(selectedData){
    if (selectedData.length !== 0) {
      var patients = selectedData.map(function(d) {return d.patID}).filter(util.filterUniqueNullUndefined),
          isolates = selectedData.map(function(d) {return d.sampleID})
                                  .filter(util.filterUniqueNullUndefined)
                                  .filter(util.filter_str_null)


      d3.select('#patientIsolateDescriptor')
        .text('Number of patients: ' + patients.length +
             '   &   Isolates: ' + isolates.length)
    } else {
      d3.select('#patientIsolateDescriptor')
        .text('No records found')
    }
  }

  render() {

    const {metadataTableSearch: metadataTableSearch} = this.props
    return (
      <div style={{width: '100%', height: '100%'}}>

        <div id="tableHandle" className= 'panelHeader w3-row w3-dark-grey'>
          <PanelTitle titleText={"Metadata Table"}></PanelTitle>
          <div className= 'w3-col m6 w3-right'>
            <CloseChart id='table'/>
          </div>
        </div>

        <div className='w3-row w3-white'>
          <div className='w3-container w3-col m6'>
            <SearchForm metadata={this.props.metadata}
                        selectedData={this.props.selectedData}>
            </SearchForm>
          </div>
          <div className='w3-container w3-text-dark-grey w3-col m6'>
            <p id='patientIsolateDescriptor'>No records</p>
          </div>
        </div>
        <div>
          {metadataTableSearch}
        </div>
      </div>
    )
  }

  renderD3(){

    const margin = {'top': 10, 'right': 10, 'bottom': 50, 'left': 60}
    const {width, height, connectFauxDOM, drawFauxDOM, metadata, selectedData} = this.props
    const faux = connectFauxDOM('div', 'metadataTableSearch')
    const formatTime = d3.timeFormat("%d %B, %Y")

    var chart_width = width - margin.left - margin.right
    var chart_height = height - margin.top - margin.bottom - 70

    var tableContainer = d3.select(faux)
                          .append('div').attr('id', 'tableContainer')
                          .style('height', chart_height+'px')
                          .style('overflow', 'auto')

    var table = tableContainer.append('table').attr('id', 'tableMetadata')
                .classed('w3-table-all', true)
                .style('table-layout', 'fixed')


    var headerName = ["patID", "siteID", "siteLevel",
                      "dateIn", "dateOut", "sampleID", "samplingDate", "colour"]

    var headerLabel = ["Patient ID", "Location", "Level",
                      "Date In", "Date Out", "Sample ID", "Sampling Date", "Color Index"]

    var headers = table.append('thead').append('tr')
                        .selectAll('th')
                        .data(headerLabel).enter()
                        .append('th')
                        .text(function(d) {return d})
    //var simData = undefined
    var rows = table.append('tbody')
    //console.log(selectedData);

    if (selectedData) {
      if (selectedData.length > 0) {
        rows.selectAll('tr')
        .data(selectedData).enter()
        .append('tr').attr('class', 'tableRow')
        .attr('id', function(d) {return 'tableRow_'+d.entryID })
        .selectAll('td')
        .data(function(d) {
          var entries = []
          headerName.forEach(function(key) {
            if (key === 'dateIn' || key === 'dateOut') {
              entries.push(formatTime(d[key]))
            }
            else if (key === 'samplingDate') {
              if (d[key] !== "N/A") {
                entries.push(formatTime(d[key]))
              }
              else {
                entries.push(d[key])
              }
            }
            else {
              entries.push(d[key].toString())
            }
          })
          return entries
        }).enter()
        .append('td')
        .text(function(d) {
          return d;
        })
      }
      else {
        rows.selectAll('tr')
              .data([0]).enter()
              .append('tr')
              .selectAll('td')
              .data(headerLabel).enter()
              .append('td')
              .text('N/A')
      }
    }
    else {
      rows.selectAll('tr')
            .data([0]).enter()
            .append('tr')
            .selectAll('td')
            .data(headerLabel).enter()
            .append('td')
            .text('null')

    }
    drawFauxDOM()
  }

  updateD3(){

    const faux = this.props.connectFauxDOM('div', 'metadataTableSearch')
    d3.select(faux).select('#tableContainer').remove()
    this.renderD3()
  }
  updateClickedNodes(prevEntryID, entryID){
    const faux = this.props.connectFauxDOM('div', 'metadataTableSearch')
    if (prevEntryID === null) {
      d3.select('#tableRow_'+entryID)
        .style('border', '5px solid black')
    }
    else {
      d3.select('#tableRow_'+prevEntryID)
        .style('border', '1px solid #ccc')
      d3.select('#tableRow_'+entryID)
        .style('border', '5px solid black')
    }
      this.props.drawFauxDOM()
  }
}


export default withFauxDOM(TableViewer)

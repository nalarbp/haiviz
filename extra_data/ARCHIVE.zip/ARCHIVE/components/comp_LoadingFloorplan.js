import React, {Component} from 'react'
import LoadingFloorplanImg from '../img/loadingFloorplan.png';
import {Map, TileLayer } from 'react-leaflet';

//import UploadFile from './component/btn_uploadFile'
//import UploadFileDropbox from './component/btn_uploadFileDropbox'

const position = [51.0, -0.09]


class LoadingFloorplan extends Component {

  render() {
    return (
        <div className="w3-content w3-container">
          <Map
          style={{height: "300px"}}
          center={position}
          zoom={1}>
          <TileLayer
            url='https://api.mapbox.com/styles/v1/nalarbudi/cjgluf4ov00022rq19ybz76r8/tiles/256/{z}/{x}/{y}?access_token=pk.eyJ1IjoibmFsYXJidWRpIiwiYSI6ImNqZ2xxeWoxbzFhZWIzM3MzOXFtdnVmdXIifQ.npRPzXJ-DnFPl5Vm8GoKSg'
            attribution='Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors, <a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="http://mapbox.com">Mapbox</a>' />
          </Map>

        </div>

    )
  }

}

export default LoadingFloorplan
/*
<UploadFileDropbox loadData={this.props.loadData} fileID='metadata'/>

*/

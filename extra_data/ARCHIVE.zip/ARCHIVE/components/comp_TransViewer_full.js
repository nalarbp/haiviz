//Module tree viewer: trans only
import React, {Component} from 'react'
import {withFauxDOM} from 'react-faux-dom'
import * as util from '../utils/utils'
import {event as d3Event} from 'd3'
import CloseChart from '../containers/cont_CloseChart'
import DownloadSVG from './component/btn_downloadSVG'
import {PanelTitle} from './component/btn_utils'
const d3 = {
  ...require('d3-array'),
  ...require('d3-scale'),
  ...require('d3-force'),
  ...require('d3-selection')
}
// props from container: metadata///
class TransViewer extends Component {
  constructor(props){
    super(props)
    this.state= {nodeSize:5,
                  labelSize:5,
                  weightCutoff: 1,
                  linkSource:0,
                  linkTarget:0,
                  weightValue:0,
                  prevRemovedLink: null,
                  prevAddedLink: null}

    this.initiateTrans= this.initiateTrans.bind(this)
    this.reloadTrans= this.reloadTrans.bind(this)

    this.changeNodeSize= this.changeNodeSize.bind(this)
    this.updateNodeSize= this.updateNodeSize.bind(this)

    this.changeLabelSize= this.changeLabelSize.bind(this)
    this.updateLabelSize= this.updateLabelSize.bind(this)

    this.changeWeightCutoff= this.changeWeightCutoff.bind(this)
    this.updateWeightCutoff= this.updateWeightCutoff.bind(this)

    this.changeLinkSource= this.changeLinkSource.bind(this)
    this.changeLinkTarget= this.changeLinkTarget.bind(this)
    this.changeWeightValue= this.changeWeightValue.bind(this)

    this.removeLink= this.removeLink.bind(this)
    this.drawLink= this.drawLink.bind(this)

    this.updateTransBySelectedData= this.updateTransBySelectedData.bind(this)
  }

  componentDidMount(){
    this.initiateTrans()
  }

  shouldComponentUpdate(nextProps, nextStates){
    if (nextStates.nodeSize !== this.state.nodeSize) {
      this.updateNodeSize(nextStates.nodeSize)
      return false;
    }
    else if (nextStates.labelSize !== this.state.labelSize) {
      this.updateLabelSize(nextStates.labelSize)
      return false;
    }
    else if (nextStates.weightCutoff !== this.state.weightCutoff) {
      this.updateWeightCutoff(nextStates.weightCutoff)
      return false;
    }
    else if (nextStates.linkSource !== this.state.linkSource ||
      nextStates.linkTarget !== this.state.linkTarget ||
      nextStates.weightValue !== this.state.weightValue) {
      return false;
    }
    else {
      return true;
    }
  }

  componentDidUpdate(prevProps, prevState){
    if (this.props.selectedData !== prevProps.selectedData ||
    this.props.selectedExtent !== prevProps.selectedExtent) {
      this.updateTransBySelectedData()
    }
    else if (this.props.width !== prevProps.width &&
        this.props.height !== prevProps.height) {
          d3.select('#transmissionSVG').remove()
          d3.select('#trans_refreshDescriptor').classed('w3-show', true)
    }
    else if (this.props.transmission !== prevProps.transmission) {
      this.reloadTrans()
    }
    else if (this.props.colorIndex !== prevProps.colorIndex) {
      this.reloadTrans()
    }

  }
  //event listener node size
  changeNodeSize(e){
    var value = e.target.value
    if (value) {
      this.setState({nodeSize:value})
    }
  }
  updateNodeSize(value){
    d3.selectAll('.trans_node')
      .attr('r', function (d) {
        return value
      })
  }

  //event listener node size
  changeLabelSize(e){
    var value = e.target.value
    if (value) {
      this.setState({labelSize:value})
    }
  }
  updateLabelSize(value){
    d3.selectAll('.trans_nodeLabel')
      .attr('font-size', function(d) {
        return value + 'px';
      })
    d3.selectAll('.trans_linksLabel')
    .attr('font-size', function(d) {
      return value-3 + 'px';
    })
  }

  //event listener edge weight cutoff
  changeWeightCutoff(e){
    var value = e.target.value
    if (value) {
      this.setState({weightCutoff:parseFloat(value)})
    }
  }
  updateWeightCutoff(value){
    let {connectFauxDOM, drawFauxDOM} = this.props,
     faux = connectFauxDOM('div', 'transViewer')
    d3.select(faux).selectAll('.trans_link')
      .style('opacity', function(d) {
        if (d.weight < value) {
          return 100
        } else {
          return 0
        }
      })
    d3.select(faux).selectAll('.trans_linksLabel')
      .style('opacity', function(d) {
        if (d.weight < value) {
          return 100;
        } else {
          return 0;
        }
      })
    drawFauxDOM()
  }

  // event listener edge ids
  changeLinkSource(e){
    var value = e.target.value
    if (value) {
      this.setState({linkSource:parseInt(value, 10)})
    }
  }
  changeLinkTarget(e){
    var value = e.target.value
    if (value) {
      this.setState({linkTarget:parseInt(value, 10)})
    }
  }
  changeWeightValue(e){
    var value = e.target.value
    if (value) {
      this.setState({weightValue:parseFloat(value)})
    }
  }

  removeLink(){
    var targetLinkID = this.state.linkTarget,
        sourceLinkID = this.state.linkSource,
        currentTransData = this.props.transmission,
        weight = this.state.weightValue

    var newTransmissionData = util.updateTransData(sourceLinkID, targetLinkID, currentTransData, weight ,'remove')
    this.props.updateTransmissionData(newTransmissionData)
  }
  drawLink(){
    var targetLinkID = this.state.linkTarget,
        sourceLinkID = this.state.linkSource,
        currentTransData = this.props.transmission,
        weight = this.state.weightValue,
    newTransmissionData = util.updateTransData(sourceLinkID, targetLinkID, currentTransData, weight,'add')

    this.props.updateTransmissionData(newTransmissionData)
    //process addition here
  }

  updateTransBySelectedData(){
    var {connectFauxDOM, drawFauxDOM, colorIndex} = this.props,
     nodeSizeState = this.state.nodeSize,
     faux = connectFauxDOM('div', 'transViewer'),
     container = d3.select(faux)

    if (this.props.selectedData &&
        this.props.selectedExtent &&
        this.props.selectedExtent.length !== 0) {
      var dateExtent = this.props.selectedExtent,
          selectedEntryIDs = this.props.selectedData.map(function(d) {return d.entryID})

       container.selectAll('.trans_node')
       .attr('r', function(d) {
         if (selectedEntryIDs.indexOf(d.meta.entryID) !== -1 &&
             d.meta.samplingDate < dateExtent[1] &&
             d.meta.samplingDate > dateExtent[0]) {
           return 2*nodeSizeState
         } else {
           return nodeSizeState
         }
       })
       .attr('fill', function(d) {
         if (selectedEntryIDs.indexOf(d.meta.entryID) !== -1 &&
             d.meta.samplingDate < dateExtent[1] &&
             d.meta.samplingDate > dateExtent[0]) {
           return util.fillWithColorIndex(d.meta, colorIndex)
         } else {
           return 'lightgray'
         }
       })


    }
    else if (this.props.selectedData && this.props.selectedData.length !== 0) {
       var selectedEntryIDs = this.props.selectedData.map(function(d) {return d.entryID})

       container.selectAll('.trans_node')
       .attr('r', function(d) {
         if (selectedEntryIDs.indexOf(d.meta.entryID) !== -1) {
           return 2*nodeSizeState
         } else {
           return nodeSizeState
         }
       })
         .attr('fill', function(d) {
           if (selectedEntryIDs.indexOf(d.meta.entryID) !== -1) {
             return util.fillWithColorIndex(d.meta, colorIndex)
           } else {
             return 'lightgray'
           }
         })
        .style('z-index', function(d) {
          if (selectedEntryIDs.indexOf(d.meta.entryID) !== -1) {
            return 5
          }
        })
    }
    else {
      //do nothing
    }
    drawFauxDOM()
  }

  openSetting() {
    var el = document.getElementById('TransController')
    el.className = "w3-sidebar w3-border-bottom w3-show-block"
    el.style="height:auto;right:0"
  }
  closeSetting(){
    document.getElementById('TransController').className = "w3-hide"
  }

  reloadTrans(){
      d3.select('#transmissionSVG').remove()
      d3.select('#trans_refreshDescriptor').classed('w3-show', false)
      this.initiateTrans()
  }

  render() {
    const {transViewer: transViewer} = this.props
    return (
      <div id='transmission' className= 'w3-row'>

        <div className= 'panelHeader w3-row w3-dark-grey'>
          <PanelTitle titleText={"Transmission Pathways"}></PanelTitle>
          <div id="tree_setting" className= 'w3-col m6 w3-right'>
            <CloseChart id='transmission'/>
            <DownloadSVG id='transmissionSVG'/>
            <div id='settingButton' className='w3-right'>
              <button onClick={this.openSetting}
                      className="w3-button w3-medium w3-hover-none">
                      <i className="fa fa-wrench fa-lg"></i>
              </button>
            </div>
            <div id='refreshButton' className='w3-right'>
              <button onClick={this.reloadTrans}
                      className="w3-button w3-medium w3-hover-none">
                      <i className="fa fa-refresh fa-lg"></i>
              </button>
            </div>
          </div>
        </div>

        <div id="TransController" className= "w3-sidebar w3-tiny w3-border-right w3-behind w3-hide">
          <div className= "w3-right" >
            <button onClick={this.closeSetting}
                    className="w3-button w3-medium w3-hover-none">
                    <i className="fa fa-times-circle fa-lg"></i></button>
          </div>
          <div id='nodeSize' className='w3-container'>
            <label>Node size</label>
            <input onChange={this.changeNodeSize} type="range" min='0' max='10' className='w3-input w3-border'></input>
          </div>
          <div id='labelSize' className='w3-container '>
            <label>Label size</label>
            <input onChange={this.changeLabelSize} type="range" min='0' max='20' className='w3-input w3-border'></input>
          </div>
          <div id='weightCutoff' className='w3-container '>
            <label>Links weight cutoff</label>
            <input onChange={this.changeWeightCutoff} type="number" min='0' className='w3-input w3-border'></input>
          </div>
          <div id='editingLinks' className='w3-container '>
            <label>Source link id</label>
            <input onChange={this.changeLinkSource} type="number" className='w3-input w3-border'></input>
            <label>Target link id</label>
            <input onChange={this.changeLinkTarget} type="number" className='w3-input w3-border'></input>
            <label>New links's weight</label>
            <input onChange={this.changeWeightValue} type="number" min='0' className='w3-input w3-border'></input>
          </div>
          <div id='removeLink' className='w3-container w3-margin-top'>
            <button onClick={this.removeLink} className='w3-button w3-tiny w3-round w3-green'>Remove link</button>
          </div>
          <div id='addLink' className='w3-container w3-margin-bottom'>
            <button onClick={this.drawLink} className='w3-button w3-tiny w3-round w3-green'>Draw new link</button>
          </div>
        </div>

        <div id='trans_tooltip' className='w3-container w3-small w3-white w3-row'>
          <div id='tooltip_info_icon' className='w3-text-white w3-col s1'>
            <p>.<i className="fa fa-info-circle fa-lg w3-text-black"></i></p>
          </div>
          <div id='trans_tooltip_text' className='w3-col s11 w3-text-left'>
            <p></p>
          </div>
        </div>

        <div id= 'transSVGviewer' className= 'w3-center'>
          <h6 id='trans_refreshDescriptor'
             className='w3-hide'>
             Redraw chart using reload button on the top right corner of this window
           </h6>
          {transViewer}
        </div>
      </div>
    )
  }

  initiateTrans(){
    ///console.log(this.props.transmission);
    var {metadata, colorIndex, height, width, connectFauxDOM, drawFauxDOM, selectActiveData} = this.props,
        {weightCutoff, nodeSize, labelSize} = this.state,
        margin = {'top': 10, 'right': 50, 'bottom': 20, 'left': 20},
        faux = connectFauxDOM('div', 'transViewer'),
        tooltipID = 'trans_tooltip_text',
        trans_height = height - 100 - margin.top - margin.bottom,
        trans_width = width - margin.left - margin.right,
        defaultTickNumber = 30

    var transmission = JSON.parse(JSON.stringify(this.props.transmission))
    //nodes transformation: get the name, search on metadata, return new object
    //metadata:{all records}
    transmission.nodes.forEach(function(d) {
      let name = d.name
      d['meta'] = util.getMetadataFromNodeName(name, metadata)
    })



    var trans_svg = d3.select(faux)
    //reset zoom and loation
    d3.select('#trans_svgGroup').attr('transform', 'translate(' + margin.left + ',' + margin.top + ') scale(1)')

    //make svg root
    var svg = trans_svg.append('svg').attr('id', 'transmissionSVG')
                .attr('width', trans_width + margin.left + margin.right)
                .attr('height', trans_height + margin.top + margin.bottom)

    var svgGroup = svg.append('g').attr('id', 'trans_svgGroup')
                          .attr('transform', 'translate(' + margin.left + ',' + margin.top + ')')

    var trans_sim = d3.forceSimulation(transmission.nodes)
                      .force('center', d3.forceCenter(trans_width / 2, trans_height / 2))
                      .force('charge', d3.forceManyBody().strength(-50))
                      .force('link', d3.forceLink().links(transmission.links).distance(50))
                      .stop()
                //.on('tick', ticked)
    for (var i = 0; i < defaultTickNumber; i++) {trans_sim.tick()}

    //make arrow Group
    var arrowGroupBlack = svgGroup.append('g').attr('id', 'arrowGroupBlack')
                        .append("defs").append("marker")
                        .attr("id", 'trans_arrow_black')
                        .attr("refX", 15)
                        .attr("refY", 2)
                        .attr("markerWidth", 12)
                        .attr("markerHeight", 12)
                        .attr("orient", "auto")
                        .append("path")
                        .attr("d", "M0,0 L0,4 L4,2 Z")
                        .attr('fill', 'black')

    //make link group
    var linksGroup = svgGroup.append('g').attr('id', 'linksGroup')
    var linksLabel = linksGroup.selectAll('.trans_linksLabel')
                                .data(transmission.links)
                                .enter()
                                .append('text')
                                .attr('class', 'trans_linksLabel')
                                .attr("x", function(d) {
                                  //console.log(d.source, d.target, d.weight);
                                  return (d.target.x + d.source.x)/2
                                })
                                .attr("y", function(d) {
                                  return (d.target.y + d.source.y)/2
                                })
                                .attr("text-anchor", "start")
                                .attr('font-size', labelSize)
                                .attr('fill', 'red')
                                .text(function(d) { return String(d.weight) })
                                .style('opacity', function(d) {
                                  if (d.weight < weightCutoff) {
                                    return 100;
                                  } else {
                                    return 0;
                                  }
                                })

    var linkLine = linksGroup.selectAll('.trans_link')
                            .data(transmission.links)
                            .enter()
                            .append('line').attr('class', 'trans_link')
                            .attr("x1", function(d) {return d.source.x})
                            .attr("y1", function(d) {return d.source.y})
                            .attr("x2", function(d) {return d.target.x})
                            .attr("y2", function(d) {return d.target.y})
                            .attr('stroke',  'black')
                            .attr('stroke-width', '1px')
                            .style('fill', 'none')
                            .attr('marker-end', function(d) {
                              return 'url(#trans_arrow_black)'
                            })
                            .style('opacity', function(d) {
                              if (d.weight < weightCutoff) {
                                return 100;
                              } else {
                                return 0;
                              }
                            })



    //draw nodes
    //= Math.max(60, Math.min(trans_height - 60, d.y))

    var nodesGroup = svgGroup.append('g').attr('id', 'nodesGroup')
    var nodeCircle = nodesGroup.selectAll('.trans_node')
                            .data(transmission.nodes)
                            .enter()
                            .append('circle').attr('class', 'trans_node')
                            .attr('r', this.state.nodeSize)
                            .attr('stroke', 'black')
                            .attr('stroke-width', '2px')
                            .attr("cx", function(d){
                              if (d.x > trans_width) {
                                return d.x = Math.max(100, Math.min(trans_width - 100, d.y))
                              } else {
                                return d.x
                              }
                              })
                            .attr("cy", function(d){
                              if (d.y > trans_height) {
                                return d.y = Math.max(100, Math.min(trans_height - 100, d.y))
                              } else {
                                return d.y
                              }
                            })
                            .attr('fill', function(d) {
                              //return 'black'
                              return util.fillWithColorIndex(d.meta, colorIndex)
                            })
                            .style('cursor', 'move')
                            .on('mouseover', function(d) {
                              showTooltip('#'+tooltipID, d)})
                            .on('mouseout', function(d) {
                              hideTooltip('#'+tooltipID)
                            })
                            .on('click', function(d) {
                              //d.meta.entryID
                              //getSelectedData d.meta.entryID

                              var activeData = util.getDatafromEntryID(metadata, d.meta.entryID)
                              selectActiveData({selectedData: activeData, selectedExtent: undefined})
                              //console.log(activeData);
                            })

    var nodeLabel = nodesGroup.selectAll('.trans_nodeLabel')
                            .data(transmission.nodes)
                            .enter()
                            .append("text")
                            .attr('class', 'trans_nodeLabel')
                            .attr("x", function(d){return d.x + 10})
                            .attr("y", function(d){return d.y})
                            .attr("text-anchor", "start")
                            .attr('font-size', labelSize)
                            .attr('fill', 'black')
                            .text(function(d) { return d.name })

    //drag & zoom event
    var zoomLevel = 1, isZoomed = false,
    isMouseDown = false,
    currentX, currentY, initialX, initialY,
    xOffset = 0, yOffset = 0

    svg.on('mousedown', function() {
            isMouseDown = true
            initialX = d3Event.clientX - xOffset
            initialY = d3Event.clientY - yOffset})
        .on('mousemove', function() {
            if (isMouseDown) {
                currentX = d3Event.clientX - initialX
                currentY = d3Event.clientY - initialY
                //offset
                xOffset = currentX
                yOffset = currentY
                //move it
                moveIt('#trans_svgGroup', currentX, currentY, zoomLevel)
            }
          })
        .on('mouseup', function() {
          initialX = currentX
          initialY = currentY
          isMouseDown = false
        })

    // Event: zoom
    svg.on('wheel.zoom', function() {
      if (d3Event.deltaY > 0 && zoomLevel < 4 ) {
        zoomLevel += 0.15
        zoomed('#trans_svgGroup', zoomLevel)
      }
      else if (d3Event.deltaY < 0 && zoomLevel > 0.2 ) {
        zoomLevel -= 0.15
        zoomed('#trans_svgGroup', zoomLevel)
      }
    })
    //Listener: zoomed
    function zoomed(transformID, newLevel) {
        var newMarginV = ((trans_height * newLevel) - trans_height)/2,
            newMarginH = ((trans_width * newLevel) - trans_width)/2
        if (currentX || currentY) {
          d3.select(transformID)
            .attr('transform', 'translate(' + (currentX) + ',' + (currentY) + ') scale(' + newLevel + ')')
        }
        else {
          d3.select(transformID)
            .attr('transform', 'translate(' + (margin.left) + ',' + (margin.top) + ') scale(' + newLevel + ')')
        }
      }
    //Listener: dragged
    function moveIt(transformID, posX, posY, currentZoomLevel) {
      d3.select(transformID)
        .attr('transform', 'translate(' + posX + ',' + posY + ') scale(' + currentZoomLevel + ')')
      }
      // Event: zoom
    svg.on('wheel.zoom', function() {
      if (d3Event.deltaY > 0 && zoomLevel < 4 ) {
        //var initial = floorplanZoomLevel + 0.2
        zoomLevel += 0.15
        //updateFloorplanZoomLevel(num)
        zoomed('#trans_svgGroup', zoomLevel)
      }
      else if (d3Event.deltaY < 0 && zoomLevel > 0.2 ) {
        //var reducedLevel = floorplanZoomLevel - 0.2
        zoomLevel -= 0.15
        //updateFloorplanZoomLevel(num)
        zoomed('#trans_svgGroup', zoomLevel)
      }
    })

    //tooltip_local
    function showTooltip(tooltipID, data, locX, locY) {
      var tooltip = d3.select(tooltipID)
                      .html('<p id="trans_tooltip_content" >' +
                            'Host: '+data.meta.patID+
                            '<span>&nbsp&nbsp&nbsp&nbsp</span>'+
                            'Location: ' +data.meta.siteID +
                            '<span>&nbsp&nbsp&nbsp&nbsp</span>'+
                            'Node id: ' +data.id +
                            '</p>')

    }

    function hideTooltip(tooltipID) {
      d3.select('#trans_tooltip_content').remove()
    }

    drawFauxDOM()
  }

}

export default withFauxDOM(TransViewer)

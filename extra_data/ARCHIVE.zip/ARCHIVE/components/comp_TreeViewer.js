//Module tree viewer: tree only
import React, { Component } from "react";
import { withFauxDOM } from "react-faux-dom";
import newickParse from "../utils/newick";
import * as util from "../utils/utils";
import { event as d3Event } from "d3";
const d3 = {
  ...require("d3-hierarchy"),
  ...require("d3-array"),
  ...require("d3-scale"),
  ...require("d3-axis"),
  ...require("d3-drag"),
  ...require("d3-shape"),
  ...require("d3-selection")
};
///re-render when props changed. Props come from treeContainer's state
class TreeViewer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      nodeSize: 5,
      labelSize: 5,
      scaleFactor: 1,
      currentbranchLength: null,
      customScale: 1
    };

    this.initiateTree = this.initiateTree.bind(this);
    this.reloadTree = this.reloadTree.bind(this);

    this.changeNodeSize = this.changeNodeSize.bind(this);
    this.updateNodeSize = this.updateNodeSize.bind(this);

    this.changeLabelSize = this.changeLabelSize.bind(this);
    this.updateLabelSize = this.updateLabelSize.bind(this);

    this.changeScaleFactor = this.changeScaleFactor.bind(this);
    this.changeCustomScale = this.changeCustomScale.bind(this);

    this.updateScale = this.updateScale.bind(this);
  }
  //
  componentDidMount() {
    this.initiateTree();
  }

  shouldComponentUpdate(nextProps, nextStates) {
    if (nextStates.nodeSize !== this.state.nodeSize) {
      this.updateNodeSize(nextStates.nodeSize);
      return false;
    } else if (nextStates.labelSize !== this.state.labelSize) {
      this.updateLabelSize(nextStates.labelSize);
      return false;
    } else if (
      nextStates.scaleFactor !== this.state.scaleFactor ||
      nextStates.customScale !== this.state.customScale ||
      nextStates.currentbranchLength !== this.state.currentbranchLength
    ) {
      return false;
    } else {
      return true;
    }
  }
  componentDidUpdate(prevProps, prevState) {
    if (
      this.props.width !== prevProps.width &&
      this.props.height !== prevProps.height
    ) {
      this.reloadTree();
    }
  }
  //event listener node size
  changeNodeSize(e) {
    var value = e.target.value;
    if (value) {
      this.setState({ nodeSize: value });
    }
  }
  updateNodeSize(value) {
    d3.selectAll(".tree_nodeCircle").attr("r", function(d) {
      return value;
    });
  }

  //event listener node size
  changeLabelSize(e) {
    var value = e.target.value;
    if (value) {
      this.setState({ labelSize: value });
    }
  }
  updateLabelSize(value) {
    d3.selectAll(".tree_nodeLabel").attr("font-size", function(d) {
      return value + "px";
    });
  }
  //event listener for scale factor
  changeScaleFactor(e) {
    var value = e.target.value;
    if (value) {
      this.setState({ scaleFactor: value });
    }
  }

  changeCustomScale(e) {
    var value = e.target.value;
    if (value) {
      this.setState({ customScale: value });
    }
  }

  updateScale() {
    //
    var margin = { top: 10, right: 50, bottom: 20, left: 20 },
      { height, width, connectFauxDOM, drawFauxDOM } = this.props,
      tree_height = height - 40 - margin.top - margin.bottom,
      s_width = width - margin.left - margin.right,
      m_width = (width * 10) / 12 - margin.left - margin.right,
      tree_width = width > 640 ? m_width : s_width,
      faux = connectFauxDOM("div", "treeViewer"),
      branchLength = this.state.currentbranchLength,
      newBranchLength = branchLength * this.state.scaleFactor,
      newScale = parseInt(this.state.customScale, 10),
      y_scale = d3
        .scaleLinear()
        .domain([0, newBranchLength])
        .range([0, tree_width - 50]),
      y_axis = d3
        .axisBottom()
        .scale(y_scale)
        .ticks();

    d3.select(faux)
      .select("#treeSVG")
      .select("#svgGroup_tree")
      .select("#treeScaleGroup")
      .remove();
    var scaleGroup = d3
      .select("#svgGroup_tree")
      .append("g")
      .attr("id", "treeScaleGroup");

    scaleGroup
      .append("g")
      .attr("transform", "translate(0," + (tree_height - 30) + ")")
      .append("line")
      .attr("x1", 0)
      .attr("y1", 0)
      .attr("x2", function() {
        return y_scale(newScale);
      })
      .attr("y2", 0)
      .attr("stroke", "black");

    scaleGroup
      .append("g")
      .attr("transform", "translate(0," + (tree_height - 28) + ")")
      .append("line")
      .attr("x1", 0)
      .attr("y1", -3)
      .attr("x2", 0)
      .attr("y2", 3)
      .attr("stroke", "black");

    scaleGroup
      .append("g")
      .attr("transform", "translate(0," + (tree_height - 28) + ")")
      .append("line")
      .attr("x1", function() {
        return y_scale(newScale);
      })
      .attr("y1", -3)
      .attr("x2", function() {
        return y_scale(newScale);
      })
      .attr("y2", 3)
      .attr("stroke", "black");

    scaleGroup
      .append("g")
      .attr("transform", "translate(0," + (tree_height - 10) + ")")
      .append("text")
      .attr("x", 0)
      .attr("y", 0)
      .attr("font-size", "12px")
      .text(function() {
        return newScale;
      });

    drawFauxDOM();
  }

  render() {
    const { treeViewer: treeViewer } = this.props;
    return (
      //produce only tree viewer
      <div className="w3-row">
        <div id="TreeController" className="w3-col m2">
          <div
            id="nodeSize"
            className="w3-container w3-margin-top w3-margin-bottom"
          >
            <label>Node size</label>
            <input
              onChange={this.changeNodeSize}
              type="range"
              min="0"
              max="10"
              className="w3-input w3-border"
            ></input>
          </div>
          <div id="labelSize" className="w3-container w3-margin-bottom">
            <label>Label size</label>
            <input
              onChange={this.changeLabelSize}
              type="range"
              min="5"
              max="20"
              className="w3-input w3-border"
            ></input>
          </div>
          <div id="scaleFactor" className="w3-container">
            <label>Scale factor</label>
            <input
              onChange={this.changeScaleFactor}
              type="number"
              min="1"
              className="w3-input w3-border"
            ></input>
          </div>
          <div id="customScale" className="w3-container">
            <label>Custom scale</label>
            <input
              onChange={this.changeCustomScale}
              type="number"
              min="1"
              className="w3-input w3-border"
            ></input>
          </div>
          <div
            id="submitScale"
            className="w3-container w3-margin-top w3-margin-bottom"
          >
            <button
              onClick={this.updateScale}
              className="w3-button w3-round w3-green"
            >
              Change scale
            </button>
          </div>
        </div>
        <div id="treeSVGviewer" className="w3-light-gray w3-col m10">
          {treeViewer}
        </div>
      </div>
    );
  }

  initiateTree() {
    //console.log('initiating tree')
    //var dummyNewickData = '(Bovine:0.69395,(Hylobates:0.36079,(Pongo:0.33636,(G._Gorilla:0.17147, (P._paniscus:0.19268,H._sapiens:0.11927):0.08386):0.06124):0.15057):0.54939, Rodent:1.21460);'
    var margin = { top: 10, right: 50, bottom: 20, left: 20 },
      { tree, height, width, connectFauxDOM, drawFauxDOM } = this.props,
      tree_height = height - 40 - margin.top - margin.bottom,
      s_width = width - margin.left - margin.right,
      m_width = (width * 10) / 12 - margin.left - margin.right,
      tree_width = width > 640 ? m_width : s_width,
      treeJSON = newickParse(tree),
      faux = connectFauxDOM("div", "treeViewer"),
      root = d3.hierarchy(treeJSON, d => d.branchset),
      clusterLayout = d3.cluster().size([tree_height - 50, tree_width]);
    clusterLayout(root);

    var nodes = root.descendants(),
      links = root.links(),
      treeHasLength = util.isTreeHasLength(nodes);

    //reposition the leaf nodes
    var branchLengthRange = nodes.map(function(d) {
        if (treeHasLength) {
          return util.hasParrent(d);
        }
      }),
      treeBranchLenExtent = d3.extent(branchLengthRange),
      treeBranchDepthExtent = d3.extent(
        nodes.map(function(d) {
          return d.depth;
        })
      ),
      branchLength = treeHasLength
        ? treeBranchLenExtent
        : treeBranchDepthExtent,
      y_scale = d3
        .scaleLinear()
        .domain([0, branchLength[1]])
        .range([0, tree_width - 50]);

    this.setState({ currentbranchLength: branchLength[1] });

    //console.log(treeBranchLenExtent);
    nodes.forEach(function(d) {
      if (treeHasLength) {
        d.y = y_scale(util.hasParrent(d));
      } else {
        d.y = y_scale(d.depth);
      }
    });

    var y_axis = d3
      .axisBottom()
      .scale(y_scale)
      .ticks();

    var tree_svg = d3.select(faux);

    d3.select("#svgGroup_tree").attr(
      "transform",
      "translate(" + margin.left + "," + margin.top + ") scale(1)"
    );

    var svg = tree_svg
      .append("svg")
      .attr("id", "treeSVG")
      .attr("width", tree_width + margin.right)
      .attr("height", tree_height + margin.bottom);

    var svgGroup = svg
      .append("g")
      .attr("id", "svgGroup_tree")
      .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

    //draw nodes
    svgGroup
      .append("g")
      .selectAll("g.node")
      .data(nodes)
      .enter()
      .append("g")
      .attr("class", function(n) {
        if (n.children) {
          if (n.depth === 0) {
            return "tree_root node";
          } else {
            return "tree_inner node";
          }
        } else {
          return "tree_leaf node";
        }
      })
      .attr("transform", function(d) {
        return "translate(" + d.y + "," + d.x + ")";
      });

    //draw label
    svgGroup
      .selectAll("g.tree_leaf.node")
      .append("text")
      .attr("class", "tree_nodeLabel")
      .attr("dx", 12)
      .attr("dy", 3)
      .attr("text-anchor", "start")
      .attr("font-size", "10px")
      .attr("fill", "black")
      .text(d => d.data.name);

    //show root node (red circle)
    //svgGroup.selectAll('g.tree_root.node')
    //  .append("circle")
    //  .attr('class', 'tree_rootCircle')
    //  .attr('r', 5)
    //  .attr('fill', 'red')

    //show internal node (blue circle)
    //svgGroup.selectAll('g.tree_inner.node')
    //  .append("circle")
    //  .attr('class', 'tree_internalCircle')
    //  .attr('r', 5)
    //  .attr('fill', 'blue')

    //draw leaf node (black circle)
    svgGroup
      .selectAll("g.tree_leaf.node")
      .append("circle")
      .attr("class", "tree_nodeCircle")
      .attr("r", 5)
      .attr("fill", "black");

    //draw links
    svgGroup
      .append("g")
      .selectAll(".tree_link")
      .data(links)
      .enter()
      .append("path")
      .attr("class", "tree_link")
      .attr("d", d => util.tree_pathGenerator(d))
      .attr("stroke", "black")
      .attr("fill", "none");

    //draw axis
    //svgGroup.append('g').attr('id', 'gAxisY')
    //               .attr("transform", "translate(0," + (tree_height - 40) + ")")
    //               .call(y_axis);

    //draw scale line
    var scaleGroup = svgGroup.append("g").attr("id", "treeScaleGroup");
    scaleGroup
      .append("g")
      .attr("transform", "translate(0," + (tree_height - 30) + ")")
      .append("line")
      .attr("x1", 0)
      .attr("y1", 0)
      .attr("x2", function() {
        return y_scale(Math.ceil(0.25 * branchLength[1]));
      })
      .attr("y2", 0)
      .attr("stroke", "black");

    scaleGroup
      .append("g")
      .attr("transform", "translate(0," + (tree_height - 28) + ")")
      .append("line")
      .attr("x1", 0)
      .attr("y1", -3)
      .attr("x2", 0)
      .attr("y2", 3)
      .attr("stroke", "black");

    scaleGroup
      .append("g")
      .attr("transform", "translate(0," + (tree_height - 28) + ")")
      .append("line")
      .attr("x1", function() {
        return y_scale(Math.ceil(0.25 * branchLength[1]));
      })
      .attr("y1", -3)
      .attr("x2", function() {
        return y_scale(Math.ceil(0.25 * branchLength[1]));
      })
      .attr("y2", 3)
      .attr("stroke", "black");

    scaleGroup
      .append("g")
      .attr("transform", "translate(0," + (tree_height - 10) + ")")
      .append("text")
      .attr("x", 0)
      .attr("y", 0)
      .attr("font-size", "12px")
      .text(function() {
        return Math.ceil(0.25 * branchLength[1]);
      });

    drawFauxDOM();
  }
  reloadTree() {
    d3.select("#treeSVG").remove();
    this.initiateTree();
  }
}

export default withFauxDOM(TreeViewer);

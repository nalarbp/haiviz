import React, {Component} from 'react'
import {withFauxDOM} from 'react-faux-dom'
import * as util from '../utils/utils'
import {PanelHeader, TransController} from '../utils/styled'
import DownloadSVG from './component/btn_downloadSVG'
import UploadFile from './component/btn_uploadFile'
import CloseChart from '../containers/cont_CloseChart'
import TransThresholdController from '../containers/cont_TransThresholdController'
import {event as d3Event} from 'd3'
const d3 = {
  ...require('d3-hierarchy'),
  ...require('d3-array'),
  ...require('d3-scale'),
  ...require('d3-force'),
  ...require('d3-axis'),
  ...require('d3-time'),
  ...require('d3-shape'),
  ...require('d3-selection')
}
// props from container: metadata
class TransChart extends Component {
  constructor(props){
    super(props)
  this.renderD3= this.renderD3.bind(this)
  this.renderTransOnly = this.renderTransOnly.bind(this)
  }
//
  componentDidUpdate(prevProps, prevState){
    //when user provide metadata
    if (this.props.metadata && this.props.transmission) {
      if (this.props.transmission && this.props.transmission !== prevProps.transmission) {
        this.updateD3()

      }
      else if (this.props.transmission &&
              this.props.width !== prevProps.width &&
              this.props.height !== prevProps.height) {

        this.updateD3()
      }
      else if (this.props.filteredEntryID !== null && this.props.filteredEntryID !== prevProps.filteredEntryID) {

        this.updateNodes(this.props.filteredEntryID)
      }
      else if (this.props.clickedElement !== null && this.props.clickedElement != prevProps.clickedElement ) {
        //console.log('balik dari store', this.props.clickedElement, prevProps.clickedElement );
        this.updateClickedNodes(this.props.clickedElement)
      }
      else if (this.props.transLinkThreshold !== null && this.props.transLinkThreshold != prevProps.transLinkThreshold ) {
        this.updateLinks(this.props.transLinkThreshold)
      }
    }
    //when user dont provide metadata
    else {
      if (this.props.transmission && this.props.transmission !== prevProps.transmission) {
        this.updateTransOnly()
      }
      else if (this.props.transmission && this.props.width !== prevProps.width &&
                this.props.height !== prevProps.height) {
        this.updateTransOnly()
      }
      else if (this.props.transLinkThreshold !== null && this.props.transLinkThreshold != prevProps.transLinkThreshold ) {
        this.updateLinks(this.props.transLinkThreshold)
      }
    }
  }

  render() {
    const {chart: chart} = this.props
    return (
      <div style={{width: '100%', height: '100%'}}>
        <PanelHeader className='panelHeader'>
          <div className='panelTitle'>Transmission Pathways</div>
          <CloseChart id='transmission'/>
          <DownloadSVG svgID="transmissionSVG"/>
        </PanelHeader>
        <TransController className='TransController'>
          <TransThresholdController/>
        </TransController>
        {chart}
      </div>
    )
  }

  renderD3(){
    const transData = this.props.transmission
    const {setTransLinkThreshold, transLinkThreshold, updateClickedElement, clickedElement, siteColor, metadata,
            width, height, connectFauxDOM, animateFauxDOM} = this.props
    const faux = connectFauxDOM('div', 'chart')
    const margin = {'top': 0, 'right': 15, 'bottom': 80, 'left': 60}
    var trans_width = width - margin.left - margin.right
    //panelHeader height 40; controller 70
    var trans_height = height- margin.top - margin.bottom - 110
    var zoomLevel = 1
    var labelFontSize = 11
    var dragStartX, dragStartY, isMouseDown, dragTimeStamp
    var translateX = margin.left
    var translateY = margin.top

    var container = d3.select(faux)
    //reset zoom and loation
    d3.select('#svgGroupRoot').attr('transform', 'translate(' + margin.left + ',' + margin.top + ') scale(1)')
    //make svg root
    var svg = container.append('svg').attr('id', 'transmissionSVG')
                .attr('width', trans_width + margin.left + margin.right)
                .attr('height', trans_height + margin.top + margin.bottom)
    var svgGroupRoot = svg.append('g').attr('id', 'svgGroupRoot')
                          .attr('transform', 'translate(' + margin.left + ',' + margin.top + ')')
    //border
    //svgGroupRoot.append('rect')
    //            .attr('width', trans_width + margin.left + margin.right)
    //            .attr('height', trans_height + margin.top + margin.bottom)
    //            .style('fill', 'pink')
    //make node group
    var nodesGroup = svgGroupRoot.append('g').attr('id', 'nodesGroup')
    var nodeCircle = nodesGroup.selectAll('.trans_node')
                            .data(transData.nodes)
                            .enter()
                            .append('circle').attr('class', 'trans_node')
                            .attr('r', 7)
                            .attr('fill', function(d) {
                              var siteID =  util.getSiteIDfromSampleID(d.name, metadata)
                              return siteColor[siteID]
                            })
    //make arrow Group
    var arrowGroup = svgGroupRoot.append('g').attr('id', arrowGroup)
                        .append("defs").append("marker")
                        .attr("id", 'trans_arrow')
                        .attr("refX", 5)
                        .attr("refY", 2)
                        .attr("markerWidth", 12)
                        .attr("markerHeight", 12)
                        .attr("orient", "auto")
                        .append("path")
                        .attr("d", "M0,0 L0,4 L4,2 Z")

    //make link group
    var linksGroup = svgGroupRoot.append('g').attr('id', 'linksGroup')
    var linkPath = linksGroup.selectAll('.trans_link')
                            .data(transData.links)
                            .enter()
                            .append('path').attr('class', 'trans_link')
                            .attr("id", function(d,i) { return "transLink_"+i; })
                            .attr('stroke', 'black')
                            .attr('stroke-width', '1px')
                            .style('fill', 'none')
                            .attr('marker-end', function(d) {
                              return 'url(#trans_arrow)'
                            })

    //make node label
    var nodesLabelGroup = svgGroupRoot.append('g').attr('id', 'nodesLabelGroup')
    var nodeLabel = nodesLabelGroup.selectAll('.trans_nodeLabel')
                      .data(transData.nodes).enter()
                      .append('text').attr('class', 'trans_nodeLabel')
                      .text(function(d) {
                        return d.name})
                      .style("font-size", "10px")
    //make link label
    var linksLabelGroup = svgGroupRoot.append('g').attr('id', 'linksLabelGroup')
    var linkLabel = linksLabelGroup.selectAll('.trans_linkLabel')
                                   .data(transData.links)
                                   .enter().append('text').attr('class', 'trans_linkLabel')
                                   .append('textPath')
                                   .attr("xlink:href",function(d,i){return "#transLink_"+i;}) //place the ID of the path here
                                   .style("text-anchor","middle") //place the text halfway on the arc
                                   .attr("startOffset", "50%")
                                   .text(d => parseFloat(d.weight))
                                   .style("font-size", "10px")



    //start simulation
    var trans_simulation = d3.forceSimulation()
                              .force('center', d3.forceCenter(0, trans_height / 2))
                              .force('charge', d3.forceManyBody().strength(8))
                              .force('collision', d3.forceCollide().radius(30))
                              .force('link', d3.forceLink().id(d => d.id))

    trans_simulation.nodes(transData.nodes)
                      .on('tick', ticked)
                    .force('link')
                      .links(transData.links)
                      //.distance(10)

    function ticked() {
        nodeCircle.attr('cx', d => d.x).attr('cy', d => d.y)
        linkPath.attr("d", function(d) {
                      var dx = d.target.x - d.source.x,
                          dy = d.target.y - d.source.y,
                          dr = Math.sqrt(dx * dx + dy * dy);
                      return "M" +
                          d.source.x + "," +
                          d.source.y + "A" +
                          dr + "," + dr + " 0 0,1 " +
                          d.target.x + "," +
                          d.target.y
                        })
        nodeLabel.attr('x', d => d.x+10).attr('y', d => d.y+10)
    }

    // Event: zoom
    svg.on('wheel.zoom', function() {
      if (d3Event.deltaY > 0 && zoomLevel < 4 ) {
        //var initial = floorplanZoomLevel + 0.2
        zoomLevel += 0.15
        //updateFloorplanZoomLevel(num)
        zoomed('#svgGroupRoot', zoomLevel)
      }
      else if (d3Event.deltaY < 0 && zoomLevel > 0.2 ) {
        //var reducedLevel = floorplanZoomLevel - 0.2
        zoomLevel -= 0.15
        //updateFloorplanZoomLevel(num)
        zoomed('#svgGroupRoot', zoomLevel)
      }
    })
    // Event: drag
    svg.on('mousedown', function() {
      isMouseDown = true
      dragStartX = d3Event.screenX
      dragStartY = d3Event.screenY})
        .on('mousemove', function() {
          if (isMouseDown) {
            var deltaTimeStamp = d3Event.timeStamp - dragTimeStamp
            if (dragTimeStamp && deltaTimeStamp > 10) {
              var deltaX = d3Event.screenX - dragStartX
              var deltaY = d3Event.screenY - dragStartY
              dragTimeStamp = d3Event.timeStamp
              dragged('#svgGroupRoot', deltaX, deltaY, zoomLevel)
            }
            else {
              dragTimeStamp = d3Event.timeStamp
            }
          }
        })
        .on('mouseup', function() {
          isMouseDown = false
        })
    //Litener: zoomed
    function zoomed(transformID, newLevel) {
        d3.select(transformID)
          .attr('transform', 'translate(' + translateX + ',' + translateY + ') scale(' + newLevel + ')')
      }
    //Listener: dragged
    function dragged(transformID, deltaX, deltaY, currentZoomLevel) {
      translateX += deltaX*0.1
      translateY += deltaY*0.1
      d3.select(transformID)
        .attr('transform', 'translate(' + translateX + ',' + translateY + ') scale(' + currentZoomLevel + ')')
      }

    animateFauxDOM(100000)
  }
  renderTransOnly(){
    const transData = this.props.transmission
    const {setTransLinkThreshold, transLinkThreshold, updateClickedElement, clickedElement, siteColor, metadata,
            width, height, connectFauxDOM, animateFauxDOM} = this.props
    const faux = connectFauxDOM('div', 'chart')
    const margin = {'top': 0, 'right': 15, 'bottom': 80, 'left': 60}
    var trans_width = width - margin.left - margin.right
    //panelHeader height 40; controller 70
    var trans_height = height- margin.top - margin.bottom - 110
    var zoomLevel = 1
    var labelFontSize = 11
    var dragStartX, dragStartY, isMouseDown, dragTimeStamp
    var translateX = margin.left
    var translateY = margin.top
    var container = d3.select(faux)
    //reset zoom and loation
    d3.select('#svgGroupRoot').attr('transform', 'translate(' + margin.left + ',' + margin.top + ') scale(1)')
    //make svg root
    var svg = container.append('svg').attr('id', 'transmissionSVG')
                .attr('width', trans_width + margin.left + margin.right)
                .attr('height', trans_height + margin.top + margin.bottom)
    var svgGroupRoot = svg.append('g').attr('id', 'svgGroupRoot')
                          .attr('transform', 'translate(' + margin.left + ',' + margin.top + ')')
    var nodesGroup = svgGroupRoot.append('g').attr('id', 'nodesGroup')
    var nodeCircle = nodesGroup.selectAll('.trans_node')
                            .data(transData.nodes)
                            .enter()
                            .append('circle').attr('class', 'trans_node')
                            .attr('r', 10)
                            .attr('fill', function(d) {

                              var siteID =  util.getSiteIDfromSampleID(d.name, metadata)

                              return siteColor[siteID]
                              //let colourIdx = util.getColurFromEntryID(d.data.entryID, metadata)
                              //return 'black'

                            })
    //make arrow Group
    var arrowGroup = svgGroupRoot.append('g').attr('id', arrowGroup)
                        .append("defs").append("marker")
                        .attr("id", 'trans_arrow')
                        .attr("refX", 22)
                        .attr("refY", 3)
                        .attr("markerWidth", 16)
                        .attr("markerHeight", 16)
                        .attr("orient", "auto")
                        .append("path")
                        .attr("d", "M0,0 L0,8 L8,5 Z")

    //make link group
    var linksGroup = svgGroupRoot.append('g').attr('id', 'linksGroup')
    var linkPath = linksGroup.selectAll('.trans_link')
                            .data(transData.links)
                            .enter()
                            .append('path').attr('class', 'trans_link')
                            .attr("id", function(d,i) { return "transLink_"+i; })
                            .attr('stroke', 'black')
                            .attr('stroke-width', '1px')
                            .style('fill', 'none')
                            .attr('marker-end', function(d) {
                              return 'url(#trans_arrow)'
                            })

    //make node label
    var nodesLabelGroup = svgGroupRoot.append('g').attr('id', 'nodesLabelGroup')
    var nodeLabel = nodesLabelGroup.selectAll('.trans_nodeLabel')
                      .data(transData.nodes).enter()
                      .append('text').attr('class', 'trans_nodeLabel')
                      .text(function(d) {
                        return d.name})
                      .style("font-size", "20px")
    //make link label
    var linksLabelGroup = svgGroupRoot.append('g').attr('id', 'linksLabelGroup')
    var linkLabel = linksLabelGroup.selectAll('.trans_linkLabel')
                                   .data(transData.links)
                                   .enter().append('text').attr('class', 'trans_linkLabel')
                                   .append('textPath')
                                   .attr("xlink:href",function(d,i){return "#transLink_"+i;}) //place the ID of the path here
                                   .style("text-anchor","middle") //place the text halfway on the arc
                                   .attr("startOffset", "50%")
                                   .text(d => parseFloat(d.weight))
                                   .style("font-size", "12px")

    //start simulation
    var trans_simulation = d3.forceSimulation()
                              .force('center', d3.forceCenter(trans_width, trans_height))
                              .force('charge', d3.forceManyBody().strength(10))
                              .force('collision', d3.forceCollide().radius(20))
                              //.force('link', d3.forceLink().id(d => d.id))

    trans_simulation.nodes(transData.nodes)
    //                  .on('tick', ticked)
    //                .force('link')
    //                  .links(transData.links)
                      //.distance(10)


    function ticked() {
        nodeCircle.attr('cx', d => d.x).attr('cy', d => d.y)

        //nodeCircle.attr("cx", function(d) { return d.x = Math.max(trans_height, Math.min(trans_width - trans_height, d.x)); })
        //          .attr("cy", function(d) { return d.y = Math.max(trans_height, Math.min(trans_height - trans_height, d.y)); });

        linkPath.attr("d", function(d) {
                      var dx = d.target.x - d.source.x,
                          dy = d.target.y - d.source.y,
                          dr = Math.sqrt(dx * dx + dy * dy);
                      return "M" +
                          d.source.x + "," +
                          d.source.y + "A" +
                          dr + "," + dr + " 0 0,1 " +
                          d.target.x + "," +
                          d.target.y
                        })
        nodeLabel.attr('x', d => d.x+10).attr('y', d => d.y+10)
    }

    // Event: zoom
    svg.on('wheel.zoom', function() {
      if (d3Event.deltaY > 0 && zoomLevel < 4 ) {
        //var initial = floorplanZoomLevel + 0.2
        zoomLevel += 0.15
        //updateFloorplanZoomLevel(num)
        zoomed('#svgGroupRoot', zoomLevel)
      }
      else if (d3Event.deltaY < 0 && zoomLevel > 0.2 ) {
        //var reducedLevel = floorplanZoomLevel - 0.2
        zoomLevel -= 0.15
        //updateFloorplanZoomLevel(num)
        zoomed('#svgGroupRoot', zoomLevel)
      }
    })
    // Event: drag
    svg.on('mousedown', function() {
      isMouseDown = true
      dragStartX = d3Event.screenX
      dragStartY = d3Event.screenY})
        .on('mousemove', function() {
          if (isMouseDown) {
            var deltaTimeStamp = d3Event.timeStamp - dragTimeStamp
            if (dragTimeStamp && deltaTimeStamp > 10) {
              var deltaX = d3Event.screenX - dragStartX
              var deltaY = d3Event.screenY - dragStartY
              dragTimeStamp = d3Event.timeStamp
              dragged('#svgGroupRoot', deltaX, deltaY, zoomLevel)
            }
            else {
              dragTimeStamp = d3Event.timeStamp
            }
          }
        })
        .on('mouseup', function() {
          isMouseDown = false
        })
    //Litener: zoomed
    function zoomed(transformID, newLevel) {
        d3.select(transformID)
          .attr('transform', 'translate(' + translateX + ',' + translateY + ') scale(' + newLevel + ')')
      }
    //Listener: dragged
    function dragged(transformID, deltaX, deltaY, currentZoomLevel) {
      translateX += deltaX*0.1
      translateY += deltaY*0.1
      d3.select(transformID)
        .attr('transform', 'translate(' + translateX + ',' + translateY + ') scale(' + currentZoomLevel + ')')
      }

    animateFauxDOM(10)
  }
  updateD3(){
    const faux = this.props.connectFauxDOM('div', 'chart')
    d3.select(faux).select('svg').remove()
    this.renderD3()
    this.props.animateFauxDOM(500)
  }
  updateTransOnly(){
    const faux = this.props.connectFauxDOM('div', 'chart')
    d3.select(faux).select('svg').remove()
    this.renderTransOnly()
    this.props.animateFauxDOM(500)
  }
  updateNodes(filteredEntryID){
    const faux = this.props.connectFauxDOM('div', 'chart')
    d3.select(faux)
      .selectAll('circle.trans_node')
      .attr('r', function (d) {
        if (filteredEntryID.indexOf(d.entryID) !== -1) {return 10}
        else {return 5}
      })
      //call animate withFauxDOM
      this.props.animateFauxDOM(500)
  }
  updateLinks(threshold){
    //console.log('UPDATE trans link');
    const faux = this.props.connectFauxDOM('div', 'chart')
    d3.select(faux)
      .selectAll('path.trans_link')
      .attr('stroke-width', function(d) {
        //console.log(threshold);
        if (parseFloat(d.weight) < threshold) {
          return "0px"
        }
      })

      d3.select(faux)
      .selectAll('.trans_linkLabel')
      .attr('opacity', function(d) {
        if (parseFloat(d.weight) < threshold) {
          return "0"
        }
      })

      //call animate withFauxDOM
      this.props.animateFauxDOM(500)
  }
  updateClickedNodes(entryID){
    const faux = this.props.connectFauxDOM('div', 'chart')
    d3.select(faux)
      .selectAll('circle.trans_node')
      .attr('r', function (d) {
        if (d.entryID !== undefined && d.entryID === entryID) {return 10}
        else {return 5}
      })
    this.props.animateFauxDOM(500)
  }

  renderD3_ori(){
    const transData = this.props.transmission
    const {updateClickedElement, clickedElement, siteColor, metadata,
            width, height, connectFauxDOM, animateFauxDOM} = this.props

    const faux = connectFauxDOM('div', 'chart')
    const margin = {'top': 10, 'right': 15, 'bottom': 80, 'left': 60}
    var trans_width = width - margin.left - margin.right
    var trans_height = height- margin.top - margin.bottom - 40

    const data_dummy = {"nodes":[{'id':'P1'},{'id':'P2'},{'id':'P3'}],
                        "links":[{'source': 'P1', 'target': 'P2', 'weight': '1'},
                                 {'source': 'P1', 'target': 'P3', 'weight': '1'},
                                 {'source': 'P2', 'target': 'P1', 'weight': '2'},
                                 {'source': 'P2', 'target': 'P3', 'weight': '3'},
                                 {'source': 'P3', 'target': 'P2', 'weight': '3'}
                                ]
                        }

    var zoomLevel = 1
    var labelFontSize = 11
    var dragStartX, dragStartY, isMouseDown, dragTimeStamp
    var translateX = margin.left
    var translateY = margin.top

    var trans_tree = d3.tree().size([trans_height, trans_width]);
    var trans_treeData = d3.stratify()
                              .id(d => d.isolateID)
                              .parentId(d => d.parent)
                              (transData)
    //assign name to nodes
    //console.log(trans_treeData)

    trans_treeData.each(function(d) {
      d.name = d.id})
    trans_treeData.sort(function(a, b) {
      //console.log(a, b)
      return b.height - a.height })


    //var nodes = d3.hierarchy(trans_treeData, d => d.children)

    var nodes = trans_tree(trans_treeData)
    //console.log('TRANS', nodes);
    nodes.descendants().forEach(function(d) {
            //console.log(d);
            d.weight = d.data.weight
            d.entryID = util.getEntryIDfromSampleID(d.name, metadata)
            d.samplingDate = util.getSamplingDatefromSampleID(d.name, metadata)
          })
            //get the date here
    var dateRange = nodes.descendants().map(function(d) {if (d.samplingDate) {return d.samplingDate}})
    var dateScale= d3.scaleTime().domain(d3.extent(dateRange)).range([0, trans_width])
    var container = d3.select(faux)
    var tooltipID = 'transTooltip'
    var tooltip = container.append('div').attr('id', tooltipID).classed('tooltip', true)

    //reset zoom and loation
    d3.select('#svgGroupRoot').attr('transform', 'translate(' + margin.left + ',' + margin.top + ') scale(1)')

    //make svg root
    var svg = container.append('svg').attr('id', 'transmissionSVG')
                .attr('width', trans_width + margin.left + margin.right)
                .attr('height', trans_height + margin.top + margin.bottom)

    var svgGroupRoot = svg.append('g').attr('id', 'svgGroupRoot')
                          .attr('transform', 'translate(' + margin.left + ',' + margin.top + ')')

    //make arrow Group
    var arrowGroup = svgGroupRoot.append('g').attr('id', arrowGroup)
                        .append("defs").append("marker")
                        .attr("id", 'trans_arrow')
                        .attr("refX", 14)
                        .attr("refY", 3)
                        .attr("markerWidth", 16)
                        .attr("markerHeight", 16)
                        .attr("orient", "auto")
                        .append("path")
                        .attr("d", "M0,0 L0,6 L6,3 Z")
                        .style('fill', 'black')

    //make link group

    var linksGroup = svgGroupRoot.append('g').attr('id', 'linksGroup')
    var linkPath = linksGroup.selectAll('.trans_link')
                            .data(nodes.links())
                            .enter().append("path")
                            .attr("d", d3.linkHorizontal()
                                .x(d => dateScale(d.samplingDate))
                                .y(d => d.x))
                            .attr('stroke', 'black')
                            .attr("fill", "none")
                            .attr('stroke-dasharray', function(d) {
                              if (+d.target.data.weight === 0) {
                                return 4
                              }
                            })
                            .attr('marker-end', function(d) {
                              if (+d.target.data.weight !== 0) {
                                return 'url(#trans_arrow)'
                              }
                            })


    //make node group
    var nodesGroup = svgGroupRoot.append('g').attr('id', 'nodesGroup')
    var nodeCircle = nodesGroup.selectAll('.trans_node')
                            .data(nodes.descendants())
                            .enter()
                            .append('circle').attr('class', 'trans_node')
                            .attr('r', 10)
                            .attr('cx', d => dateScale(d.samplingDate))
                            .attr('cy', function(d) {
                              return d.x
                            })
                            .style('cursor', 'pointer')
                            .attr('fill', function(d) {
                              let siteID =  util.getSiteIDfromEntryID(d.entryID, metadata)
                              return siteColor(siteID)
                            })
                            .on('click', function(d) {
                              if (d.entryID) {updateClickedElement(d.entryID)}
                            })
                            .on('mouseover', function(d) {
                              if (d.entryID) {
                                var datum = util.getDetailsfromEntryID(d.entryID, metadata)
                                util.showTooltip('#'+tooltipID, datum,
                                d3Event.offsetX, d3Event.offsetY, 'trans')
                              }
                            })
                            .on('mouseout', function(d) {
                              if (d.entryID) {
                                util.hideTooltip('#'+tooltipID)
                              }
                            })
    //make link label
    var linksLabelGroup = svgGroupRoot.append('g').attr('id', 'linksLabelGroup')
    var linkLabel = linksLabelGroup.selectAll('.trans_linkLabel')
                                   .data(nodes.links()).enter()
                                   .append('text')
                                   .attr('class', 'trans_linkLabel')
                                   .attr('x', d => (dateScale(d.source.samplingDate) + dateScale(d.target.samplingDate))/2)
                                   .attr('y', d => (d.source.x + d.target.x)/2)
                                   .text(d => d.target.data.weight)
                                   .style("font-size", labelFontSize+"px")

    //make node label
    //var nodesLabelGroup = svgGroupRoot.append('g').attr('id', 'nodesLabelGroup')
    //var nodeLabel = nodesLabelGroup.selectAll('.trans_nodeLabel')
    //                  .data(nodes.descendants()).enter()
    //                  .append('text').attr('class', 'trans_nodeLabel')
    //                  .attr('x', d => d.y)
    //                  .attr('y', d => d.x)
    //                  .text(function(d) {
    //                    //console.log(d);
    //                    if(d.parent === null) return 'index:'+d.name
    //                    else return d.name})
    //                  .style("font-size", labelFontSize+"px")

    // Tick and Grid
    var xAxis = d3.axisBottom()
                  .scale(dateScale)
                  .ticks(d3.timeMonday.every(1))
                  .tickSizeInner([10])

    var xAxis2 = d3.axisTop()
                    .scale(dateScale)
                    .ticks(d3.timeDay.every(1))
                    .tickSizeInner([10])

    svgGroupRoot.append('g').attr('id', 'gAxisX')
              .attr("transform", "translate(0," + trans_height  + ")")
                .call(xAxis)
                .style('font-size', '10px')

    //svgGroupRoot.append('g').attr('id', 'gAxisGrid')
    //            .attr("transform", "translate(0," + trans_height  + ")")
    //            .call(xAxis2)
    //            .style('font-size', '0px')
    //            .style('opacity', '1')



    var butt = container.append('button')
                        .classed('w3-button w3-round w3-border w3-hover-gray transShorterButton', true)
                        .on('click', function() {
                          if (labelFontSize > 2) {
                            labelFontSize -= 4
                            d3.selectAll('.trans_linkLabel')
                              .style('font-size', labelFontSize+'px')
                            d3.selectAll('.trans_nodeLabel')
                              .style('font-size', labelFontSize+'px')
                          }})
                          .append('i').classed('fa fa-sort-down fa-lg', true)

    var butt2 = container.append('button')
                        .classed('transLongerButton', true)
                        .on('click', function() {
                          if (labelFontSize < 25) {
                            labelFontSize += 2
                            d3.selectAll('.trans_linkLabel')
                              .style('font-size', labelFontSize+'px')

                            d3.selectAll('.trans_nodeLabel')
                              .style('font-size', labelFontSize+'px')
                          }
                        })
                        .append('i').classed('fa fa-sort-up fa-lg', true)
    // Event: zoom
    svg.on('wheel.zoom', function() {
      if (d3Event.deltaY > 0 && zoomLevel < 4 ) {
        //var initial = floorplanZoomLevel + 0.2
        zoomLevel += 0.15
        //updateFloorplanZoomLevel(num)
        zoomed('#svgGroupRoot', zoomLevel)
      }
      else if (d3Event.deltaY < 0 && zoomLevel > 0.2 ) {
        //var reducedLevel = floorplanZoomLevel - 0.2
        zoomLevel -= 0.15
        //updateFloorplanZoomLevel(num)
        zoomed('#svgGroupRoot', zoomLevel)
      }
    })
    // Event: drag
    svg.on('mousedown', function() {
      isMouseDown = true
      dragStartX = d3Event.screenX
      dragStartY = d3Event.screenY})
        .on('mousemove', function() {
          if (isMouseDown) {
            var deltaTimeStamp = d3Event.timeStamp - dragTimeStamp
            if (dragTimeStamp && deltaTimeStamp > 10) {
              var deltaX = d3Event.screenX - dragStartX
              var deltaY = d3Event.screenY - dragStartY
              dragTimeStamp = d3Event.timeStamp
              dragged('#svgGroupRoot', deltaX, deltaY, zoomLevel)
            }
            else {
              dragTimeStamp = d3Event.timeStamp
            }
          }
        })
        .on('mouseup', function() {
          isMouseDown = false
        })
    //Litener: zoomed
    function zoomed(transformID, newLevel) {
        d3.select(transformID)
          .attr('transform', 'translate(' + translateX + ',' + translateY + ') scale(' + newLevel + ')')
      }
    //Listener: dragged
    function dragged(transformID, deltaX, deltaY, currentZoomLevel) {
      translateX += deltaX*0.1
      translateY += deltaY*0.1
      d3.select(transformID)
        .attr('transform', 'translate(' + translateX + ',' + translateY + ') scale(' + currentZoomLevel + ')')
      }

    //call animate withFauxDOM
    animateFauxDOM(500)
  }
  renderTransOnly_ori(){
    const transData = this.props.transmission
    const {width, height, connectFauxDOM, animateFauxDOM} = this.props

    const faux = connectFauxDOM('div', 'chart')
    const margin = {'top': 10, 'right': 15, 'bottom': 80, 'left': 60}
    var trans_width = width - margin.left - margin.right
    var trans_height = height- margin.top - margin.bottom

    var zoomLevel = 1
    var labelFontSize = 11
    var dragStartX, dragStartY, isMouseDown, dragTimeStamp
    var translateX = margin.left
    var translateY = margin.top

    var trans_tree = d3.tree().size([trans_height, trans_width]);
    var trans_simulation = d3.forceSimulation()
                              .force('charge', d3.forceCollide().radius(20))
                              .force('link', d3.forceLink().id(d => d.id))
                              .force('center', d3.forceCenter(trans_width / 2, trans_height / 2))
    var trans_treeData = d3.stratify()
                              .id(d => d.isolateID)
                              .parentId(d => d.parent)
                              (transData)
    //assign name to nodes
    trans_treeData.each(function(d) {d.name = d.id})

    var nodes = d3.hierarchy(trans_treeData, d => d.children)
    nodes = trans_tree(trans_treeData)

    var container = d3.select(faux)
    //reset zoom and loation
    d3.select('#svgGroupRoot').attr('transform', 'translate(' + margin.left + ',' + margin.top + ') scale(1)')

    //make svg root
    var svg = container.append('svg').attr('id', 'transmissionSVG')
                .attr('width', trans_width + margin.left + margin.right)
                .attr('height', trans_height + margin.top + margin.bottom)

    var svgGroupRoot = svg.append('g').attr('id', 'svgGroupRoot')
                          .attr('transform', 'translate(' + margin.left + ',' + margin.top + ')')

    //make arrow Group
    var arrowGroup = svgGroupRoot.append('g').attr('id', arrowGroup)
                        .append("defs").append("marker")
                        .attr("id", 'trans_arrow')
                        .attr("refX", 14)
                        .attr("refY", 3)
                        .attr("markerWidth", 16)
                        .attr("markerHeight", 16)
                        .attr("orient", "auto")
                        .append("path")
                        .attr("d", "M0,0 L0,6 L6,3 Z")
                        .style('fill', 'black')

    //make link group
    var linksGroup = svgGroupRoot.append('g').attr('id', 'linksGroup')
    var linkPath = linksGroup.selectAll('.trans_link')
                            .data(nodes.links())
                            .enter()
                            .append('line').attr('class', 'trans_link')
                            .attr('x1', d => d.source.y)
                            .attr('y1', d => d.source.x)
                            .attr('x2', d => d.target.y)
                            .attr('y2', d => d.target.x)
                            .attr('stroke', 'black')
                            .attr('stroke-dasharray', function(d) {
                              if (+d.target.data.snps === 0) {
                                return 4
                              }
                            })
                            .attr('marker-end', function(d) {
                              if (+d.target.data.snps !== 0) {
                                return 'url(#trans_arrow)'
                              }
                            })
    //make node group
    var nodesGroup = svgGroupRoot.append('g').attr('id', 'nodesGroup')
    var nodeCircle = nodesGroup.selectAll('.trans_node')
                            .data(nodes.descendants())
                            .enter()
                            .append('circle').attr('class', 'trans_node')
                            .attr('r', 5)
                            .attr('cx', d => d.y)
                            .attr('cy', d => d.x)
                            .style('cursor', 'pointer')
                            .attr('fill', 'black')

    //make link label
    var linksLabelGroup = svgGroupRoot.append('g').attr('id', 'linksLabelGroup')
    var linkLabel = linksLabelGroup.selectAll('.trans_linkLabel')
                                   .data(nodes.links()).enter()
                                   .append('text')
                                   .attr('class', 'trans_linkLabel')
                                   .attr('x', d => (d.source.x + d.target.x)/2)
                                   .attr('y', d => (d.source.y + d.target.y)/2)
                                   .text(d => d.target.data.snps)
                                   .style("font-size", labelFontSize+"px")

    //make node label
    var nodesLabelGroup = svgGroupRoot.append('g').attr('id', 'nodesLabelGroup')
    var nodeLabel = nodesLabelGroup.selectAll('.trans_nodeLabel')
                      .data(nodes.descendants()).enter()
                      .append('text').attr('class', 'trans_nodeLabel')
                      .attr('x', d => d.y)
                      .attr('y', d => d.x)
                      .text(function(d) {
                        //console.log(d);
                        if(d.parent === null) return 'index:'+d.name
                        else return d.name})
                      .style("font-size", labelFontSize+"px")

    //start simulation
    trans_simulation.nodes(nodes.descendants()).on('tick', ticked)

    trans_simulation.force('link')
                    .links(nodes.links())
                    //.distance(function(l) {return 5})

    function ticked() {
        nodeCircle.attr('cx', d => d.x).attr('cy', d => d.y)
        linkPath.attr('x1', d => d.source.x).attr('x2', d => d.target.x)
                .attr('y1', d => d.source.y).attr('y2', d => d.target.y)
        nodeLabel.attr('x', d => d.x+5).attr('y', d => d.y+5)
        linkLabel.attr('x', d => (d.source.x + d.target.x)/2)
                  .attr('y', d => (d.source.y + d.target.y)/2)
    }

    var butt = container.append('button')
                        .classed('w3-button w3-round w3-border w3-hover-gray transShorterButton', true)
                        .on('click', function() {
                          if (labelFontSize > 2) {
                            labelFontSize -= 4
                            d3.selectAll('.trans_linkLabel')
                              .style('font-size', labelFontSize+'px')
                            d3.selectAll('.trans_nodeLabel')
                              .style('font-size', labelFontSize+'px')
                          }})
                          .append('i').classed('fa fa-sort-down fa-lg', true)

    var butt2 = container.append('button')
                        .classed('transLongerButton', true)
                        .on('click', function() {
                          if (labelFontSize < 25) {
                            labelFontSize += 2
                            d3.selectAll('.trans_linkLabel')
                              .style('font-size', labelFontSize+'px')

                            d3.selectAll('.trans_nodeLabel')
                              .style('font-size', labelFontSize+'px')
                          }
                        })
                        .append('i').classed('fa fa-sort-up fa-lg', true)
    // Event: zoom
    svg.on('wheel.zoom', function() {
      if (d3Event.deltaY > 0 && zoomLevel < 4 ) {
        //var initial = floorplanZoomLevel + 0.2
        zoomLevel += 0.15
        //updateFloorplanZoomLevel(num)
        zoomed('#svgGroupRoot', zoomLevel)
      }
      else if (d3Event.deltaY < 0 && zoomLevel > 0.2 ) {
        //var reducedLevel = floorplanZoomLevel - 0.2
        zoomLevel -= 0.15
        //updateFloorplanZoomLevel(num)
        zoomed('#svgGroupRoot', zoomLevel)
      }
    })
    // Event: drag
    svg.on('mousedown', function() {
      isMouseDown = true
      dragStartX = d3Event.screenX
      dragStartY = d3Event.screenY})
        .on('mousemove', function() {
          if (isMouseDown) {
            var deltaTimeStamp = d3Event.timeStamp - dragTimeStamp
            if (dragTimeStamp && deltaTimeStamp > 10) {
              var deltaX = d3Event.screenX - dragStartX
              var deltaY = d3Event.screenY - dragStartY
              dragTimeStamp = d3Event.timeStamp
              dragged('#svgGroupRoot', deltaX, deltaY, zoomLevel)
            }
            else {
              dragTimeStamp = d3Event.timeStamp
            }
          }
        })
        .on('mouseup', function() {
          isMouseDown = false
        })
    //Litener: zoomed
    function zoomed(transformID, newLevel) {
        d3.select(transformID)
          .attr('transform', 'translate(' + translateX + ',' + translateY + ') scale(' + newLevel + ')')
      }
    //Listener: dragged
    function dragged(transformID, deltaX, deltaY, currentZoomLevel) {
      translateX += deltaX*0.1
      translateY += deltaY*0.1
      d3.select(transformID)
        .attr('transform', 'translate(' + translateX + ',' + translateY + ') scale(' + currentZoomLevel + ')')
      }

    //call animate withFauxDOM
    animateFauxDOM(500)
  }

}

/*
.enter().append('line').attr('class', 'trans_link')
.attr('x1', d => dateScale(d.source.samplingDate))
.attr('y1', function(d) {
  //console.log(d);
  return d.source.x

})
.attr('x2', d => dateScale(d.target.samplingDate))
.attr('y2', d => d.target.x)


*/


export default withFauxDOM(TransChart)

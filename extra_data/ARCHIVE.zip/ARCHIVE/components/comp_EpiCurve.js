import React, {Component} from 'react'
import {withFauxDOM} from 'react-faux-dom'
import * as util from '../utils/utils'
import {event as currentEvent} from 'd3';
const d3 = {
  ...require('d3-brush'),
  ...require('d3-array'),
  ...require('d3-scale'),
  ...require('d3-axis'),
  ...require('d3-selection')
}

// props from container: metadata
class EpiCurve extends Component {
  constructor(props){
    super(props)
  }
  
  render() {
    const {chart: chart} = this.props
    return (
      <div style={{width: '100%', height: '100%'}}>
        <svg id='brushChart' ref={node => this.node = node}></svg>
      </div>
    )
  }

  render_epiCurve_d3(){
    const self = this
    const {width, height, data} = this.props
    const margin = {'top': 10, 'right': 10, 'bottom': 70, 'left': 10}
    var chart_width = width - margin.left - margin.right
    var chart_height = height- margin.top - margin.bottom
    //Get data
    //if time is date object, create epiCurve_date
    //else, create epiCurve_number
    var dateRange = util.getAdmissionDates(metadata)
    var patientList = util.getPatients(metadata)

    patientList = patientList.filter(util.filterUnique);
    patientList.push("plusOne");

    var rectHeight = chart_height/patientList.length;

    var brush = d3.brushX() // brush rectangle area for mini chart
          .extent([[0, 0], [chart_width, chart_height]]) // brush region from top left corner 0, 0 to 900, 40
          .on("brush", brushed);

    //scaling
    var brush_x = d3.scaleTime().domain(d3.extent(dateRange)).range([0, chart_width]);
    var brush_y = d3.scalePoint().domain(patientList).range([0, chart_height]);

    //axis-scale
    var brush_xAxis = d3.axisBottom(brush_x)

    //make svg root
    const node = this.node
    d3.select(node).attr('width', chart_width + margin.left + margin.right)
                .attr('height', chart_height + margin.top + margin.bottom)
                .selectAll('g.svgGroupRoot')
                .data([0])
                .enter()
                .append('g')
                .attr('class', 'svgGroupRoot')
                .attr('transform', 'translate(' + margin.left + ',' + margin.top + ')')


    d3.select('g.svgGroupRoot')
      .selectAll('g.brush_rectGroup')
      .data([0]).enter().append('g')
      .attr('class', 'brush_rectGroup')
      //.attr('transform', 'translate(' + margin.left + ',' + margin.top + ')')

    //make lane bar
    d3.select('g.brush_rectGroup')
                .selectAll('.brush_rect')
                .data(metadata)
                .enter()
                .append('rect')
                .attr('class', 'brush_rect')
                .attr('x', d => brush_x(d.dateIn))
                .attr('y', d => brush_y(d.patID))
                .attr('width', d => { return brush_x(d.dateOut) - brush_x(d.dateIn)})
                .attr('height', rectHeight)
                .style('fill', d => siteColor(d.siteID) )

    //add axis
    d3.select('g.svgGroupRoot').selectAll('g.axisX')
            .data([0])
            .enter()
            .append('g')
            .attr('class', 'axisX')
    d3.select('g.axisX')
            .attr("transform", "translate(0," + chart_height + ")")
            .call(brush_xAxis)

    //brush area
    d3.select('g.svgGroupRoot').selectAll("g.brushArea")
            .data([0])
            .enter()
            .append('g')
            .attr('class', 'brushArea')

    d3.select('g.brushArea')
                .call(brush)
                .call(brush.move, brush_x.range())

    //event listener
    function brushed() {
      var selection = currentEvent.selection;
      var selectedExtent = selection.map(brush_x.invert, brush_x);
      var filteredEntryID = util.filterEntryID(metadata, selectedExtent)
      //console.log(filteredSampleID);
      self.props.updateEntryID(filteredEntryID)
      //console.log(selectedExtent)
      self.props.onSelect(selectedExtent)

    }
  }

}




export default EpiCurve;

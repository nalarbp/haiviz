import React, {Component} from 'react'
import {PanelHeader} from '../utils/styled'
import DownloadSVG from './component/btn_downloadSVG'
import CloseChart from '../containers/cont_CloseChart'
import TransViewer from './comp_TransViewer'
import TransViewerIntegrated from './comp_TransViewer_full'

// props from container: metadata
class TransComponent extends Component {
  constructor(props){
    super(props)
  }
/////
  render() {
    //console.log(this.props.transmission);
    if (this.props.height !== 0 && this.props.width !== 0 &&
        this.props.metadata !== null && this.props.transmission !== null) {
      //console.log('1: render: dimensions, metadata and trans are ready')
      if (this.props.selectedData !== null && this.props.selectedData !== {} &&
          this.props.selectedExtent !== null) {
        return (
          <div style={{width: '100%', height: '100%'}}>
            <TransViewerIntegrated height={this.props.height}
                        width={this.props.width}
                        selectActiveData={this.props.selectActiveData}
                        selectedData={this.props.selectedData}
                        selectedExtent={this.props.selectedExtent}
                        metadata={this.props.metadata}
                        colorIndex={this.props.colorIndex}
                        transmission={this.props.transmission}
                        updateTransmissionData={this.props.updateTransmissionData}
              ></TransViewerIntegrated>
          </div>
        )
      }
      else {
        return (
          <div style={{width: '100%', height: '100%'}}>
            <TransViewerIntegrated height={this.props.height}
                        width={this.props.width}
                        metadata={this.props.metadata}
                        colorIndex={this.props.colorIndex}
                        transmission={this.props.transmission}
                        selectActiveData={this.props.selectActiveData}
                        updateTransmissionData={this.props.updateTransmissionData}
              ></TransViewerIntegrated>
          </div>
        )
      }

    }
    else if (this.props.height !== 0 && this.props.width !== 0 && this.props.transmission !== null) {
      //console.log('1: render: dimensions and trans are ready')
      return (
        <div style={{width: '100%', height: '100%'}}>
          <PanelHeader className='panelHeader'>
            <div className='panelTitle'>Transmission Pathways</div>
            <CloseChart id='transmission'/>
            <DownloadSVG svgID="transmissionSVG"/>
          </PanelHeader>
          <TransViewer height={this.props.height}
                      width={this.props.width}
                      transmission={this.props.transmission}
                      updateTransmissionData={this.props.updateTransmissionData}
            ></TransViewer>
        </div>
      )
    }
    else {
      //console.log('1: render: dimensions not ready', this.props.height, this.props.width)
      return (
        <div style={{width: '100%', height: '100%'}}>
          <PanelHeader className='panelHeader'>
            <div className='panelTitle'>Transmission Pathways</div>
            <CloseChart id='transmission'/>
            <DownloadSVG svgID="transmissionSVG"/>
          </PanelHeader>
        </div>
      )
    }
  }
}
export default (TransComponent)

/*
import React, {Component} from 'react';
import * as fa from 'react-icons/lib/fa';
import {csv, json, text} from 'd3-fetch';
import * as util from '../../utils/utils'

async function getDataset(fileURL, fileType ) {
  switch (fileType) {
    case 'metadata':
      var metadata = await csv(fileURL);
      var patientList = []
      var siteList = []
      metadata.forEach((d) => {
        //console.log(d);
        //if sampleID is N/A
        if (d.samplingDate !== 'N/A') {
          d.samplingDate = new Date(d.samplingDate)
        }

        if (d.dateIn === "N/A" && d.samplingDate !== "N/A") {
          //console.log(d.dateIn)
          d.dateIn = new Date(d.samplingDate)
        }
        else if (d.dateOut === "N/A") {
          d.dateOut = new Date
        }
        else {
          d.dateIn = new Date(d.dateIn)
          d.dateOut = new Date(d.dateOut)
        }

        patientList.push(d.patID)
        siteList.push(d.siteID)

      })
      return {
        metadata : metadata,
        patientColor : util.colorOrdinalInterpolator(patientList.filter(util.filterUnique)),
        siteColor : util.colorOrdinalInterpolator(siteList.filter(util.filterUnique))
      }
    case 'floorplan':
      var floorplan = await json(fileURL);
      return floorplan
    case 'tree':
      var tree = await text(fileURL);
      return tree
    case 'transmission':
      var transmission = await csv(fileURL);
      transmission.forEach(function(d) {
        if (d.parent === 'null') d.parent = null;})
      return transmission
    default:
      return undefined

  }
}
//
class Btn_uploadFile extends Component{
  constructor(props){
    //props: chartID, upload method
    super(props)
    this.onChange = this.onChange.bind(this);
    this.getAcceptType = this.getAcceptType.bind(this)
  }

  getAcceptType(fileID){
    switch (fileID) {
      case 'metadata':
        return '.csv'
      case 'floorplan':
        return '.json'
      case 'tree':
        return '.txt'
      case 'transmission':
        return '.csv'
      default:

    }
  }

  onChange(e){
    var fileID = this.props.fileID;
    var self = this;
    var file = e.target.files[0];
    if (file) {
              var reader = new FileReader();
              reader.readAsDataURL(file);

              reader.onloadend = function(evt) {
              var dataUrl = evt.target.result;
              var data = getDataset(dataUrl, fileID)
              //call this.props.loadMetadata
              self.props.loadData(data, fileID)
              };
            }
  }
  render(){
    //console.log(this.props);
    return(

      <div style={{marginBottom: '5px'}} >
        <input type="file" accept={this.getAcceptType(this.props.fileID)}
               id={this.props.fileID}
               style={{display: 'none'}}
               onChange={this.onChange} />
        <label
          className='w3-button w3-round w3-black w3-hover-green'
          htmlFor={this.props.fileID} >
          <fa.FaFolderOpen  size={20} color='lightgreen'/>
          <span>        </span>  Upload from local storage
        </label>
      </div>
    )
  }
}
export default Btn_uploadFile;
*/

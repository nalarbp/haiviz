import React, {Component} from 'react';
import {searchMetadata, searchMetadataFromMultiQuery} from '../../utils/utils'

class Btn_SearchFormChart extends Component{
  constructor(props){
    //props: svgID
    super(props)
    this.onKeyUp = this.onKeyUp.bind(this)
    this.onKeyDown = this.onKeyDown.bind(this)
    this.onSelected = this.onSelected.bind(this)
    this.onClicked = this.onClicked.bind(this)
    this.state = {typingTimer: undefined,
                  searchField: undefined,
                  searchQuery: undefined}
  }
  shouldComponentUpdate(nextProps, nextStates) {
    //if the any of this state changed dont re-render
    return false
    }

  onKeyUp(f){
    //wait user finish typing
    var val = f.target.value
    clearTimeout(this.state.typingTimer)
    var typingTime = setTimeout(
      this.setState({searchQuery: val}), 1000)

    this.setState({typingTimer: typingTime})
  }
  onKeyDown(e){
    clearTimeout(this.state.typingTimer)
  }

  onSelected(e){
    if (e.target.value !== 'null') {
      var sel = e.target.value
      this.setState({searchField: sel})
    }
    else {
      this.setState({searchField: undefined})
    }
  }

  onClicked(e){
    if (this.state.searchField && this.state.searchQuery) {
      var multiQuery = this.state.searchQuery.split(",")
      if (multiQuery.length <= 1) {
        var activeData = searchMetadata(this.props.metadata, this.state.searchField, this.state.searchQuery)
        this.props.selectActiveData({selectedData: activeData, selectedExtent: undefined})
      }
      else {
        var activeData = searchMetadataFromMultiQuery(this.props.metadata, this.state.searchField, multiQuery)
        this.props.selectActiveData({selectedData: activeData, selectedExtent: undefined})
      }


    }
    else {
      alert('Please select search field and input the query')
    }
  }

  render(){
    //console.log('Render SearchForm');
    return(
      <div className="w3-margin-top w3-margin-bottom" >
        <div className="w3-row">
          <div className="w3-margin-right w3-col m4">
            <select value={this.state.searchField} onChange={this.onSelected} className="w3-select" name="option">
              <option value="null">Select Field</option>
              <option value="patient">Patient</option>
              <option value="isolate">Sample</option>
              <option value="location">Location</option>
            </select>
          </div>
          <div className="w3-col m5">
            <input onKeyUp={this.onKeyUp} onKeyDown={this.onKeyDown} type="text" placeholder="Search.." name="search" className='w3-input'></input>
          </div>
          <div className="w3-col m2">
            <button onClick={this.onClicked} className="w3-button"><i className="fa fa-search"></i></button>
          </div>
        </div>
      </div>
    )
  }
}
export default Btn_SearchFormChart;

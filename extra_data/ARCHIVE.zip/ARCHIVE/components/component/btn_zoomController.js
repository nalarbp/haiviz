import React, {Component} from 'react';
import * as md from 'react-icons/lib/md'

class Btn_zoomController extends Component{
  constructor(props){
    //props: svgID
    super(props)
    this.onZoomIn = this.onZoomIn.bind(this);
    this.onZoomOut = this.onZoomOut.bind(this);
    this.onZoomReset = this.onZoomReset.bind(this);
  }
  onZoomIn(e){
    this.props.updateZoomLevel(this.props.zoomLevel + 0.09)
  }
  onZoomOut(e){
    this.props.updateZoomLevel(this.props.zoomLevel - 0.09)
  }
  onZoomReset(e){
    this.props.updateZoomLevel(1)
  }
  render(){
    return(
      <div style={{float: 'left', backgroundColor:'gray'}} >
        <button style={{border: 'none'}} onClick={this.onZoomIn}>
          <md.MdAdd  size={18} color='black'/>
        </button>
        <button style={{border: 'none'}} onClick={this.onZoomReset}>
          <md.MdReplay  size={18} color='black'/>
        </button>
        <button style={{border: 'none'}} onClick={this.onZoomOut}>
          <md.MdRemove  size={18} color='black'/>
        </button>
      </div>
    )
  }
}
export default Btn_zoomController;

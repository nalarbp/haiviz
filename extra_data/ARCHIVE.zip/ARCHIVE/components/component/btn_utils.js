import React, {Component} from 'react';

class PanelTitle extends Component{
  render(){
    return(
        <div className= ' w3-container w3-col m6 w3-text-white w3-left'>
          <h6>{this.props.titleText}</h6>
        </div>
    )
  }
}

export {PanelTitle}

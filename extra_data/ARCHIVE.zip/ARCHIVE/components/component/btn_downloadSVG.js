import React, {Component} from 'react';
import SVGSaver from 'svgsaver';

class Btn_downloadSVG extends Component{
  constructor(props){
    //props: id
    super(props)
    this.onClicked = this.onClicked.bind(this);
  }
  onClicked(e){
    var svgsaver = new SVGSaver();
    var svg = document.querySelector('#' + this.props.id)
    //SavePDF.save(d3.select('#' + this.props.id).node(), {filename: this.props.id+'alala'});
    svgsaver.asSvg(svg, this.props.id+'.svg')
  }
  render(){
    return(
      <div style={{float: 'right'}} >
        <button onClick={this.onClicked}
                className="w3-button w3-text-white w3-medium w3-hover-none">
                <i className="fa fa-download fa-lg"></i>
        </button>
      </div>
    )
  }
}
export default Btn_downloadSVG;

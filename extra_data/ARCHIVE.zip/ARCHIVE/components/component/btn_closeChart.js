import React, {Component} from 'react';

class Btn_closeChart extends Component{
  constructor(props){
    //props: svgID
    super(props)
    this.onClicked = this.onClicked.bind(this);
  }
  onClicked(e){
    this.props.deactivateChart(this.props.id)
  }
  render(){
    return(
      <div style={{float: 'right'}} >
        <button onClick={this.onClicked}
                className="w3-button w3-text-white w3-medium w3-hover-none">
                <i className="fa fa-times fa-lg"></i></button>

      </div>
    )
  }
}
export default Btn_closeChart;

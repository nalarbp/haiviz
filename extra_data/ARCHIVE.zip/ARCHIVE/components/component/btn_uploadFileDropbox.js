import React, {Component} from 'react';
import * as fa from 'react-icons/lib/fa';
import {csv, json, text} from 'd3-fetch';
import * as util from '../../utils/utils'
import DropboxChooser from 'react-dropbox-chooser';

async function getDataset(fileURL, fileType ) {
  switch (fileType) {
    case 'metadata':
      var metadata = await csv(fileURL);
      var patientList = []
      var siteList = []
      metadata.forEach((d) => {
        d.dateIn = new Date(d.dateIn)
        d.dateOut = new Date(d.dateOut)
        patientList.push(d.patID)
        siteList.push(d.siteID)
        if (d.samplingDate !== 'N/A') {d.samplingDate = new Date(d.samplingDate)}
      })
      return {
        metadata : metadata,
        patientColor : util.colorOrdinalInterpolator(patientList.filter(util.filterUnique)),
        siteColor : util.colorOrdinalInterpolator(siteList.filter(util.filterUnique))
      }
    case 'floorplan':
      var floorplan = await json(fileURL);
      return floorplan
    case 'tree':
      var tree = await text(fileURL);
      return tree
    case 'transmission':
      var transmission = await csv(fileURL);
      transmission.forEach(function(d) {
        if (d.parent === 'null') d.parent = null;})
      return transmission
    default:
      return undefined

  }
}

class Btn_uploadFileDropbox extends Component{
  constructor(props){
    //props: chartID, upload method
    super(props)
    this.onChange = this.onChange.bind(this);
    this.getAcceptType = this.getAcceptType.bind(this)
    this.onCancel = this.onCancel.bind(this)
    this.onSuccess = this.onSuccess.bind(this)
  }

  getAcceptType(fileID){
    switch (fileID) {
      case 'metadata':
        return ['.csv']
      case 'floorplan':
        return ['.geojson']
      case 'tree':
        return ['.txt']
      case 'transmission':
        return ['.csv']
      default:

    }
  }

  onChange(e){
    var fileID = this.props.fileID;
    var self = this;
    var file = e.target.files[0];
    if (file) {
              var reader = new FileReader();
              reader.readAsDataURL(file);

              reader.onloadend = function(evt) {
              var dataUrl = evt.target.result;
              var data = getDataset(dataUrl, fileID)
              //call this.props.loadMetadata
              self.props.loadData(data, fileID)
              };
            }
  }
  onCancel(){
    //console.log("Dropbox files cancelled!");
  }

  onSuccess(file){
    const fileURL = file[0].link
    //console.log(file[0], fileURL);
    var fileID = this.props.fileID;
    //var self = this;
    var data = getDataset(fileURL, fileID );
    //console.log(fileURL, data);
    //self.props.loadData(data, fileID)
  }

  render(){
    //console.log(this.props);
    return(
      <div style={{marginBottom: '5px'}}>
        <DropboxChooser
          appKey={'gg2v9l43d94ss2r'}
          success={file => this.onSuccess(file)}
          cancel={() => this.onCancel()}
          multiselect={false}
          extensions={this.getAcceptType(this.props.fileID)} >
          <button className='w3-button w3-round w3-black w3-hover-green'>
            <fa.FaDropbox  size={20} color='lightgreen'/>
            <span>        </span>  Upload from Dropbox
          </button>
        </DropboxChooser>
      </div>
    )
  }
}
export default Btn_uploadFileDropbox;

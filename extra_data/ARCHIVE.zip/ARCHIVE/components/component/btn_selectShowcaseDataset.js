import React, {Component} from 'react';
import {SHOWCASE_DATASET_1,
        SHOWCASE_DATASET_2} from '../../utils/constants'

//dataset 1 : metadata only
//dataset 2 : metadata + tree + graph
//SHOWCASE_DATASET_3, SHOWCASE_DATASET_4
class btn_selectShowcaseDataset extends Component{
  constructor(props){
    //props: svgID
    super(props)
    this.onChanged = this.onChanged.bind(this);
  }

  //for each key in dataset

  onChanged(e){
    var val = e.target.value
    switch (val) {
      case 'sampleDataset1':
      //SHOWCASE_DATASET_1.metadataURL etc, should stay same, but we remove link on the constant
        this.props.newDataset(SHOWCASE_DATASET_1.metadataURL,
                              SHOWCASE_DATASET_1.floorplanURL,
                              SHOWCASE_DATASET_1.treeURL,
                              SHOWCASE_DATASET_1.transmissionURL)
        break;
      case 'sampleDataset2':
      this.props.newDataset(SHOWCASE_DATASET_2.metadataURL,
                            SHOWCASE_DATASET_2.floorplanURL,
                            SHOWCASE_DATASET_2.treeURL,
                            SHOWCASE_DATASET_2.transmissionURL)
        break;
      default:
    }
  }
  render(){
    return(
      <div>
        <select value='null' onChange={this.onChanged}>
          <option value='null'>Choose here</option>
          <option value='sampleDataset2'>Demonstration dataset</option>


        </select>
      </div>
    )
  }
}
export default btn_selectShowcaseDataset;
//<option value='sampleDataset3'>Sample dataset (metadata+floorplan)</option>
//<option value='sampleDataset4'>Sample dataset (complete)</option>

import React, {Component} from 'react';
import * as md from 'react-icons/lib/md'

class btn_loadShowcaseDataset extends Component{
  constructor(props){
    //props: svgID
    super(props)
    this.onClicked = this.onClicked.bind(this);
  }
  onClicked(e){
    this.props.newDataset(this.props.metadataURL,
                          this.props.floorplanURL,
                          this.props.treeURL,
                          this.props.transmissionURL)
    //console.log(this.props);
  }
  render(){
    return(
      <div>
        <button className='w3-button w3-block w3-lime'
                onClick={this.onClicked}>Show
        </button>
      </div>
    )
  }
}
export default btn_loadShowcaseDataset;

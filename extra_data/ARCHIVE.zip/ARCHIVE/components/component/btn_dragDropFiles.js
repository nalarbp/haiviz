import React, {Component} from 'react';
import * as fa from 'react-icons/lib/fa'

class Btn_dragDropFiles extends Component{
  constructor(props){
    //props: svgID
    super(props)
  }

  render(){
    return(
      <div style={{backgroundColor:'pink', width:'100%', height:'auto'}} >
        <input type="file"/>
      </div>
    )
  }
}
export default Btn_dragDropFiles;

import React, {Component} from 'react';
import * as md from 'react-icons/lib/md'

class Btn_transThresholdInput extends Component{
  constructor(props){
    //props: svgID
    super(props)
    this.onClicked = this.onClicked.bind(this);
  }
  onClicked(e){
    //console.log('clicked>>newThreshold 0.7', this.props);
    var newThreshold = document.getElementById("transThresholdInput").value
    this.props.setTransLinkThreshold(newThreshold)
  }
  render(){
    return(
      <div style={{float: 'left'}} >
        <div className="w3-container"></div>
        <div className="w3-row-padding">
          <div className="w3-third">
            <input id='transThresholdInput' className="w3-input w3-border" type="number" placeholder="Threshold"></input>
          </div>
          <div className="w3-third">
            <button onClick={this.onClicked} className="w3-button w3-round w3-green" >Set threshold</button>
          </div>
        </div>
      </div>
    )
  }
}
export default Btn_transThresholdInput;

import React, {Component} from 'react';
import Toggle from 'react-toggle';

class Btn_colorToggle extends Component{
  constructor(props){
    super(props)
    this.handleChange = this.handleChange.bind(this)
  }
  render(){
    return(
      <div style={{float: 'right'}} >
        <Toggle defaultChecked={this.props.defaultChecked}
                onChange={this.handleChange} />
      </div>
    )
  }

  handleChange(event) {
  // do something with event.target.checked
}
}
export default Btn_colorToggle;

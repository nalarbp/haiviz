import React, {Component} from 'react'
//import FloorplanMap from './comp_'
import {SHOWCASE_DATASET_2} from '../utils/constants'

// input data

class IndividualTest extends Component {
  constructor(props){
    super(props)

  }

  render() {
    //console.log(this.props;
    return (
      <div className="w3-content w3-center">

      </div>

    )
  }

}

export default IndividualTest


/*
<div className="w3-col s12">
  <p>Or select one of our sample dataset</p>
  <SelectShowcaseDataset />
</div>
*/

import React, {Component} from 'react';
import {blob, csv, json, text} from 'd3-fetch';
import * as util from '../utils/utils'
import MetadataIcon from '../img/metadata.png';
import FloorplanIcon from '../img/floorplan.png';
import TreeIcon from '../img/tree.png';
import TransmissionIcon from '../img/transmission.png';

import MetadataIcon_loaded from '../img/loaded_metadata.png';
import FloorplanIcon_loaded from '../img/loaded_floorplan.png';
import TreeIcon_loaded from '../img/loaded_tree.png';
import TransmissionIcon_loaded from '../img/loaded_transmission.png';

//
async function getDataset(fileURL, fileType ) {
  switch (fileType) {
    case 'metadata':
      var metadata = await csv(fileURL);
      //console.log('GETDATASET', metadata);
      //if file metadata not valid, return metadata: null
      if (!util.validateHeader(metadata)) {
        return {
          metadata : null,
          patientColor : null,
          siteColor : null
        }
      } else {
        //util.transformMetadata(metadata)
        var patientColour = {}
        var siteColour = {}
        metadata.forEach((d) => {
          d.entryID = +d.entryID
          d.dateIn = new Date(d.dateIn)
          d.dateOut = new Date(d.dateOut)
          util.transformDateOut(d.dateOut)

          d.siteLevel = +d.siteLevel
          patientColour[d.patID]=util.getMetadataColour(d.colour)
          siteColour[d.siteID]=util.getMetadataColour(d.colour)
          if (d.samplingDate !== 'N/A') {d.samplingDate = new Date(d.samplingDate)}
        })
        return {
          metadata : metadata,
          patientColor : patientColour,
          siteColor : siteColour
        }
      }
    case 'floorplan':
      var floorplan = await json(fileURL);
      //JSON.parse(JSON.stringify(floorplan)

      floorplan.features.forEach(function(d) {
        var level = d.properties.level.split(',')
        //console.log(level);
        for (var i = 0; i < level.length; i++) {level[i] = parseInt(level[i])}
        d.properties.level = level
      })
      //console.log(floorplan)

      return floorplan
    case 'tree':
      var tree = await text(fileURL);
      return tree
    case 'transmission':
      var transmissionGraphml = await text(fileURL);
      var transmissionData = util.parseGraphMLtoJSON(transmissionGraphml)
      return transmissionData;
      //var transmissionCSV = await csv(fileURL);
      //transmission input validation
      //if (!util.transmissionInputValidation(transmissionCSV)) {
      //  return null
      //} else {
      //  var transmission = util.createTransmissionData(transmissionCSV)
      //  return transmission
      //}

    default:
      //return undefined

  }
}

class PopupInput extends Component{
  constructor(props){
    //props: metadata, floorplan, trans, tree, upload method
    super(props)
    this.onChange = this.onChange.bind(this);
    this.popup = this.popup.bind(this);
    this.onClicked = this.onClicked.bind(this);
    this.getAcceptType = this.getAcceptType.bind(this)
    this.getIcon = this.getIcon.bind(this)
    this.getAltImage = this.getAltImage.bind(this)
    this.isDisabled = this.isDisabled.bind(this)
    this.getStyles = this.getStyles.bind(this)
  }

  getStyles(styleID){
    switch (styleID) {
      case 'popup':
        return {'display': 'none'}
      default:

    }
  }


  isDisabled(fileID){
    switch (fileID) {
      case 'metadata':
        if (this.props.metadata) {
          return true
        }
        return false
      case 'floorplan':
        if (this.props.floorplan) {
          return true
        }
        return false
      case 'tree':
        if (this.props.tree) {
          return true
        }
        return false
      case 'transmission':
        if (this.props.transmission) {
          return true
        }
        return false
      default:
    }
  }

  getAcceptType(fileID){
    switch (fileID) {
      case 'metadata':
        return '.csv'
      case 'floorplan':
        return '.geojson'
      case 'tree':
        return '.nwk'
      case 'transmission':
        return '.txt'
        //return '.csv'
      default:
    }
  }

  getAltImage(fileID){
    switch (fileID) {
      case 'metadata':
        return 'Metadata'
      case 'floorplan':
        return 'Floorplan'
      case 'tree':
        return 'Tree'
      case 'transmission':
        return 'Transmission'
      default:
    }
  }

  getIcon(fileID){
    switch (fileID) {
      case 'metadata':
        if (!this.props.metadata) {
          return MetadataIcon
        }
        return MetadataIcon_loaded
      case 'floorplan':
        if (!this.props.floorplan) {
          return FloorplanIcon
        }
        return FloorplanIcon_loaded
      case 'tree':
        if (!this.props.tree) {
          return TreeIcon
        }
        return TreeIcon_loaded
      case 'transmission':
        if (!this.props.transmission) {
          return TransmissionIcon
        }
        return TransmissionIcon_loaded
      default:
    }
  }

  onChange(e){
    var fileID = this.props.fileID;
    var self = this;
    var file = e.target.files[0];
    if (file) {
              var reader = new FileReader();
              reader.readAsDataURL(file);

              reader.onloadend = function(evt) {
              var dataUrl = evt.target.result;
              var data = getDataset(dataUrl, fileID) //-Start loading data!
              self.props.loadData(data, fileID) //loading to state via action


              };
            }
  }

  popup(e){
    //console.log('popip');
    document.getElementById("id01").style.display = "block";
  }

  onClicked(e){
    document.getElementById('id01').style.display='none';
  }


  render(){
    //console.log(this.props);
    return(
      <div style={{marginBottom: '5px'}} >


        <label
          onClick={this.popup}
          className='w3-button w3-round w3-hover-lightgray'>
          <p>LALALA</p>
        </label>

        <button className="w3-button w3-black"
                style={this.getStyles('popup')}
                //onClick={this.popup}
              />

        <div id="id01" className="w3-modal">
          <div className="w3-modal-content">
            <div className="w3-container">
              <span onClick={this.onClicked}
                className="w3-button w3-display-topright">&times;</span>
                <form class="w3-container">
                  <p>
                    <label>First Name</label>
                    <input className="w3-input" type="text"/>
                  </p>
                  <select className="w3-select" name="option">
                    <option value="" disabled selected>Choose your option</option>
                    <option value="1">Option 1</option>
                    <option value="2">Option 2</option>
                    <option value="3">Option 3</option>
                  </select>
                  <p></p>

                    <input type="file" />

                </form>
            </div>
          </div>
        </div>
      </div>
    )
  }
}
export default PopupInput;

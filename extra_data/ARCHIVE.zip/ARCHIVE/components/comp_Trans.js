import React, {Component} from 'react'
import TransChart from './comp_TransChart'
import withMeasure from '../hocs/withMeasure';

const dimensions = ['width', 'height']
const MeasuredTrans = withMeasure(dimensions)(TransChart)


//props from container: dataset: Map(metadata,etc)
class ComponentTrans extends Component {
  render(){
    //console.log(this.props.transmission);
    return (
      <div style={{width: '100%', height: '100%'}} >
        <MeasuredTrans transmission={this.props.transmission}
                        metadata={this.props.metadata}
                        transLinkThreshold={this.props.transLinkThreshold}
                        setTransLinkThreshold= {this.props.setTransLinkThreshold}
                        filteredEntryID={this.props.filteredEntryID}
                        siteColor={this.props.siteColor}
                        updateClickedElement={this.props.updateClickedElement}
                        clickedElement={this.props.clickedElement}
                        loadData={this.props.loadData}/>
      </div>
    )
  }
}

export default ComponentTrans
//

import React, {Component} from 'react'
import * as util from '../utils/utils'
import * as fa from 'react-icons/lib/fa';
import styled from 'styled-components';
import {event as currentEvent} from 'd3';
import AnimationController from '../containers/cont_AnimationController'
const d3 = {
  ...require('d3-brush'),
  ...require('d3-array'),
  ...require('d3-scale'),
  ...require('d3-axis'),
  ...require('d3-selection')
}

// props from container: metadata
class BrushChart extends Component {
  constructor(props){
    super(props)

  this.renderD3= this.renderD3.bind(this)
  this.updateD3= this.updateD3.bind(this)
  }

  componentDidUpdate(prevProps, prevState){
    if (this.props.metadata) {
      this.updateD3()
    }
  }
  render() {
    return (
      <div style={{width: '100%', height: '100%'}}>
        <div id='brusher' ref={node => this.node = node}>
        </div>
      </div>
    )
  }

  renderD3(){
    //console.log('renderD3');

    const {siteColor, width, height, metadata} = this.props,
          self = this,
          margin = {'top': 5, 'right': 5, 'bottom': 25, 'left': 3},
          chart_width = width - margin.left - margin.right,
          chart_height = height- margin.top - margin.bottom - 60,
          player_width = chart_width,
          player_height = margin.top + margin.bottom + 20

    var dateRange = util.getAdmissionDates(metadata),
        patientList = util.getPatients(metadata)

    patientList = patientList.filter(util.filterUnique);
    patientList.push("plusOne");

    var rectHeight = chart_height/patientList.length; //below 0.1 is barely visible
    var animIsPlaying = false;
    var animDateIntervalMilliseconds = metadata.map(function(d) {return d.dateOut.getTime()})
                                    .filter(util.filterUnique)

    var animDateInterval = animDateIntervalMilliseconds.map(function(d) {return new Date(d)})
                                                        .sort(function(a,b) {return a - b})
    //console.log(animDateInterval);
    var pointInInterval = 0
    var animPlayer;

    var brush = d3.brushX() // brush rectangle area for mini chart
          .extent([[0, 0], [chart_width, chart_height]]) // brush region from top left corner 0, 0 to 900, 40
          .on("end", brushed)


    //scaling
    var brush_x = d3.scaleTime().domain(d3.extent(dateRange)).range([0, chart_width]);
    var brush_y = d3.scalePoint().domain(patientList).range([0, chart_height]);

    //axis-scale
    var brush_xAxis = d3.axisBottom(brush_x)


    const node = this.node
    //make animation controller
    var animationController = d3.select(node).append('div')
                              .attr('id', 'brushController')
                              .classed('w3-row w3-leftbar w3-border-green', true)
                              .style('float','left')
                              .style('width',chart_width+'px')
                              .style('height',player_height+'px')
                              .style('margin','5px 0 0 5px')
                              .style('background-color', '#474747')


    animationController.append('button')
                        .classed('w3-button w3-hover-gray', true)
                        .attr('name', 'play')
                        .on('click', function() {if (!animIsPlaying) {playAnimation()}
                          else {pauseAnimation()}})
                        .append('i').attr('id', 'playPauseIcon')
                        .classed('fa fa-inverse fa-play-circle fa-2x', true)

    animationController.append('button')
                        .attr('id', 'animStopButton')
                        .classed('w3-button w3-margin-right w3-border-left w3-border-green w3-hover-gray', true)
                        .attr('name', 'stop')
                        .on('click', function() {if (animIsPlaying) {stopAnimation()}})
                        .append('i').classed('fa fa-inverse fa-stop-circle fa-lg', true)

    animationController.append('text').classed('h3 w3-text-white', true)
                        .text('lalla')


    //make svg root
    d3.select(node).append('svg').attr('id', 'brushChart')
                .attr('width', chart_width + margin.left + margin.right)
                .attr('height', chart_height + margin.top + margin.bottom)
                .selectAll('g.svgGroupRoot')
                .data([0])
                .enter()
                .append('g')
                .attr('class', 'svgGroupRoot')
                .attr('transform', 'translate(' + margin.left + ',' + margin.top + ')')


    d3.select('g.svgGroupRoot')
      .selectAll('g.brush_rectGroup')
      .data([0]).enter().append('g')
      .attr('class', 'brush_rectGroup')
      //.attr('transform', 'translate(' + margin.left + ',' + margin.top + ')')

    //make lane bar
    d3.select('g.brush_rectGroup')
                .selectAll('.brush_rect')
                .data(metadata)
                .enter()
                .append('rect')
                .attr('class', 'brush_rect')
                .attr('x', d => brush_x(d.dateIn))
                .attr('y', d => brush_y(d.patID))
                .attr('width', d => { return brush_x(d.dateOut) - brush_x(d.dateIn)})
                .attr('height', rectHeight)
                .style("fill", function(d) {
                  var colour = util.getMetadataColour(d.colour)
                  return colour})

                //.style('fill', d => siteColor(d.siteID) )

    //add axis
    d3.select('g.svgGroupRoot').selectAll('g.axisX')
            .data([0])
            .enter()
            .append('g')
            .attr('class', 'axisX')
    d3.select('g.axisX')
            .attr("transform", "translate(0," + chart_height + ")")
            .call(brush_xAxis)

    //brush area
    d3.select('g.svgGroupRoot').selectAll("g.brushArea")
            .data([0])
            .enter()
            .append('g')
            .attr('class', 'brushArea')
    //buat interval yang terus jalan di store, ubah parameter date by date
    d3.select('g.brushArea')
                .call(brush)
                .call(brush.move, brush_x.range()) //gerakan brush area sepanjang range


    //event listener
    function playAnimation() {
      if (!animIsPlaying) {
        animPlayer = setInterval(function() {movingBrush()}, 1000)
      }
      d3.select('#playPauseIcon')
      .classed('fa-play-circle', false)
      .classed('fa-pause-circle', true)
      animIsPlaying = true;
    }

    function pauseAnimation() {
      clearInterval(animPlayer)
      d3.select('#playPauseIcon')
        .classed('fa-pause-circle', false)
        .classed('fa-play-circle', true)
      animIsPlaying = false;
    }

    function movingBrush() {
      //var dateInterval = brush_x([firstDate, currentDate]) //in: [date, date] out: [0, endPixel]
      if (pointInInterval < animDateInterval.length) {
        var currentDate = animDateInterval[pointInInterval]
        d3.select('g.brushArea')
                    .call(brush)
                    .call(brush.move, [0, brush_x(currentDate)])
        pointInInterval += 1
      }
      else {
        stopAnimation()
      }
    }

    function stopAnimation() {
        d3.select('#playPauseIcon')
          .classed('fa-pause-circle', false)
          .classed('fa-play-circle', true)
        clearInterval(animPlayer)
        pointInInterval = 0
        animIsPlaying = false;
    }

    function brushed() {
      var selection = currentEvent.selection;
      var selectedExtent = selection.map(brush_x.invert, brush_x);
      //console.log(selectedExtent);
      //var filteredEntryID = util.filterEntryID(metadata, selectedExtent)
      var newSelectedData = util.filterMetadataByDateRange(metadata, selectedExtent)
      //console.log(filteredEntryID);
      self.props.selectActiveData({selectedData: newSelectedData, selectedExtent: selectedExtent})

      //self.props.onSelect(selectedExtent)
    }

    function recenterBrush() {
    }
  }
  updateD3(){
    //d3.select('svg#brushChart').select('.svgGroupRoot').remove()
    d3.select('#brusher').select('svg#brushChart').remove()
    d3.select('#brusher').select('#brushController').remove()
    this.renderD3()
  }
}

export default BrushChart;

/*
<div id='brushController' style={{height:'50px'}}>
  <AnimationController />
</div>

*/

import React, {Component} from 'react'
import InfoBoxHTML from './comp_InfoBoxHTML'
import withMeasure from '../hocs/withMeasure';

const dimensions = ['width', 'height']
const MeasuredInfoBox = withMeasure(dimensions)(InfoBoxHTML)


//props from container: dataset: Map(metadata,etc)
class ComponentInfoBox extends Component {
  render(){
    return (
      <div style={{width: '100%', height: '100%'}} >
        <MeasuredInfoBox metadata={this.props.metadata}
                        clickedElement={this.props.clickedElement}/>
      </div>
    )
  }
}

export default ComponentInfoBox

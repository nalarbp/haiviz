//Module brush viewer
import React, {Component} from 'react'
import * as util from '../utils/utils'
import styled from 'styled-components';
import {event as d3Event} from 'd3';
const d3 = {
  ...require('d3-brush'),
  ...require('d3-array'),
  ...require('d3-scale'),
  ...require('d3-axis'),
  ...require('d3-selection')
}

// props from container: metadata
class BrushViewer extends Component {
  constructor(props){
    super(props)
    this.state = {initialExtent:{isInitial: true,
                                  extent: []}}

  this.renderD3= this.renderD3.bind(this)
  this.updateD3= this.updateD3.bind(this)
  }

  componentDidUpdate(prevProps, prevState){
    if (this.props.metadata) {
      this.updateD3()
    }
  }

  render() {
    return (
      <div style={{width: '100%', height: '100%'}}>

        <div className= 'panelHeader w3-row w3-dark-grey'>

          <div className= 'w3-col s12 w3-left'>
            <div className='w3-left'>
              <button id="brush_play_button"
                      ref={playBtn => this.playBtn = playBtn}
                      className="w3-button w3-hover-gray">
                      <i id='playPauseIcon' className="fa fa-inverse fa-play-circle fa-3x"></i>
              </button>
            </div>

            <div className='w3-left'>
              <button id="brush_stop_button"
                      ref={stopBtn => this.stopBtn = stopBtn}
                      className="w3-button w3-hover-gray w3-leftbar w3-border-green">
                      <i id='playPauseIcon' className="fa fa-inverse fa-stop-circle fa-3x"></i>
              </button>
            </div>

            <div className='w3-container w3-margin-right w3-right'>
              <h5 id='extentDescriptor' >24 Jul 2019 to 23 Aug 2019</h5>
            </div>

          </div>
        </div>


        <div id='brusher' className='w3-white' ref={node => this.node = node}></div>
      </div>
    )
  }

  renderD3(){
    const {siteColor, width, height, metadata, dateRange, patients} = this.props,
          self = this,
          margin = {'top': 5, 'right': 5, 'bottom': 25, 'left': 3},
          chart_width = width - margin.left - margin.right,
          chart_height = height- margin.top - margin.bottom - 60,
          player_width = chart_width,
          player_height = margin.top + margin.bottom + 20

    var patientList = patients

    patientList = patientList.filter(util.filterUnique);
    patientList.push("plusOne");

    var rectHeight = chart_height/patientList.length; //below 0.1 is barely visible
    var animIsPlaying = false;
    var animDateIntervalMilliseconds = metadata.map(function(d) {return d.dateOut.getTime()})
                                    .filter(util.filterUnique)

    var animDateInterval = animDateIntervalMilliseconds.map(function(d) {return new Date(d)})
                                                        .sort(function(a,b) {return a - b})
    //console.log(animDateInterval);
    var pointInInterval = 0
    var animPlayer;

    var brush = d3.brushX() // brush rectangle area for mini chart
          .extent([[0, 0], [chart_width, chart_height]]) // brush region from top left corner 0, 0 to 900, 40
          .on("end", brushed)


    //scaling
    var brush_x = d3.scaleTime().domain(dateRange).range([0, chart_width]);
    var brush_y = d3.scalePoint().domain(patientList).range([0, chart_height]);

    //axis-scale
    var brush_xAxis = d3.axisBottom(brush_x)


    const node = this.node,
          stopBtn = this.stopBtn,
          playBtn = this.playBtn

    //make animation controller


    d3.select(playBtn).on('click', function() {if (!animIsPlaying) {playAnimation()}
                          else {pauseAnimation()}})
    d3.select(stopBtn).on('click', function() {if (animIsPlaying) {stopAnimation()}})

    //make svg root
    d3.select(node).append('svg').attr('id', 'brushChart')
                .attr('width', chart_width + margin.left + margin.right)
                .attr('height', chart_height + margin.top + margin.bottom)
                .attr('fill', 'white')
                .selectAll('g.svgGroupRoot')
                .data([0])
                .enter()
                .append('g')
                .attr('class', 'svgGroupRoot')
                .attr('transform', 'translate(' + margin.left + ',' + margin.top + ')')


    //d3.select('g.svgGroupRoot')
    //  .selectAll('g.brush_rectGroup')
    //  .data([0]).enter().append('g')
    //  .attr('class', 'brush_rectGroup')
      //.attr('transform', 'translate(' + margin.left + ',' + margin.top + ')')

    //make lane bar
    //d3.select('g.brush_rectGroup')
    //            .selectAll('.brush_rect')
    //            .data(metadata)
    //            .enter()
    //            .append('rect')
    //            .attr('class', 'brush_rect')
    //            .attr('x', d => brush_x(d.dateIn))
    //            .attr('y', d => brush_y(d.patID))
    //            .attr('width', d => { return brush_x(d.dateOut) - brush_x(d.dateIn)})
    //            .attr('height', rectHeight)
    //            .style("fill", function(d) {
    //              var colour = util.getMetadataColour(d.colour)
    //              return colour})

                //.style('fill', d => siteColor(d.siteID) )

    //add axis
    d3.select('g.svgGroupRoot').selectAll('g.axisX')
            .data([0])
            .enter()
            .append('g')
            .attr('class', 'axisX')
    d3.select('g.axisX')
            .attr("transform", "translate(0," + chart_height + ")")
            .call(brush_xAxis)

    //brush area
    d3.select('g.svgGroupRoot').selectAll("g.brushArea")
            .data([0])
            .enter()
            .append('g')
            .attr('class', 'brushArea')
    //buat interval yang terus jalan di store, ubah parameter date by date
    d3.select('g.brushArea')
                .call(brush)
                .call(brush.move, brush_x.range()) //gerakan brush area sepanjang range


    //event listener
    function playAnimation() {
      if (!animIsPlaying) {
        animPlayer = setInterval(function() {movingBrush()}, 1000)
      }
      d3.select('#playPauseIcon')
      .classed('fa-play-circle', false)
      .classed('fa-pause-circle', true)
      animIsPlaying = true;
    }

    function pauseAnimation() {
      clearInterval(animPlayer)
      d3.select('#playPauseIcon')
        .classed('fa-pause-circle', false)
        .classed('fa-play-circle', true)
      animIsPlaying = false;
    }

    function movingBrush() {
      //var dateInterval = brush_x([firstDate, currentDate]) //in: [date, date] out: [0, endPixel]
      if (pointInInterval < animDateInterval.length) {
        var currentDate = animDateInterval[pointInInterval]
        d3.select('g.brushArea')
                    .call(brush)
                    .call(brush.move, [0, brush_x(currentDate)])
        pointInInterval += 1
      }
      else {
        stopAnimation()
      }
    }

    function stopAnimation() {
        d3.select('#playPauseIcon')
          .classed('fa-pause-circle', false)
          .classed('fa-play-circle', true)
        clearInterval(animPlayer)
        pointInInterval = 0
        animIsPlaying = false;
    }

    function brushed() {
      var selection = d3Event.selection

      if (self.state.initialExtent.isInitial) {
        self.setState({initialExtent:{isInitial: false, extent: selection}})
      }

      var selectedExtent = selection ? selection.map(brush_x.invert, brush_x) : self.state.initialExtent.extent.map(brush_x.invert, brush_x),
          newSelectedData = util.filterMetadataByDateRange(metadata, selectedExtent)

      d3.select('#extentDescriptor')
        .text('Period:  ' + util.formatTime(selectedExtent[0]) + ' - ' + util.formatTime(selectedExtent[1]) )

      self.props.selectActiveData({selectedData: newSelectedData, selectedExtent: selectedExtent})
    }

  }
  updateD3(){
    d3.select('#brusher').select('svg#brushChart').remove()
    this.renderD3()
  }
}

export default BrushViewer;

/*
<div id='brushController' style={{height:'50px'}}>
  <AnimationController />
</div>

*/

//Module map viewer: map only
import React, {Component} from 'react'
import {withFauxDOM} from 'react-faux-dom'
import * as util from '../utils/utils'
import DownloadSVG from './component/btn_downloadSVG'
import CloseChart from '../containers/cont_CloseChart'
import {PanelTitle} from './component/btn_utils'
import {event as d3Event} from 'd3'
const d3 = {
  ...require('d3-geo'),
  ...require('d3-zoom'),
  ...require('d3-array'),
  ...require('d3-scale'),
  ...require('d3-axis'),
  ...require('d3-selection'),
  ...require('d3-force')
}
//
class MapViewer extends Component {
  constructor(props){
    super(props)
  this.initiateMap= this.initiateMap.bind(this)
  this.reloadMap = this.reloadMap.bind(this)
  }

  componentDidMount(){
    this.initiateMap()
  }

  componentDidUpdate(prevProps, prevState){
    if (this.props.width !== prevProps.width &&
        this.props.height !== prevProps.height) {
      d3.select('#floorplanSVG').remove()
      d3.select('#map_refreshDescriptor').classed('w3-show', true)
    }
  }

  render() {
    const {mapViewer: mapViewer} = this.props
    return (
      <div id="map" className='w3-row'>
        <div id="mapHandle" className= 'panelHeader w3-row w3-dark-grey'>
          <PanelTitle titleText={util.getFloorplanName(this.props.levelID)}></PanelTitle>
          <div id="map_setting" className= 'w3-col m6 w3-right'>
            <CloseChart id={this.props.levelID}/>
            <DownloadSVG id='floorplanSVG'/>
            <div id='refreshButton' className='w3-right'>
              <button onClick={this.reloadMap}
                      className="w3-button w3-medium w3-hover-none">
                      <i className="fa fa-refresh fa-lg"></i>
              </button>
            </div>
          </div>
        </div>

        <div id='map_tooltip' className='w3-container w3-small w3-white w3-row'>
          <div id='tooltip_info_icon' className='w3-text-white w3-col s1'>
            <p>.<i className="fa fa-info-circle fa-lg w3-text-black"></i></p>
          </div>
          <div id='map_tooltip_text' className='w3-col s11 w3-text-left'>
            <p></p>
          </div>
        </div>

        <div id= 'mapSVGviewer' className= 'w3-center'>
          <h6 id='map_refreshDescriptor'
             className='w3-hide'>
             Redraw chart using reload button on the top right corner of this window
           </h6>
            {mapViewer}
        </div>
      </div>
    )
  }

  initiateMap(){
    const margin = {'top': 10, 'right': 20, 'bottom': 10, 'left': 20},
                  {height, width, connectFauxDOM, drawFauxDOM} = this.props,
                  map_width = width - margin.left - margin.right,
                  map_height = height- margin.top - margin.bottom - 100,
                  faux = connectFauxDOM('div', 'mapViewer'),
                  geojson = this.props.floorplan

    var zoomLevel = 1, isZoomed = false,
    isMouseDown = false,
    currentX, currentY, initialX, initialY,
    xOffset = 0, yOffset = 0


    const mapProjection = d3.geoMercator()
                      .fitExtent([[0, 0], [map_width, map_height]], geojson),
                      path = d3.geoPath().projection(mapProjection).pointRadius(0)

    function filterLevel(level) {
      return function(feature) {
        return feature.properties.level.indexOf(level) !== -1
      }
    }

    var floorplanLevel = +this.props.levelID.split('_')[1],
        level = JSON.parse(JSON.stringify(geojson))
    // Filtering the level
    level.features = level.features.filter(filterLevel(floorplanLevel))
    /*
    level.features = level.features.filter(function(d) {
      //console.log(d);
      if (d.properties.level.indexOf(floorplanLevel) && d.geometry.type === 'Point') {
        console.log(d);
        return false;
      }
      else {
        //remove it
        return true;
      }
    })
  */
    var container = d3.select(faux),
        transformFloorplanID = 'transform'+this.props.levelID

    //reset zoom and loation
    d3.select('#'+transformFloorplanID)
    .attr('transform', 'translate(' + margin.left + ',' + margin.top + ') scale(1)')

    //make svg root
    var svg = container.append('svg').attr('id', 'floorplanSVG')
                .attr('width', map_width + margin.left + margin.right)
                .attr('height', map_height + margin.top + margin.bottom)
    var g = svg.append('g')
                .attr('id', transformFloorplanID)
                .attr('transform', 'translate(' + margin.left + ',' + margin.top + ') scale(1)')

    //add site label
    g.append('g').selectAll('.map_siteLabel')
                    .data(level.features)
                    .enter()
                    .append('text')
                    .attr('class', 'map_siteLabel')
                    .text( d => d.properties.name)
                    .attr('x', function(d) {return path.centroid(d)[0]})
                    .attr('y', function(d) {return path.centroid(d)[1]})
                    .attr('fill', 'black')
                    .attr('text-anchor', 'middle')
                    .attr('font-size', '8pt')

    //add path
    g.append('g').selectAll('.pathD')
                    .data([0])
                    .enter()
                    .append('path')
                    .attr('class', 'pathD')
                    .attr('d', path(level))
                    .attr('fill', 'transparent')
                    .attr('stroke-width', '1px')
                    .attr('stroke', 'black');

    svg.on('mousedown', function() {
            isMouseDown = true
            initialX = d3Event.clientX - xOffset
            initialY = d3Event.clientY - yOffset})
        .on('mousemove', function() {
            if (isMouseDown) {
              if (isZoomed) {
                currentX = d3Event.clientX - initialX - margin.left
                currentY = d3Event.clientY - initialY - margin.top
                //offset
                xOffset = currentX
                yOffset = currentY
                //move it
                moveIt('#'+transformFloorplanID, currentX, currentY, zoomLevel)
              }
              else {
                currentX = d3Event.clientX - initialX
                currentY = d3Event.clientY - initialY
                //offset
                xOffset = currentX
                yOffset = currentY
                //move it
                moveIt('#'+transformFloorplanID, currentX, currentY, zoomLevel)
              }
            }
          })
        .on('mouseup', function() {
          initialX = currentX
          initialY = currentY
          isMouseDown = false
        })

    // Event: zoom
    svg.on('wheel.zoom', function() {
      if (d3Event.deltaY > 0 && zoomLevel < 4 ) {
        zoomLevel += 0.15
        zoomed('#'+transformFloorplanID, zoomLevel)
      }
      else if (d3Event.deltaY < 0 && zoomLevel > 0.2 ) {
        zoomLevel -= 0.15
        zoomed('#'+transformFloorplanID, zoomLevel)
      }
    })
    //Listener: zoomed
    function zoomed(transformID, newLevel) {
        var newMarginV = ((map_height * newLevel) - map_height)/2,
            newMarginH = ((map_width * newLevel) - map_width)/2
        if (currentX || currentY) {
          d3.select(transformID)
            .attr('transform', 'translate(' + currentX + ',' + currentY + ') scale(' + newLevel + ')')
        }
        else {
          d3.select(transformID)
            .attr('transform', 'translate(' + (margin.left - newMarginH) + ',' + (margin.top - newMarginV) + ') scale(' + newLevel + ')')
        }
      }
    //Listener: dragged
    function moveIt(transformID, posX, posY, currentZoomLevel) {
      d3.select(transformID)
        .attr('transform', 'translate(' + posX + ',' + posY + ') scale(' + currentZoomLevel + ')')
      }

    drawFauxDOM()
  }

  reloadMap(){
    d3.select('#floorplanSVG').remove()
    d3.select('#map_refreshDescriptor').classed('w3-show', false)
    this.initiateMap()
  }
}

export default withFauxDOM(MapViewer)

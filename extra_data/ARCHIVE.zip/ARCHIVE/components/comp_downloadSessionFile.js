import React, {Component} from 'react';
import DownloadSessionIcon from '../img/downloadSession.png';
import {sessionDownloader} from '../utils/utils'


class DownloadSessionFile extends Component{
  constructor(props){
    //props: metadata, floorplan, trans, tree, upload method
    super(props)
    this.onClick = this.onClick.bind(this);
  }

  onClick(e){
    if (!this.props.metadata && !this.props.tree
      && !this.props.transmission && !this.props.floorplan) {
      alert("No input files is avalaible. Please input the file first")
    }
    else {
      //alert("Session file downloaded")
      //make session downloader
      sessionDownloader(this.props.metadata, this.props.tree,
        this.props.transmission, this.props.floorplan)

    }

  }
  render(){
    //console.log(this.props);
    return(
      <div style={{marginBottom: '5px'}} >
        <label
          onClick={this.onClick}
          className='w3-button w3-round w3-hover-lightgray'>
          <img
            src={DownloadSessionIcon}
            alt="download session file"
            style={{width:"40%"}}
            className="w3-hover-opacity" />
          <br/>
          <p>Download session file</p>
        </label>
      </div>
    )
  }
}
export default DownloadSessionFile;

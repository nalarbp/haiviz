import React, {Component} from 'react'
import MapViewer from './comp_MapViewer'
import IntegratedMapViewer from './comp_MapViewer_full'
import {getFloorplanName} from '../utils/utils'
import {PanelHeader} from '../utils/styled'
import DownloadSVG from './component/btn_downloadSVG'
import CloseChart from '../containers/cont_CloseChart'

class MapComponent extends Component {
  constructor(props){
    super(props)
  }

//  shouldComponentUpdate(nextProps, nextStates){
//    if (Math.round(nextProps.height) === Math.round(this.props.height) ||
//        Math.round(nextProps.width) === Math.round(this.props.width)) {
//      return false
//    }
//    else {
//      return true
//    }
//  }
///
  render() {
    if (this.props.height !== 0 && this.props.width !== 0 &&
      this.props.floorplan !== null && this.props.metadata !== null) {
        if (this.props.selectedData !== null && this.props.selectedData !== {} &&
            this.props.selectedExtent !== null) {
          return (
            <div style={{width: '100%', height: '100%'}}>
              <IntegratedMapViewer height={this.props.height}
                          width={this.props.width}
                          selectActiveData={this.props.selectActiveData}
                          selectedData={this.props.selectedData}
                          selectedExtent={this.props.selectedExtent}
                          metadata={this.props.metadata}
                          colorIndex={this.props.colorIndex}
                          levelID={this.props.levelID}
                          floorplan={this.props.floorplan}
                ></IntegratedMapViewer>
            </div>
          )
        }
        else {
          return (
            <div style={{width: '100%', height: '100%'}}>
              <IntegratedMapViewer height={this.props.height}
                          width={this.props.width}
                          metadata={this.props.metadata}
                          colorIndex={this.props.colorIndex}
                          levelID={this.props.levelID}
                          floorplan={this.props.floorplan}
                          selectActiveData={this.props.selectActiveData}
              ></IntegratedMapViewer>
            </div>
          )
        }
    }
    else if (this.props.height !== 0 && this.props.width !== 0 && this.props.floorplan !== null) {
      //console.log('1: render: dimensions and trans are ready')
      return (
        <div style={{width: '100%', height: '100%'}}>
          <PanelHeader className='panelHeader'>
            <div className='panelTitle'>Map</div>
            <CloseChart id={this.props.levelID}/>
            <DownloadSVG svgID="floorplanSVG"/>
          </PanelHeader>
          <MapViewer height={this.props.height}
                      width={this.props.width}
                      levelID={this.props.levelID}
                      floorplan={this.props.floorplan}
            ></MapViewer>
        </div>
      )
    }
    else {
      //console.log('1: render: dimensions not ready', this.props.height, this.props.width)
      return (
        <div style={{width: '100%', height: '100%'}}>
          <PanelHeader className='panelHeader'>
            <div className='panelTitle'>Map</div>
            <CloseChart id={this.props.levelID}/>
            <DownloadSVG svgID="floorplanSVG"/>
          </PanelHeader>
        </div>
      )
    }
  }
}

export default MapComponent

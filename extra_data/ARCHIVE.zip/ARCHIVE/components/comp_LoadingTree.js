import React, {Component} from 'react'
import LoadingTreeImg from '../img/loadingTree.png';
//import UploadFile from './component/btn_uploadFile'
//import UploadFileDropbox from './component/btn_uploadFileDropbox'
import * as fa from 'react-icons/lib/fa'

class LoadingTree extends Component {

  render() {
    return (
        <div className="w3-content w3-container">
          <div style={{border:'1px dashed black'}} className=' w3-container w3-margin w3-padding-32'>
            <div style={{maxWidth:'300px'}} className='w3-content w3-center'>
              <div>
                <img src={LoadingTreeImg} alt='Waiting tree'></img>
              </div>
            </div>
          </div>

        </div>

    )
  }

}

export default LoadingTree
/*
<UploadFileDropbox loadData={this.props.loadData} fileID='metadata'/>

*/

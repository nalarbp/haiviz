//Module map viewer: map + metadata
import React, {Component} from 'react'
import {withFauxDOM} from 'react-faux-dom'
import * as util from '../utils/utils'
import {event as d3Event} from 'd3'
import DownloadSVG from './component/btn_downloadSVG'
import CloseChart from '../containers/cont_CloseChart'
import {PanelTitle} from './component/btn_utils'
const d3 = {
  ...require('d3-geo'),
  ...require('d3-array'),
  ...require('d3-scale'),
  ...require('d3-axis'),
  ...require('d3-zoom'),
  ...require('d3-drag'),
  ...require('d3-selection'),
  ...require('d3-time-format'),
  ...require('d3-force')
}

class MapViewerWithMetadata extends Component {
  constructor(props){
    super(props)
    this.state={locationTextSize:'5pt',
                nodeSize:5,
                nodeStrength:null, //range from -5 to +5
                rotateDegree:0,
                showTransmission:false,
                features_level: null,
                features_name: null}

    this.initiateMap= this.initiateMap.bind(this)
    this.reloadMap = this.reloadMap.bind(this)

    this.changeNodeSize= this.changeNodeSize.bind(this)
    this.updateNodeSize= this.updateNodeSize.bind(this)

    this.changeLocationTextSize= this.changeLocationTextSize.bind(this)
    this.updateLocationTextSize= this.updateLocationTextSize.bind(this)

    this.changeNodeDistanceValue= this.changeNodeDistanceValue.bind(this)
    this.updateNodeDistance= this.updateNodeDistance.bind(this)

    this.updateCircles= this.updateCircles.bind(this)

  }
  //open-close setting icon
  openSetting() {
    var el = document.getElementById('MapController')
    el.className = "w3-sidebar w3-border-bottom w3-show-block"
    el.style="height:auto;right:0"
  }
  closeSetting(){
    document.getElementById('MapController').className = "w3-hide"
  }
  //change-update node size
  changeNodeSize(e){
    var value = e.target.value
    if (value) {
      this.setState({nodeSize:value})
    }
  }
  updateNodeSize(value){
    d3.selectAll('.map_nodes')
      .attr('r', function (d) {
        return value
      })
  }

  //change-update location text size
  changeLocationTextSize(e){
    var value = e.target.value
    if (value) {
      this.setState({locationTextSize:value})
    }
  }
  updateLocationTextSize(value){
    d3.selectAll('.map_siteLabel')
      .attr('font-size', function (d) {
        return value+'pt'
      })
  }

  //change-update nodeStrength
  changeNodeDistanceValue(e){
    var value = e.target.value
    if (value) {
      this.setState({nodeStrength:value})
    }
  }
  updateNodeDistance(){
    var {connectFauxDOM, colorIndex, drawFauxDOM} = this.props,
        nodeDistance = this.state.nodeStrength,
        features_name = this.state.features_name,
        faux = connectFauxDOM('div', 'mapViewer'),
        container = d3.select(faux)

    var newCirclesData = container.selectAll('circle.map_nodes').data()


    if (nodeDistance) {
      var sim = d3.forceSimulation(newCirclesData)
                  .force('charge', d3.forceManyBody().strength(0 - nodeDistance).distanceMax(50).distanceMin(1))
                  .stop()

      for (var i = 0; i < 300; i++) {sim.tick()}
      container.selectAll('circle.map_nodes')
                .attr("cx", (d) => {return d.x})
                .attr("cy", (d) => {return d.y})
    }
    else {
      alert('Please enter distance value')
    }

    //d3.select(faux).selectAll('.map_nodes')
    //  .attr('cx', function (d) {
    //    return d.x
    //  })

    drawFauxDOM()
  }

  updateCircles(selectedData){
    var {connectFauxDOM, colorIndex, drawFauxDOM} = this.props,
        faux = connectFauxDOM('div', 'mapViewer'),
        nodeSize = this.state.nodeSize,
        container = d3.select(faux)

    if (this.props.selectedData &&
        this.props.selectedExtent &&
        this.props.selectedExtent.length !== 0) {
        var dateExtent = this.props.selectedExtent,
            entryIDs = this.props.selectedData.map(function(d) {return d.entryID})

      container.selectAll('circle.map_nodes')
                .attr('r', function (d) {
                  if (entryIDs.indexOf(d.entryID) === -1) {
                    return nodeSize;
                  } else {
                    return 2*nodeSize;
                  }
                })
                .attr('fill', function (d) {
                  if (entryIDs.indexOf(d.entryID) === -1) {
                    return 'lightgray'
                  } else {
                    return util.fillWithColorIndex(d, colorIndex)
                  }
                })

    }
    else if (this.props.selectedData) {
       var entryIDs = this.props.selectedData.map(function(d) {return d.entryID})
       container.selectAll('circle.map_nodes')
       .attr('r', function (d) {
         if (entryIDs.indexOf(d.entryID) === -1) {
           return nodeSize;
         } else {
           return 2*nodeSize;
         }
       })
       .attr('fill', function (d) {
         if (entryIDs.indexOf(d.entryID) === -1) {
           return 'lightgray'
         } else {
           return util.fillWithColorIndex(d, colorIndex)
         }
       })
    }
    else {
      //do nothing
    }
    drawFauxDOM()
  }

  componentDidMount(){
    this.initiateMap()
  }

  shouldComponentUpdate(nextProps, nextStates){
    if (nextStates.nodeSize !== this.state.nodeSize) {
      this.updateNodeSize(nextStates.nodeSize)
      return false;
    }
    else if (nextStates.locationTextSize !== this.state.locationTextSize) {
      this.updateLocationTextSize(nextStates.locationTextSize)
      return false;
    }
    else if (nextStates.nodeStrength !== this.state.nodeStrength) {
      return false;
    }
    else if (nextStates.features_level !== this.state.features_level ||
             nextStates.features_name !== this.state.features_name) {
      return false;
    }
    else {
      return true;
    }
  }

  componentDidUpdate(prevProps, prevState){
    if (this.props.selectedData && this.props.selectedData !== prevProps.selectedData ||
    this.props.selectedExtent !== prevProps.selectedExtent){
      this.updateCircles(this.props.selectedData)
    }
    else if (this.props.width !== prevProps.width &&
        this.props.height !== prevProps.height) {
      d3.select('#floorplanSVG').remove()
      d3.select('#floorplanTooltip').remove()
    }
    else if (this.props.floorplan !== prevProps.floorplan) {
      this.reloadMap()
      console.log('reloading');
    }
  }

  render() {
    const {mapViewer: mapViewer} = this.props
    return (
      <div id="map" className='w3-row'>
        <div id="mapHandle" className= 'panelHeader w3-row w3-dark-grey'>
          <PanelTitle titleText={util.getFloorplanName(this.props.levelID)}></PanelTitle>
          <div id="map_setting" className= 'w3-col m6 w3-right'>
            <CloseChart id={this.props.levelID}/>
            <DownloadSVG id='floorplanSVG'/>
            <div id='settingButton' className='w3-right'>
              <button onClick={this.openSetting}
                      className="w3-button w3-medium w3-hover-none">
                      <i className="fa fa-wrench fa-lg"></i>
              </button>
            </div>
            <div id='refreshButton' className='w3-right'>
              <button onClick={this.reloadMap}
                      className="w3-button w3-medium w3-hover-none">
                      <i className="fa fa-refresh fa-lg"></i>
              </button>
            </div>
          </div>
        </div>

        <div id="MapController" className= "w3-sidebar w3-tiny w3-border-right w3-behind w3-hide">
          <div className= "w3-right" >
            <button onClick={this.closeSetting}
                    className="w3-button w3-medium w3-hover-none">
                    <i className="fa fa-times-circle fa-lg"></i></button>
          </div>
          <div id='nodeSize' className='w3-container'>
            <label>Node size</label>
            <input onChange={this.changeNodeSize} type="range" min='0' max='10' className='w3-input w3-border'></input>
          </div>
          <div id='locationTextSize' className='w3-container'>
            <label>Location text size</label>
            <input onChange={this.changeLocationTextSize} type="range" min='0' max='14' className='w3-input w3-border'></input>
          </div>
          <div id='changeNodeDistanceValue' className='w3-container '>
            <label>Node distance</label>
            <input onChange={this.changeNodeDistanceValue} type="number" className='w3-input w3-border'></input>
          </div>
          <div id='updateNodeDistanceButton' className='w3-container w3-margin-top'>
            <button onClick={this.updateNodeDistance} className='w3-button w3-tiny w3-round w3-green'>Change Node distance</button>
          </div>

        </div>



        <div id='map_tooltip' className='w3-container w3-small w3-white w3-row'>
          <div id='tooltip_info_icon' className='w3-text-white w3-col s1'>
            <p>.<i className="fa fa-info-circle fa-lg w3-text-black"></i></p>
          </div>
          <div id='map_tooltip_text' className='w3-col s11 w3-text-left'>
            <p></p>
          </div>
        </div>

        <div id= 'mapSVGviewer' className= 'w3-center'>
          <h6 id='map_refreshDescriptor'
             className='w3-hide'>
             Redraw chart using reload button on the top right corner of this window
           </h6>
            {mapViewer}
        </div>
      </div>
    )
  }

  initiateMap(){
    const margin = {'top': 10, 'right': 10, 'bottom': 50, 'left': 10},
                  {height, width, connectFauxDOM, colorIndex, drawFauxDOM} = this.props,
                  map_width = width - margin.left - margin.right,
                  map_height = height - margin.top - margin.bottom - 60,
                  svg_height = map_height + margin.top + margin.bottom - 60,
                  faux = connectFauxDOM('div', 'mapViewer'),
                  geojson = this.props.floorplan,
                  formatTime = d3.timeFormat("%d %B, %Y"),
                  defaultTickNumber = 50

    var metadata = this.props.metadata

    const mapProjection = d3.geoMercator().fitExtent([[0, 0], [map_width, svg_height-10]], geojson),
          path = d3.geoPath().projection(mapProjection).pointRadius(0)


    //function filterLevel(level) {
    //  return function(feature) {
    //    return feature.properties.level.indexOf(level) !== -1}}

    var floorplanLevel = +this.props.levelID.split('_')[1],
        level = JSON.parse(JSON.stringify(geojson))
    // Filtering the level
    //level.features = level.features.filter(filterLevel(floorplanLevel))
    //level.features = level.features.filter(filterLevel(floorplanLevel))

    //group the features
    var features_level = this.state.features_level ? this.state.features_level : []
    var features_name = this.state.features_name ? this.state.features_name : []

    if (features_level.length === 0) {
      level.features.forEach(function(d) {
        if (d.properties.level.indexOf(floorplanLevel) !== -1) {
          features_level.push(d)
        }
        if (d.properties.name) {
          features_name.push(d)
        }
      })
      // set state
      this.setState({features_level:features_level, features_name:features_name})
    }

    console.log(features_level.length, features_name.length);



    var container = d3.select(faux),
        transformFloorplanID = 'transform'+this.props.levelID,
        tooltipID = 'tooltip'+this.props.levelID

    //reset zoom and loation
    d3.select('#'+transformFloorplanID)
    .attr('transform', 'translate(' + margin.left + ',' + margin.top + ') scale(1)')

    //make tooltip
    var tooltip = container.append('div')
                            .attr('id', tooltipID)
                            .classed('tooltip', true)
    //make svg root
    var svg = container.append('svg').attr('id', 'floorplanSVG')
                .attr('width', map_width + margin.left + margin.right)
                .attr('height', svg_height)
    var g = svg.append('g')
                .attr('id', transformFloorplanID)
                .attr('transform', 'translate(' + margin.left + ',' + margin.top + ') scale(1)')

    //add path
    g.append('g').selectAll('.pathD')
                    .data(features_level)
                    .enter()
                    .append('path')
                    .attr('class', 'pathD')
                    .attr('d', path)
                    .attr('fill', function(d) {
                      if (d.properties.hasOwnProperty('fill')) {
                        if (d.properties.fill === "#555555") {
                          return 'transparent'
                        }
                        else {
                          return d.properties.fill
                        }
                      }
                      return 'transparent'
                    })
                    .attr('stroke-width', '1px')
                    .attr('stroke', 'black');

    //run simulation and spread circle's position
    metadata.forEach(function(d) {
        d.x = util.getXfromPath(d.siteID, features_name, path)
        d.y = util.getYfromPath(d.siteID, features_name, path)
      });

    var sim = d3.forceSimulation(metadata)
                .force('charge', d3.forceManyBody().strength(0).distanceMax(10).distanceMin(1))
                .stop()
    for (var i = 0; i < defaultTickNumber; i++) {sim.tick()}

    //circles
    var nodeGroup = g.append('g').attr('id', 'nodeMapGroup'),
        circles = nodeGroup.selectAll('.map_nodes')
                    .data(metadata.filter(d => d.siteLevel === floorplanLevel))
                    .enter()
                    .append('circle')
                    .attr('class', 'map_nodes')
                    .attr('r', this.state.nodeSize)
                    .attr("cx", (d) => {return d.x})
                    .attr("cy", (d) => {return d.y})
                    .attr('fill', function(d) {
                      return util.fillWithColorIndex(d, colorIndex)
                    })
                    .attr('stroke',  'black')
                    .attr('stroke-width', '2px')


    //add site label
    g.append('g').selectAll('.map_siteLabel')
                    .data(features_name)
                    .enter()
                    .append('text')
                    .attr('class', 'map_siteLabel')
                    .text( d => d.properties.name)
                    .attr('x', function(d) {return path.centroid(d)[0] + 10})
                    .attr('y', function(d) {return path.centroid(d)[1] + 10})
                    .attr('fill', 'black')
                    .attr('text-anchor', 'middle')
                    .attr('font-size', this.state.locationTextSize)

      //================DRAG & ZOOM FUNCTION =====================//
      var zoomLevel = 1, isZoomed = false,
      isMouseDown = false,
      currentX, currentY, initialX, initialY,
      xOffset = 0, yOffset = 0

      svg.on('mousedown', function() {
              isMouseDown = true
              initialX = d3Event.clientX - xOffset
              initialY = d3Event.clientY - yOffset})
          .on('mousemove', function() {
              if (isMouseDown) {
                  currentX = d3Event.clientX - initialX
                  currentY = d3Event.clientY - initialY
                  //offset
                  xOffset = currentX
                  yOffset = currentY
                  //move it
                  moveIt('#'+transformFloorplanID, currentX, currentY, zoomLevel)
              }
            })
          .on('mouseup', function() {
            initialX = currentX
            initialY = currentY
            isMouseDown = false
          })

      // Event: zoom
      svg.on('wheel.zoom', function() {
        if (d3Event.deltaY > 0 && zoomLevel < 4 ) {
          zoomLevel += 0.15
          zoomed('#'+transformFloorplanID, zoomLevel)
        }
        else if (d3Event.deltaY < 0 && zoomLevel > 0.2 ) {
          zoomLevel -= 0.15
          zoomed('#'+transformFloorplanID, zoomLevel)
        }
      })
      //Listener: zoomed
      function zoomed(transformID, newLevel) {
          var newMarginV = ((map_height * newLevel) - map_height)/2,
              newMarginH = ((map_width * newLevel) - map_width)/2
          if (currentX || currentY) {
            d3.select(transformID)
              .attr('transform', 'translate(' + (currentX) + ',' + (currentY) + ') scale(' + newLevel + ')')
          }
          else {
            d3.select(transformID)
              .attr('transform', 'translate(' + (margin.left) + ',' + (margin.top) + ') scale(' + newLevel + ')')
          }
        }
      //Listener: dragged
      function moveIt(transformID, posX, posY, currentZoomLevel) {
        d3.select(transformID)
          .attr('transform', 'translate(' + posX + ',' + posY + ') scale(' + currentZoomLevel + ')')
        }
        // Event: zoom
      svg.on('wheel.zoom', function() {
        if (d3Event.deltaY > 0 && zoomLevel < 4 ) {
          //var initial = floorplanZoomLevel + 0.2
          zoomLevel += 0.15
          //updateFloorplanZoomLevel(num)
          zoomed('#'+transformFloorplanID, zoomLevel)
        }
        else if (d3Event.deltaY < 0 && zoomLevel > 0.2 ) {
          //var reducedLevel = floorplanZoomLevel - 0.2
          zoomLevel -= 0.15
          //updateFloorplanZoomLevel(num)
          zoomed('#'+transformFloorplanID, zoomLevel)
        }
      })
    //call the faux-dom
    drawFauxDOM()
  }

  redrawCircles(){
    var {connectFauxDOM, colorIndex, drawFauxDOM} = this.props
    d3.selectAll(".map_nodes")
      .attr('fill', function(d) {
        return 'red'
      })
  }

  reloadMap(){
    d3.select('#floorplanSVG').remove()
    d3.select('#floorplanTooltip').remove()
    this.initiateMap()
  }

}

export default withFauxDOM(MapViewerWithMetadata)

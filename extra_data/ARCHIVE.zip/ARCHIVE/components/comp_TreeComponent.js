import React, {Component} from 'react'
import {PanelHeader} from '../utils/styled'
import DownloadSVG from './component/btn_downloadSVG'
import CloseChart from '../containers/cont_CloseChart'
import TreeViewer from './comp_TreeViewer'
import TreeViewerIntegrated from './comp_TreeViewer_full'

class TreeComponent extends Component {
  constructor(props){
    super(props)
  }

/////
  render() {
    if (this.props.height !== 0 && this.props.width !== 0 &&
        this.props.tree !== null && this.props.metadata !== null) {
          //console.log(this.props.selectedData);
          if (this.props.selectedData !== null && this.props.selectedData !== {} &&
              this.props.selectedExtent !== null) {
                //console.log('TreeViewer selectedData&Extent YES')
            return (
              <div style={{width: '100%', height: '100%'}}>
                <TreeViewerIntegrated height={this.props.height}
                            width={this.props.width}
                            selectActiveData={this.props.selectActiveData}
                            selectedData={this.props.selectedData}
                            selectedExtent={this.props.selectedExtent}
                            metadata={this.props.metadata}
                            colorIndex={this.props.colorIndex}
                            tree={this.props.tree}
                  ></TreeViewerIntegrated>
              </div>
            )
          }
          else {
            //console.log('TreeViewer selectedData Null', this.props.selectedData)
            return (
              <div style={{width: '100%', height: '100%'}}>
                <TreeViewerIntegrated height={this.props.height}
                            width={this.props.width}
                            colorIndex={this.props.colorIndex}
                            metadata={this.props.metadata}
                            selectActiveData={this.props.selectActiveData}
                            tree={this.props.tree}
                  ></TreeViewerIntegrated>
              </div>
            )
          }
    }
    else if (this.props.height !== 0 && this.props.width !== 0 && this.props.tree !== null) {
      //console.log('TreeViewer Only')
      return (
          <div style={{width: '100%', height: '100%'}}>
          <PanelHeader className='panelHeader'>
            <div className='panelTitle'>Tree</div>
            <CloseChart id='tree'/>
            <DownloadSVG svgID="treeSVG"/>
          </PanelHeader>

          <TreeViewer height={this.props.height}
                      width={this.props.width}
                      tree={this.props.tree}
            ></TreeViewer>
        </div>
      )
    }
    else {
      //console.log('Blank')
      //console.log('1: render: dimensions not ready', this.props.height, this.props.width)
      return (
        <div style={{width: '100%', height: '100%'}}>
          <PanelHeader className='panelHeader'>
            <div className='panelTitle'>Tree</div>
            <CloseChart id='tree'/>
            <DownloadSVG svgID="treeSVG"/>
          </PanelHeader>
        </div>
      )
    }
  }
}

export default (TreeComponent)

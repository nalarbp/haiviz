import React, {Component} from 'react'
import LoadingGanttImg from '../img/loadingGantt.png';

class LoadingGantt extends Component {

  render() {
    return (
        <div className="w3-content w3-container">
          <div style={{border:'1px dashed black'}} className=' w3-container w3-margin w3-padding-32'>
            <div style={{maxWidth:'300px'}} className='w3-content w3-center'>
              <div>
                <img src={LoadingGanttImg} alt='Waiting metadata'></img>
              </div>
            </div>
          </div>
        </div>
    )
  }

}

export default LoadingGantt
/*
<UploadFileDropbox loadData={this.props.loadData} fileID='metadata'/>

*/

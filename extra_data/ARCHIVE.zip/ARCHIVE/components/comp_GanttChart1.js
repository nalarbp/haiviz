import React, {Component} from 'react'
import {withFauxDOM} from 'react-faux-dom'
import {PanelHeader} from '../utils/styled'
import DownloadSVG from './component/btn_downloadSVG'
import CloseChart from '../containers/cont_CloseChart'
import LoadingGantt from '../components/comp_LoadingGantt'
import * as util from '../utils/utils'
import {event as currentEvent} from 'd3';
const d3 = {
  ...require('d3-array'),
  ...require('d3-scale'),
  ...require('d3-axis'),
  ...require('d3-time'),
  ...require('d3-selection'),
}

// props from container: metadata
class GanttChart extends Component {
  constructor(props){
  super(props)
  this.renderD3= this.renderD3.bind(this)
  this.updateD3= this.updateD3.bind(this)
  }

  render() {
    const {chart: chart} = this.props
    return (
      <div style={{width: '100%', height: '100%'}}>
        <PanelHeader className='panelHeader'>
          <div className='panelTitle'>Gantt</div>
          <CloseChart id='gantt'/>
          <DownloadSVG svgID="ganttSVG"/>
        </PanelHeader>
        {chart}
      </div>
    )
  }

  renderD3(){
    const margin = {'top': 10, 'right': 15, 'bottom': 80, 'left': 60}
    const {updateClickedElement, siteColor,
           width, height, connectFauxDOM, animateFauxDOM, metadata} = this.props
    const faux = connectFauxDOM('div', 'chart')
    var dateRange = (!this.props.dateRange) ? util.getAdmissionDates(metadata) : this.props.dateRange

    var chart_width = width - margin.left - margin.right
    var chart_height = height- margin.top - margin.bottom

    //var dateRange = util.getAdmissionDates(metadata)
    var patientList = util.getPatients(metadata)
    patientList = patientList.filter(util.filterUnique);
    patientList.push("plusOne");
    var rectHeight = chart_height/patientList.length;
    //scaling
    var gantt_x = d3.scaleTime().domain(d3.extent(dateRange)).range([0, chart_width]);
    var gantt_y = d3.scalePoint().domain(patientList).range([0, chart_height]);

    //axis-scale
    var gantt_xAxis = d3.axisBottom()
                        .scale(gantt_x)

    var gantt_grid = d3.axisBottom()
                    .scale(gantt_x)
                    .ticks(d3.timeDay.every(1))
                    .tickSizeInner([5])

    var gantt_yAxis = d3.axisLeft(gantt_y).tickFormat("").tickSize(0)

    //make tooltips container
    var container = d3.select(faux)
    var tooltipID = 'ganttTooltip'
    var tooltip = container.append('div').attr('id', tooltipID).classed('tooltip', true)

    //make svg root
    var svg = container.append('svg').attr('id', 'ganttSVG')
                .attr('width', chart_width + margin.left + margin.right)
                .attr('height', chart_height + margin.top + margin.bottom)

    var svgGroupRoot = svg.append('g')
                          .attr('transform', 'translate(' + margin.left + ',' + margin.top + ')')

    svgGroupRoot.append("defs")
                .append("clipPath")
                .attr("id", "gantt_clipPath")
                .append("rect")
                .attr("width", chart_width)
                .attr("height", chart_height)

    var rectGroup =  svgGroupRoot.append("g")
                                .attr('class', 'rectGroup')
                                .attr("clip-path", "url(#gantt_clipPath)")
    // make lane bar
    var count = 1
    rectGroup.selectAll(".gantt_rect")
           .data(metadata)
           .enter().append("rect")
           .attr('class', 'gantt_rect')
           .attr('id', function(d) {return 'gantt_rect'+d.entryID })
           .attr('x', function(d) {return gantt_x(d.dateIn)})
           .attr('y', function(d) {return gantt_y(d.patID)})
           .attr('width', function(d) { return gantt_x(d.dateOut) - gantt_x(d.dateIn)})
           .attr('height', rectHeight)
           .attr('stroke-width', '2')
           .attr('stroke-dasharray', '5,3')
           .attr('stroke', 'none')
           .style("fill", function(d) {
             var colour = util.getMetadataColour(d.colour)
             return colour})
           //.style("fill", function(d) {return siteColor(d.siteID)})
           .on('click', function(d) {updateClickedElement(d.entryID)})
           .on('mouseover', function(d) {
             //console.log(currentEvent);
             util.showTooltip('#'+tooltipID, d,
             currentEvent.offsetX, currentEvent.offsetY, 'gantt')
           })
           .on('mouseout', function(d) {
             util.hideTooltip('#'+tooltipID)
           })

    //make sampling date bar
    rectGroup.selectAll(".gantt_sampling_bar")
              .data(metadata)
              .enter().append("rect")
              .attr('class', 'gantt_sampling_bar')
              .attr('x', function(d) {
                if (d.samplingDate !== "N/A") {
                  return gantt_x(d.samplingDate)}
                })
              .attr('y', function(d) {return gantt_y(d.patID)})
              .attr('width', 1)
              .attr('height', rectHeight)
              .style("fill", 'black')
              .style("opacity", function(d) {
                if (d.samplingDate === 'N/A') {
                  return 0
                }
              })

    //make sampling date circle
    rectGroup.selectAll(".gantt_sampling_circle")
              .data(metadata)
              .enter().append("circle")
              .attr('class', 'gantt_sampling_circle')
              .attr('cx', function(d) {
                if (d.samplingDate !== "N/A") {
                  return gantt_x(d.samplingDate)}
                })
              .attr('cy', function(d) {return gantt_y(d.patID) + rectHeight/2 })
              .attr('r', rectHeight/4)
              .style("fill", 'black')
              .style('opacity', function(d) {if (d.samplingDate === 'N/A') {
                  return 0
                }})
              .on('click', function(d) {updateClickedElement(d.entryID)})
              .on('mouseover', function(d) {
                util.showTooltip('#'+tooltipID, d,
                currentEvent.offsetX, currentEvent.offsetY, 'gantt_sampling_circle')
              })
              .on('mouseout', function(d) {
                util.hideTooltip('#'+tooltipID)
              })


    //add axis
    svgGroupRoot.append('g').attr('id', 'gAxisX')
                   .attr("transform", "translate(0," + chart_height + ")")
                   .call(gantt_xAxis);



    //svgGroupRoot.append("g").attr('id', 'gAxisY').call(gantt_yAxis)
    //              .attr('transform', 'translate(-3,0)')

    //add y-axis label
    var yAxis_patientLabel = patientList.map(function(d) {
      if (d !== "plusOne") {return d} else {return undefined}})

    svgGroupRoot.append("g").selectAll(".yAxis_label")
              .data(yAxis_patientLabel).enter().append('text')
              .attr('class', 'yAxis_label')
              .text(function(d) {if (d !== undefined) {return d}})
              .attr('x', -3)
,            .attr('y', function(d) {if (d !== undefined) {
                      return gantt_y(d)+(rectHeight/2)}})
              .attr('text-anchor', 'end')
              .attr('font-size', '0.7em')

    //add left and bottom axis title
    //svgGroupRoot.append("text")
    //              .attr("transform", "rotate(-90)")
    //              .attr("y", 0 - margin.left)
    //              .attr("x",0 - (chart_height / 2))
    //              .attr("dy", "1em")
    //              .style("text-anchor", "middle")
    //              .text("Patients");

    //svgGroupRoot.append("text")
    //              .attr("transform", "translate(" + ((chart_width + margin.right +
    //                margin.left)/2) + " ," + (chart_height + 35) + ")")
    //              .style("text-anchor", "middle")
    //              .text("Date");
    animateFauxDOM(50)
  }
  updateD3(){
    const faux = this.props.connectFauxDOM('div', 'chart')
    d3.select(faux).select('svg#ganttSVG').remove()
    d3.select(faux).select('#ganttTooltip').remove()
    this.renderD3()
  }

  updateClickedNodes(prevEntryID, entryID){
    const faux = this.props.connectFauxDOM('div', 'chart')
    if (prevEntryID === null) {
      d3.selectAll('rect.gantt_rect').attr('stroke', 'none')

      d3.select('#gantt_rect'+entryID)
        .attr('stroke', 'black')
    }
    else {
      d3.select('#gantt_rect'+prevEntryID)
        .attr('stroke', 'none')

      d3.select('#gantt_rect'+entryID)
        .attr('stroke', 'black')
    }
      this.props.animateFauxDOM(50)
  }
}

export default withFauxDOM(GanttChart)

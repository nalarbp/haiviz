/* == COMPONENT DASHBOARD ==
#switcher
+ input page
  - store.input = null || loading || loaded
  -
+ visualization page
//
*/

import React, { Component } from "react";
import ReactGridLayout, { WidthProvider } from "react-grid-layout";
import "react-grid-layout/css/styles.css";
import "react-resizable/css/styles.css";
import Home from "./comp_Home";
import LoginHome from "./comp_LoginHome";
import GanttContainer from "../containers/cont_Gantt";
import FloorplanContainer from "../containers/cont_Floorplan";
import TreeContainer from "../containers/cont_Tree";
import TransContainer from "../containers/cont_Trans";
import InfoBoxContainer from "../containers/cont_InfoBox";
import TableContainer from "../containers/cont_Table";
import ColourContainer from "../containers/cont_idxCol";
import BarContainer from "../containers/cont_Bar";
import SimulatedMapContainer from "../containers/cont_SimulatedMap";
import UkuleleContainer from "../containers/cont_Ukulele";
import OverlappingTableContainer from "../containers/cont_OverlappingTable";

const GridLayout = WidthProvider(ReactGridLayout);

function createChart(id) {
  let newID = id.split("_");
  switch (newID[0]) {
    case "gantt":
      return <GanttContainer />;
    case "idxCol":
      return <ColourContainer />;
    case "floorplan":
      return <FloorplanContainer levelID={id} />;
    case "tree":
      return <TreeContainer />;
    case "transmission":
      return <TransContainer />;
    case "info":
      return <InfoBoxContainer />;
    case "table":
      return <TableContainer />;
    case "bar":
      return <BarContainer />;
    case "simulatedMap":
      return <SimulatedMapContainer />;
    case "overlappingTable":
      return <OverlappingTableContainer />;
    case "ukulele":
      return <UkuleleContainer />;
    default:
      return <div></div>;
  }
}

function getDataGrid(layout, id) {
  let dataGrid;
  layout.forEach(function(d) {
    if (d.i === id) {
      dataGrid = d;
    }
  });
  return dataGrid;
}

class Dashboard extends Component {
  componentDidUpdate() {
    if (!this.props.colorIndex.color && this.props.metadata.userColor) {
      this.props.changeColorIndex({
        type: "user",
        color: this.props.metadata.userColor
      });
    }
  }

  render() {
    var layout = this.props.layout;
    var activeChart = [];
    for (var key in this.props.activeChart) {
      if (this.props.activeChart[key].show) {
        activeChart.push(key);
      }
    }

    if (!this.props.loginState) {
      return (
        <LoginHome
          loginState={this.props.loginState}
          updateLoginState={this.props.updateLoginState}
        />
      );
    } else if (activeChart.length === 0 && this.props.loginState) {
      return (
        <div id="dashboard">
          <Home
            loadData={this.props.loadData}
            setActiveChart={this.props.setActiveChart}
            metadata={this.props.metadata.metadata}
            floorplan={this.props.floorplan}
            tree={this.props.tree}
            transmission={this.props.transmission}
          />
        </div>
      );
    } else {
      return (
        <div id="dashboard">
          <GridLayout
            cols={12}
            rowHeight={30}
            margin={[3, 3]}
            draggableHandle=".panelHeader"
          >
            {activeChart.map(function(id) {
              return (
                <div key={id} data-grid={getDataGrid(layout, id)}>
                  {createChart(id)}
                </div>
              );
            })}
          </GridLayout>
        </div>
      );
    }
  }
}

export default Dashboard;

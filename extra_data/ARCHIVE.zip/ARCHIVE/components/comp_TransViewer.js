//Module tree viewer: trans only
import React, {Component} from 'react'
import {withFauxDOM} from 'react-faux-dom'
import * as util from '../utils/utils'
import {event as d3Event} from 'd3'
const d3 = {
  ...require('d3-array'),
  ...require('d3-scale'),
  ...require('d3-force'),
  ...require('d3-selection')
}
// props from container: metadata
class TransViewer extends Component {
  constructor(props){
    super(props)
    this.state= {nodeSize:5,
                  labelSize:5,
                  weightCutoff: 1,
                  linkSource:0,
                  linkTarget:0,
                  weightValue:0,
                  prevRemovedLink: null,
                  prevAddedLink: null}

    this.initiateTrans= this.initiateTrans.bind(this)
    this.reloadTrans= this.reloadTrans.bind(this)

    this.changeNodeSize= this.changeNodeSize.bind(this)
    this.updateNodeSize= this.updateNodeSize.bind(this)

    this.changeLabelSize= this.changeLabelSize.bind(this)
    this.updateLabelSize= this.updateLabelSize.bind(this)

    this.changeWeightCutoff= this.changeWeightCutoff.bind(this)
    this.updateWeightCutoff= this.updateWeightCutoff.bind(this)

    this.changeLinkSource= this.changeLinkSource.bind(this)
    this.changeLinkTarget= this.changeLinkTarget.bind(this)
    this.changeWeightValue= this.changeWeightValue.bind(this)

    this.removeLink= this.removeLink.bind(this)
    this.drawLink= this.drawLink.bind(this)
  }

  componentDidMount(){
    this.initiateTrans()
  }

  shouldComponentUpdate(nextProps, nextStates){
    if (nextStates.nodeSize !== this.state.nodeSize) {
      this.updateNodeSize(nextStates.nodeSize)
      return false;
    }
    else if (nextStates.labelSize !== this.state.labelSize) {
      this.updateLabelSize(nextStates.labelSize)
      return false;
    }
    else if (nextStates.weightCutoff !== this.state.weightCutoff) {
      this.updateWeightCutoff(nextStates.weightCutoff)
      return false;
    }
    else if (nextStates.linkSource !== this.state.linkSource ||
      nextStates.linkTarget !== this.state.linkTarget ||
      nextStates.weightValue !== this.state.weightValue) {
      return false;
    }
    else {
      return true;
    }
  }

  componentDidUpdate(prevProps, prevState){
    if (this.props.width !== prevProps.width &&
        this.props.height !== prevProps.height) {
      this.reloadTrans()
    }
    else if (this.props.transmission !== prevProps.transmission) {
      //console.log('reloading');
      this.reloadTrans()
    }
  }
  //event listener node size
  changeNodeSize(e){
    var value = e.target.value
    if (value) {
      this.setState({nodeSize:value})
    }
  }
  updateNodeSize(value){
    d3.selectAll('.trans_node')
      .attr('r', function (d) {
        return value
      })
  }

  //event listener node size
  changeLabelSize(e){
    var value = e.target.value
    if (value) {
      this.setState({labelSize:value})
    }
  }
  updateLabelSize(value){
    d3.selectAll('.trans_nodeLabel')
      .attr('font-size', function(d) {
        return value + 'px';
      })
  }

  //event listener edge weight cutoff
  changeWeightCutoff(e){
    var value = e.target.value
    if (value) {
      this.setState({weightCutoff:parseFloat(value)})
    }
  }
  updateWeightCutoff(value){
    let {connectFauxDOM, drawFauxDOM} = this.props,
     faux = connectFauxDOM('div', 'transViewer')
    d3.select(faux).selectAll('.trans_link')
      .style('opacity', function(d) {
        if (d.weight < value) {
          return 100
        } else {
          return 0
        }
      })
    drawFauxDOM()
  }

  // event listener edge ids
  changeLinkSource(e){
    var value = e.target.value
    if (value) {
      this.setState({linkSource:parseInt(value)})
    }
  }
  changeLinkTarget(e){
    var value = e.target.value
    if (value) {
      this.setState({linkTarget:parseInt(value)})
    }
  }
  changeWeightValue(e){
    var value = e.target.value
    if (value) {
      this.setState({weightValue:parseFloat(value)})
    }
  }

  removeLink(){
    var targetLinkID = this.state.linkTarget,
        sourceLinkID = this.state.linkSource,
        currentTransData = this.props.transmission,
        weight = this.state.weightValue

    var newTransmissionData = util.updateTransData(sourceLinkID, targetLinkID, currentTransData, weight ,'remove')
    this.props.updateTransmissionData(newTransmissionData)
  }

  drawLink(){
    //console.log('draw link')
    var targetLinkID = this.state.linkTarget,
        sourceLinkID = this.state.linkSource,
        currentTransData = this.props.transmission,
        weight = this.state.weightValue,
    newTransmissionData = util.updateTransData(sourceLinkID, targetLinkID, currentTransData, weight,'add')

    this.props.updateTransmissionData(newTransmissionData)
    //process addition here
  }

  render() {
    const {transViewer: transViewer} = this.props
    return (
      <div className= 'w3-row'>
        <div id="TransController" className= "w3-col m2">
          <div id='nodeSize' className='w3-container w3-margin-top w3-margin-bottom'>
            <label>Node size</label>
            <input onChange={this.changeNodeSize} type="range" min='0' max='10' className='w3-input w3-border'></input>
          </div>
          <div id='labelSize' className='w3-container w3-margin-bottom'>
            <label>Label size</label>
            <input onChange={this.changeLabelSize} type="range" min='0' max='20' className='w3-input w3-border'></input>
          </div>
          <div id='weightCutoff' className='w3-container w3-margin-bottom'>
            <label>Links weight cutoff</label>
            <input onChange={this.changeWeightCutoff} type="number" min='0' className='w3-input w3-border'></input>
          </div>
          <div id='editingLinks' className='w3-container w3-margin-bottom'>
            <label>Source link id</label>
            <input onChange={this.changeLinkSource} type="number" className='w3-input w3-border'></input>
            <label>Target link id</label>
            <input onChange={this.changeLinkTarget} type="number" className='w3-input w3-border'></input>
            <label>New links's weight</label>
            <input onChange={this.changeWeightValue} type="number" min='0' className='w3-input w3-border'></input>
          </div>
          <div id='removeLink' className='w3-container w3-margin-top w3-margin-bottom'>
            <button onClick={this.removeLink} className='w3-button w3-round w3-green'>Remove link</button>
          </div>
          <div id='addLink' className='w3-container w3-margin-top w3-margin-bottom'>
            <button onClick={this.drawLink} className='w3-button w3-round w3-green'>Draw new link</button>
          </div>
        </div>
        <div id= 'transSVGviewer' className= 'w3-light-gray w3-col m10'>
          {transViewer}
        </div>
      </div>
    )
  }

  initiateTrans(){
    ///console.log(this.props.transmission);

    var {height, width, connectFauxDOM, drawFauxDOM} = this.props,
        {weightCutoff, nodeSize, labelSize} = this.state,
        margin = {'top': 10, 'right': 50, 'bottom': 20, 'left': 20},
        faux = connectFauxDOM('div', 'transViewer'),
        trans_height = height - 40 - margin.top - margin.bottom,
        s_width = width - margin.left - margin.right,
        m_width = (width * 10/12) - margin.left - margin.right,
        trans_width = width > 640 ? m_width : s_width,
        defaultTickNumber = 30,
        zoomLevel = 1,
        dragStartX, dragStartY, isMouseDown, dragTimeStamp,
        translateX = margin.left,
        translateY = margin.top

    var transmission = JSON.parse(JSON.stringify(this.props.transmission))

    var trans_svg = d3.select(faux)
    //reset zoom and loation
    d3.select('#trans_svgGroup').attr('transform', 'translate(' + margin.left + ',' + margin.top + ') scale(1)')

    //make tooltips
    var tooltipID = 'transmission',
        tooltip = trans_svg.append('div')
                            .attr('id', tooltipID)
                            .classed('tooltip', true)

    //make svg root
    var svg = trans_svg.append('svg').attr('id', 'transmissionSVG')
                .attr('width', trans_width + margin.left + margin.right)
                .attr('height', trans_height + margin.top + margin.bottom)

    var svgGroup = svg.append('g').attr('id', 'trans_svgGroup')
                          .attr('transform', 'translate(' + margin.left + ',' + margin.top + ')')

    var trans_sim = d3.forceSimulation(transmission.nodes)
                      .force('center', d3.forceCenter(trans_width / 2, trans_height / 2))
                      .force('charge', d3.forceManyBody().strength(-50))
                      .force('link', d3.forceLink().links(transmission.links).distance(50))
                      .stop()
                //.on('tick', ticked)
    for (var i = 0; i < defaultTickNumber; i++) {trans_sim.tick()}


    //make arrow Group
    var arrowGroupBlack = svgGroup.append('g').attr('id', 'arrowGroupBlack')
                        .append("defs").append("marker")
                        .attr("id", 'trans_arrow_black')
                        .attr("refX", 15)
                        .attr("refY", 2)
                        .attr("markerWidth", 12)
                        .attr("markerHeight", 12)
                        .attr("orient", "auto")
                        .append("path")
                        .attr("d", "M0,0 L0,4 L4,2 Z")
                        .attr('fill', 'black')

    //make link group
    var linksGroup = svgGroup.append('g').attr('id', 'linksGroup')
    var linkLine = linksGroup.selectAll('.trans_link')
                            .data(transmission.links)
                            .enter()
                            .append('line').attr('class', 'trans_link')
                            .attr("x1", function(d) {return d.source.x})
                            .attr("y1", function(d) {return d.source.y})
                            .attr("x2", function(d) {return d.target.x})
                            .attr("y2", function(d) {return d.target.y})
                            .attr('stroke',  'black')
                            .attr('stroke-width', '1px')
                            .style('fill', 'none')
                            .attr('marker-end', function(d) {
                              return 'url(#trans_arrow_black)'
                            })
                            .style('opacity', function(d) {
                              if (d.weight < weightCutoff) {
                                return 100;
                              } else {
                                return 0;
                              }
                            })

    //draw nodes
    //= Math.max(60, Math.min(trans_height - 60, d.y))

    var nodesGroup = svgGroup.append('g').attr('id', 'nodesGroup')
    var nodeCircle = nodesGroup.selectAll('.trans_node')
                            .data(transmission.nodes)
                            .enter()
                            .append('circle').attr('class', 'trans_node')
                            .attr('r', 7)
                            .attr("cx", function(d){
                              if (d.x > trans_width) {
                                return d.x = Math.max(100, Math.min(trans_width - 100, d.y))
                              } else {
                                return d.x
                              }
                              })
                            .attr("cy", function(d){
                              if (d.y > trans_height) {
                                return d.y = Math.max(100, Math.min(trans_height - 100, d.y))
                              } else {
                                return d.y
                              }
                            })
                            .attr('fill', 'black')
                            .style('cursor', 'move')
                            .on('mouseover', function(d) {
                              showTooltip('#'+tooltipID, d,
                              d3Event.offsetX, d3Event.offsetY)})
                            .on('mouseout', function(d) {
                              hideTooltip('#'+tooltipID)
                            })

    var nodeLabel = nodesGroup.selectAll('.trans_nodeLabel')
                            .data(transmission.nodes)
                            .enter()
                            .append("text")
                            .attr('class', 'trans_nodeLabel')
                            .attr("x", function(d){return d.x + 10})
                            .attr("y", function(d){return d.y})
                            .attr("text-anchor", "start")
                            .attr('font-size', labelSize)
                            .attr('fill', 'black')
                            .text(function(d) { return d.name })

    // Event: zoom
    svg.on('wheel.zoom', function() {
      if (d3Event.deltaY > 0 && zoomLevel < 4 ) {
        //var initial = floorplanZoomLevel + 0.2
        zoomLevel += 0.15
        //updateFloorplanZoomLevel(num)
        zoomed('#trans_svgGroup', zoomLevel)
      }
      else if (d3Event.deltaY < 0 && zoomLevel > 0.2 ) {
        //var reducedLevel = floorplanZoomLevel - 0.2
        zoomLevel -= 0.15
        //updateFloorplanZoomLevel(num)
        zoomed('#trans_svgGroup', zoomLevel)
      }
    })
    // Event: drag
    svg.on('mousedown', function() {
            isMouseDown = true
            dragStartX = d3Event.screenX
            dragStartY = d3Event.screenY})
        .on('mousemove', function() {
          if (isMouseDown) {
            var deltaTimeStamp = d3Event.timeStamp - dragTimeStamp
            if (dragTimeStamp && deltaTimeStamp > 10) {
              var deltaX = d3Event.screenX - dragStartX
              var deltaY = d3Event.screenY - dragStartY
              dragTimeStamp = d3Event.timeStamp
              dragged('#trans_svgGroup', deltaX, deltaY, zoomLevel)
            }
            else {
              dragTimeStamp = d3Event.timeStamp
            }
          }
        })
        .on('mouseup', function() {
          isMouseDown = false
        })



    //Litener: zoomed
    function zoomed(transformID, newLevel) {
        d3.select(transformID)
          .attr('transform', 'translate(' + translateX + ',' + translateY + ') scale(' + newLevel + ')')
      }
    //Listener: dragged
    function dragged(transformID, deltaX, deltaY, currentZoomLevel) {
      translateX += deltaX*0.1
      translateY += deltaY*0.1
      d3.select(transformID)
        .attr('transform', 'translate(' + translateX + ',' + translateY + ') scale(' + currentZoomLevel + ')')
      }
    //tooltip_local
    function showTooltip(tooltipID, data, locX, locY) {
      var tooltip = d3.select(tooltipID)
                      .style('opacity', 1)
                      .style('left', locX + margin.left + margin.right + 'px')
                      .style('top', locY + 'px')
                      .append('div').attr('class', 'tooltipContent')

          tooltip.html('<p>'+data.name+'</p>'+
                '<p>id: '+data.id+'</p>')
    }

    function hideTooltip(tooltipID) {
      d3.select(tooltipID)
        .style('opacity', 0)
      d3.selectAll('.tooltipContent').remove()
    }

    drawFauxDOM()
  }
  reloadTrans(){
      d3.select('#transmissionSVG').remove()
      this.initiateTrans()
  }
}

export default withFauxDOM(TransViewer)

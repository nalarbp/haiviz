import React, {Component} from 'react'
import SelectShowcaseDataset from '../containers/cont_SelectShowcaseDataset'
import InputFile from './comp_inputFiles'
import sampleDataset from '../files/haiviz_sampleDataset.zip'
import Documentation from './comp_Documentation'
import DownloadSessionFile from './comp_downloadSessionFile'
import DownloadUploadSession from '../containers/cont_Session'
import InputDragAndDrop from  '../containers/cont_inputDragAndDrop'


class Home extends Component {
  constructor(props){
    super(props)

  }
  showDocumentation(){
    document.getElementById('documentation').style.display='block'
  }
  closeDocumentation(){
    document.getElementById('documentation').style.display='none'
  }

  render() {
    return (
      <div id='home' className="w3-content w3-center">
          <div id="documentation" className="w3-modal">
            <div className="w3-modal-content">
              <div className="w3-container">
                <span onClick={this.closeDocumentation}
                      className="w3-button w3-display-topright">&times;</span>
                <Documentation/>
              </div>
            </div>
          </div>

          <div className="w3-container w3-content w3-padding-32" style={{maxWidth:'700px'}} >
            <h1 className="w3-wide">HAIviz v.0.3</h1>
            <h4 className="w3-opacity"><i>Healthcare Associated Infections Visualization Tool</i></h4>
            <p className="w3-center">An easy to use and interactive single page application for visualizing and integrating information of genomic epidemiology of Healthcare Associated Infection (HAI).</p>
          </div>
          <div className="w3-row w3-content w3-padding-bottom" style={{maxWidth:'600px'}}>

          </div>
          <hr></hr>
          <div className="w3-row w3-content w3-padding-bottom" style={{maxWidth:'400px'}}>
            <h4>Input Files</h4>
            <div className="w3-col s12">
                <InputDragAndDrop />
            </div>
          </div>
          <hr></hr>
          <div className="w3-row w3-content" style={{maxWidth:'600px'}}>
            <h4>Documentation</h4>
            <p> <button className='w3-button w3-teal w3-small w3-round' onClick={this.showDocumentation}>Click here</button> for details documentation</p>
            <p>Sample dataset is avalaible <a href={sampleDataset} className="w3-tag">here</a> and to be used as the template.</p>

          </div>

          <hr></hr>

          <footer className="w3-center w3-small w3-white w3-padding-16 ">
            <p>HAIviz v.0.2 | {new Date().getFullYear()}
              <br/> Developed by Budi Permana at <a href="http://beatsonlab.com" target="_blank" className="w3-hover-text-green">Beatson Lab</a>
              <br/> The University of Queensland | Australia
            </p>
          </footer>

        </div>

    )
  }

}


export default Home

import React, { Component } from "react";
import { blob, csv, json, text } from "d3-fetch";
import * as util from "../utils/utils";
import MetadataIcon from "../img/metadata.png";
import FloorplanIcon from "../img/floorplan.png";
import TreeIcon from "../img/tree.png";
import TransmissionIcon from "../img/transmission.png";

import MetadataIcon_loaded from "../img/loaded_metadata.png";
import FloorplanIcon_loaded from "../img/loaded_floorplan.png";
import TreeIcon_loaded from "../img/loaded_tree.png";
import TransmissionIcon_loaded from "../img/loaded_transmission.png";

import MetadataIcon_inactive from "../img/inactive_metadata.png";
import FloorplanIcon_inactive from "../img/inactive_floorplan.png";
import TreeIcon_inactive from "../img/inactive_tree.png";
import TransmissionIcon_inactive from "../img/inactive_transmission.png";
const d3 = {
  ...require("d3-array"),
  ...require("d3-scale"),
  ...require("d3-time-format")
};
//
async function getDataset(fileURL, fileType) {
  switch (fileType) {
    //METADATA
    case "metadata":
      var metadata = await csv(fileURL),
        valid_metadata = util.validateMetadata(metadata);
      if (!valid_metadata) {
        //if its false (not valid), return null
        return {
          metadata: null,
          userColor: null,
          patientColor: null,
          isolateColor: null,
          siteColor: null,
          dateRange: null,
          daysRange: null,
          patients: null,
          locations: null,
          isolates: null
        };
      } else {
        //when input is extremely valid, return data, ready for next process
        var patientColour,
          userColor = {},
          siteColour,
          allDates = [],
          patients = [],
          locations = [],
          isolates = [];

        metadata.forEach(d => {
          //transforming metadata
          //if admission or discharge null change to period collection date
          d.entryID = +d.entryID;

          var transformedDateIn = util.metadataDateValidation(
              d.dateIn,
              "admission"
            ),
            transformedDateOut = util.metadataDateValidation(
              d.dateOut,
              "discharge"
            ),
            transformDateCol = util.metadataDateValidation(
              d.samplingDate,
              "collection"
            );

          //dateIN & dateOut will never be null
          d.dateIn = transformedDateIn ? transformedDateIn : transformDateCol;
          d.dateOut = transformedDateOut
            ? transformedDateOut
            : transformDateCol;
          d.samplingDate = transformDateCol; //valid date or undefined
          d.siteLevel = +d.siteLevel;
          //create group of patient, location and sample
          patients.push(d.patID);
          locations.push(d.siteID);
          isolates.push(d.sampleID);
          allDates.push(d.dateIn, d.dateOut, d.samplingDate);

          //add color at userColor
          userColor[d.colourLegend] = util.getMetadataColour(d.colour);
          //patientColour[d.patID]=util.getMetadataColour(d.colour)
          //siteColour[d.siteID]=util.getMetadataColour(d.colour)
        });
        //filtering the group
        patients = patients.filter(util.filterUniqueNullUndefined);
        locations = locations.filter(util.filterUniqueNullUndefined);
        isolates = isolates.filter(util.filterUniqueNullUndefined);
        allDates = allDates.filter(util.filterUndefinedNull);

        //generate color category
        patientColour = util.generateColor(patients);
        siteColour = util.generateColor(locations);

        //generate range date for date scale
        var arbtoday = new Date(),
          arbtomorrow = new Date();
        arbtomorrow.setDate(arbtoday.getDate() + 1);
        var dateRange =
          d3.extent(allDates)[0] && d3.extent(allDates)[1]
            ? d3.extent(allDates)
            : [arbtoday, arbtomorrow];

        return {
          metadata: metadata,
          userColor: userColor,
          patientColor: patientColour,
          siteColor: siteColour,
          dateRange: dateRange,
          patients: patients,
          isolates: isolates,
          locations: locations
        };
      }

    //FLOORPLAN
    case "floorplan":
      var floorplan = await json(fileURL);
      //make validation function here

      //var floorplanData = util.parseDOTtoJSON(floorplan)
      //JSON.parse(JSON.stringify(floorplan)
      /*
      floorplan.features.forEach(function(d) {
        var level = d.properties.level.split(',')
        console.log(level);
        for (var i = 0; i < level.length; i++) {level[i] = parseInt(level[i])}
        d.properties.level = level
      })
      */
      return floorplan;
    case "tree":
      //make validation here
      var tree = await text(fileURL);
      return tree;
    case "transmission":
      //make validation here: if valid continue, else alert
      var dotURL = await text(fileURL);
      var transmissionData = util.parseDOTtoJSON(dotURL);
      return transmissionData;

    default:
    //return undefined
  }
}

class InputFiles extends Component {
  constructor(props) {
    //props: metadata, floorplan, trans, tree, upload method
    super(props);
    this.onChange = this.onChange.bind(this);
    this.getAcceptType = this.getAcceptType.bind(this);
    this.getIcon = this.getIcon.bind(this);
    this.getAltImage = this.getAltImage.bind(this);
    this.getInputTitle = this.getInputTitle.bind(this);
    this.isDisabled = this.isDisabled.bind(this);
  }

  isDisabled(fileID) {
    switch (fileID) {
      case "metadata":
        if (this.props.metadata) {
          return true;
        } else {
          return false;
        }

      case "floorplan":
        if (this.props.floorplan || !this.props.metadata) {
          return true; //disable
        } else {
          return false; //active
        }

      case "tree":
        if (!this.props.metadata || this.props.tree) {
          return true;
        } else {
          return false;
        }

      case "transmission":
        if (!this.props.metadata || this.props.transmission) {
          return true;
        } else {
          return false;
        }

      default:
    }
  }
  getAcceptType(fileID) {
    switch (fileID) {
      case "metadata":
        return ".csv";
      case "floorplan":
        return ".geojson";
      case "tree":
        return ".nwk";
      case "transmission":
        return ".gv";
      //return '.csv'
      default:
    }
  }
  getAltImage(fileID) {
    switch (fileID) {
      case "metadata":
        return "Metadata";
      case "floorplan":
        return "Floorplan";
      case "tree":
        return "Tree";
      case "transmission":
        return "Transmission";
      default:
    }
  }
  getInputTitle(fileID) {
    switch (fileID) {
      case "metadata":
        return "Metadata";
        break;
      case "floorplan":
        return "Map";
        break;
      case "tree":
        return "Phylogenetic Tree";
        break;
      case "transmission":
        return "Transmission Graph";
        break;
      default:
        return undefined;
    }
  }
  getIcon(fileID) {
    switch (fileID) {
      case "metadata":
        if (!this.props.metadata) {
          return MetadataIcon;
        }
        return MetadataIcon_loaded;
      case "floorplan":
        if (!this.props.metadata && !this.props.floorplan) {
          return FloorplanIcon_inactive;
        } else if (this.props.metadata && !this.props.floorplan) {
          return FloorplanIcon;
        } else {
          return FloorplanIcon_loaded;
        }
      case "tree":
        if (!this.props.metadata && !this.props.tree) {
          return TreeIcon_inactive;
        } else if (this.props.metadata && !this.props.tree) {
          return TreeIcon;
        } else {
          return TreeIcon_loaded;
        }

      case "transmission":
        if (!this.props.metadata && !this.props.transmission) {
          return TransmissionIcon_inactive;
        } else if (this.props.metadata && !this.props.transmission) {
          return TransmissionIcon;
        } else {
          return TransmissionIcon_loaded;
        }

      default:
    }
  }
  onChange(e) {
    var fileID = this.props.fileID;
    var self = this;
    var file = e.target.files[0];
    if (file) {
      var reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onloadend = function(evt) {
        var dataUrl = evt.target.result;
        var data = getDataset(dataUrl, fileID); //-Start loading data!
        self.props.loadData(data, fileID); //loading to state via action
      };
    }
  }
  render() {
    //console.log(this.props);
    return (
      <div style={{ marginBottom: "5px" }}>
        <input
          type="file"
          accept={this.getAcceptType(this.props.fileID)}
          id={this.props.fileID}
          style={{ display: "none" }}
          onChange={this.onChange}
          disabled={this.isDisabled(this.props.fileID)}
        />
        <label
          className="w3-button w3-round w3-hover-lightgray"
          htmlFor={this.props.fileID}
        >
          <img
            src={this.getIcon(this.props.fileID)}
            alt={this.getAltImage(this.props.fileID)}
            style={{ width: "40%" }}
            className="w3-hover-opacity"
          />
          <br />
          <p>{this.getInputTitle(this.props.fileID)}</p>
        </label>
      </div>
    );
  }
}
export default InputFiles;

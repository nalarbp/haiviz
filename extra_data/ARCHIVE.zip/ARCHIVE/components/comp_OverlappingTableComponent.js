import React, {Component} from 'react'
import {PanelHeader} from '../utils/styled'
//import DownloadSVG from './component/btn_downloadSVG'
import CloseChart from '../containers/cont_CloseChart'
import OverlappingTableViewer from './comp_OverlappingTableViewer'

class OverlappingTableComponent extends Component {
  render() {
    if (this.props.height !== 0 && this.props.width !== 0 && this.props.metadata !== null) {
      return (
        <div style={{width: '100%', height: '100%'}} >
          <OverlappingTableViewer height={this.props.height}
                      width={this.props.width}
                      metadata={this.props.metadata}
                      selectActiveData={this.props.selectActiveData}
            ></OverlappingTableViewer>
        </div>
      )
    }
    else {
      return (
        <div style={{width: '100%', height: '100%'}}>
          <PanelHeader className='panelHeader'>
            <div className='panelTitle'>Overlapping Period</div>
            <CloseChart id='overlappingTable'/>
          </PanelHeader>
        </div>
      )
    }
  }
}

export default OverlappingTableComponent
